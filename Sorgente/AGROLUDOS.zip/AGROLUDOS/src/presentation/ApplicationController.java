package presentation;

import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import business.BusinessDelegate;
import mail.SendMail;
import ui.MainMenu;
import ui.Menu;
import ui.ModificaPassword;
import ui.Registrazione;
import ui.mngCompetizione.AggiungiCompetizione;
import ui.mngCompetizione.CompetizioniGestite;
import ui.mngCompetizione.ListaPartecipanti;
import ui.mngCompetizione.MenuMngCompetizione;
import ui.mngCompetizione.ModificaCompetizione;
import ui.mngCompetizione.ModificaDatiManager;
import ui.mngCompetizione.ModificaOptionalPartecipante;
import ui.mngCompetizione.NuovoMngCompetizione;
import ui.mngCompetizione.ProfiloMngCompetizione;
import ui.mngSistema.MenuMngSistema;
import ui.mngSistema.PrezzoOptional;
import ui.mngSistema.TipiCompetizione;
import ui.mngSistema.TipiOptional;
import ui.mngSistema.VediCompetizioni;
import ui.mngSistema.VediMngCompetizioni;
import ui.partecipante.CompetizioniDisponibili;
import ui.partecipante.ListaIscrizioni;
import ui.partecipante.MenuPartecipante;
import ui.partecipante.ModificaDatiPartecipante;
import ui.partecipante.ModificaOptionalScelti;
import ui.partecipante.NuovoPartecipante;
import ui.partecipante.ProfiloPartecipante;
import ui.partecipante.SelezioneOptional;

/**
 * Application Controller
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */

public class ApplicationController extends MainMenu{
	
	private static final long serialVersionUID = 1L;
	private SendMail sm;

	/**
	 * Menu principale
	 * @param frame
	 */
	public void menu(JFrame frame){
		Menu menu = new Menu();
		menu.setVisible(true);
		menu.setLocationRelativeTo(null);
	}

	/**
	 * Form di registrazione
	 * @param frame
	 */
	public void registrazione(JFrame frame){
		Registrazione reg = new Registrazione();
		reg.setVisible(true);
		reg.setLocationRelativeTo(null);
	}
	
	/**
	 * metodo per il login dell' utente
	 * @param frame
	 * @param par
	 */
	public void login(JFrame frame, ArrayList<Object> par){
		
		final int M_SISTEMA = 1;
		final int M_COMPETIZIONE = 2;
		final int PARTECIPANTE = 3;

		BusinessDelegate bd = new BusinessDelegate();
		try {
			int tipo = (int) bd.execute("login", par);

			switch(tipo){
			case 0:
				JOptionPane.showMessageDialog(null, "Username o Password errati.");
				openJFrame("menu");
				break;
			case M_SISTEMA:
				openJFrame("menuMngSistema");
				break;
			case M_COMPETIZIONE:
				openJFrame("menuMngCompetizione");
				break;
			case PARTECIPANTE:
				openJFrame("menuPartecipante");
				break;
			default:
				break;
			}	
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}

	}


	/*
	 * ------------ PARTECIPANTE ----------------
	 */

	/**
	 * Mostra il form di iscrizione di un nuovo partecipante
	 * @param frame
	 */
	public void nuovoPartecipante(JFrame frame){
		NuovoPartecipante nPart = new NuovoPartecipante();
		nPart.setVisible(true);
		nPart.setLocationRelativeTo(null);
	}
	
	/**
	 * Mostra il form di registrazione di un nuovo partecipante,
	 * nel caso in cui l'utente abbia inserito un username gi� esistente,
	 * mostrando ci� che l'utente ha gi� inserito, fatta eccezione per username
	 * e password.
	 * 
	 * @param frame
	 * @param p
	 */
	public void nuovoPartecipante(JFrame frame, ArrayList<Object> p){
		NuovoPartecipante nPart = new NuovoPartecipante(p);
		nPart.setVisible(true);
		nPart.setLocationRelativeTo(null);
	}

	/**
	 * Effettua la scrittura su db, restituendo un messaggio di avvenuta iscrizione.
	 * 
	 * @param frame
	 * @param par
	 */
	public void registrazionePartecipante(JFrame frame, ArrayList<Object> par){

		BusinessDelegate bd = new BusinessDelegate();
		String u = (String) par.get(11);
		
		try {
			boolean esiste = (boolean) bd.execute("esisteUsername", u);
			if(!esiste){
				bd.execute("registrazionePartecipante", par);
				JOptionPane.showMessageDialog(null, "Registrazione effettuata con successo.");
				
				sm = new SendMail();
				sm.registrazioneSistema((String) par.get(10), (String) par.get(11));
				openJFrame("menu");
			} else {
				JOptionPane.showMessageDialog(null, "L'username inserito esiste gi�.");
				openJFrame("nuovoPartecipante", par);
			}
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}

	}

	/**
	 * Mostra il menu del partecipante.
	 * 
	 * @param frame
	 */
	public void menuPartecipante(JFrame frame){
		MenuPartecipante mPart = new MenuPartecipante();
		mPart.setVisible(true);
		mPart.setLocationRelativeTo(null);
	}

	/**
	 * Mostra il profilo del partecipante
	 * 
	 * @param frame
	 * @param par
	 */
	@SuppressWarnings("unchecked")
	public void profiloPartecipante(JFrame frame){
		
		ArrayList<Object> lista = new ArrayList<Object>();
		BusinessDelegate bd = new BusinessDelegate();
		String c = null;

			try {
				
				lista = (ArrayList<Object>) bd.execute("profiloPartecipante", c);
				ProfiloPartecipante pPart = new ProfiloPartecipante(lista);
				pPart.setVisible(true);
				pPart.setLocationRelativeTo(null); 
				
			} catch (ClassNotFoundException e) {
				e.toString();
			} catch (InstantiationException e) {
				e.toString();
			} catch (IllegalAccessException e) {
				e.toString();
			} catch (NoSuchMethodException e) {
				e.toString();
			} catch (SecurityException e) {
				e.toString();
			}
	}

	/**
	 * Mostra il form di modifica del partecipante
	 * 
	 * @param frame
	 * @param par
	 */
	@SuppressWarnings("unchecked")
	public void modificaDatiPartecipante(JFrame frame){

		BusinessDelegate bd = new BusinessDelegate();
		ArrayList<Object> p = new ArrayList<Object>();
		String c = null;

		try {
			p = (ArrayList<Object>) bd.execute("modificaDatiPartecipante", c);

			ModificaDatiPartecipante modPart = new ModificaDatiPartecipante(p);
			modPart.setVisible(true);
			modPart.setLocationRelativeTo(null);
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
	}

	/**
	 * Scrive le modifiche su db restituendo un messaggio di registrazione 
	 * delle modifiche
	 * 
	 * @param frame
	 * @param par
	 */
	public void confermaModifichePart(JFrame frame, ArrayList<Object> par){

		BusinessDelegate bd = new BusinessDelegate();
		try {
			bd.execute("confermaModifichePart", par);
			JOptionPane.showMessageDialog(null, "Modifiche registrate con successo.");
			openJFrame("profiloPartecipante");
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}


	}

	/**
	 * mostra il form per la modifica della password
	 * @param frame
	 * @param p
	 */
	public void modificaPassword(JFrame frame, ArrayList<Object> p){

		ModificaPassword modPass = new ModificaPassword(p);
		modPass.setVisible(true);
		modPass.setLocationRelativeTo(null);
		
	}

	/**
	 * Aggiornamento password 
	 * @param frame
	 * @param p dettagli 
	 */
	public void aggiornaPassword(JFrame frame, ArrayList<Object> p){
		
		BusinessDelegate bd = new BusinessDelegate();
		String tipo = (String) p.get(2);
		
		try {
			ArrayList<Object> par = new ArrayList<Object>();
			
			String pAtt = (String) p.get(1);
			
			if(pAtt.compareTo((String) bd.execute("getPassword", tipo)) == 0){
			
				par.add(p.get(0).toString()); //password nuova
				par.add(tipo); //tipo di utente
				
				bd.execute("aggiornaPassword", par);
	
				JOptionPane.showMessageDialog(null, "Modifiche registrate con successo.");
	
				if(tipo.compareTo("Partecipanti") == 0){
					openJFrame("menuPartecipante"); 
				}else if(tipo.compareTo("ManagerCompetizione") == 0){
					openJFrame("menuMngCompetizione"); 
				}

			}else{
				JOptionPane.showMessageDialog(null, "Controlla password attuale");
				openJFrame("modificaPassword");
			}
		} catch (ClassNotFoundException e1) {
			e1.toString();
		} catch (InstantiationException e1) {
			e1.toString();
		} catch (IllegalAccessException e1) {
			e1.toString();
		} catch (NoSuchMethodException e1) {
			e1.toString();
		} catch (SecurityException e1) {
			e1.toString();
		}

	}

	/**
	 * Mostra la lista delle competizioni disponibili a cui un partecipante pu�
	 * iscriversi
	 * 
	 * @param frame
	 */
	@SuppressWarnings("unchecked")
	public void competizioniDisponibili(JFrame frame){

		ArrayList<ArrayList<Object>> lista = new ArrayList<ArrayList<Object>>();
		BusinessDelegate bd = new BusinessDelegate();
		String c = null;

		try {
			lista = (ArrayList<ArrayList<Object>>) bd.execute("leggiCompetizioni", c);
			ArrayList<Object> t = new ArrayList<Object>();

			t.add(bd.execute("getDataSRC", c));
			lista.add(t);
			
			CompetizioniDisponibili compDisp = new CompetizioniDisponibili(lista);
			compDisp.setVisible(true);
			compDisp.setLocationRelativeTo(null);
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}


	}

	/**
	 * Estrae i dettagli degli optional
	 * 
	 * @param frame
	 * @param par 
	 */
	@SuppressWarnings("unchecked")
	public void selezioneOptional(JFrame frame, ArrayList<Object> par){

		BusinessDelegate bd = new BusinessDelegate();
		ArrayList<ArrayList<Object>> opt = new ArrayList<ArrayList<Object>>();

		try {			
			opt = (ArrayList<ArrayList<Object>>) bd.execute("leggiOptional", par);
			SelezioneOptional selOpt = new SelezioneOptional(opt);
			selOpt.setVisible(true);
			selOpt.setLocationRelativeTo(null);
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}


	}

	/**
	 * Legge gli optional scelti 
	 * 
	 * @param frame
	 * @param par
	 */
	@SuppressWarnings("unchecked")
	public void leggiOptionalScelti(JFrame frame, ArrayList<Object> par){
		
		BusinessDelegate bd = new BusinessDelegate();
		ArrayList<ArrayList<Object>> opt = new ArrayList<ArrayList<Object>>();
		
		try {
			opt = (ArrayList<ArrayList<Object>>) bd.execute("leggiOptionalScelti", par);
			ModificaOptionalScelti modOptScelti = new ModificaOptionalScelti(opt);
			modOptScelti.setVisible(true);
			modOptScelti.setLocationRelativeTo(null);
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
			
	}
	
	/**
	 * Modifica degli optional scelti per una competizione da parte di un 
	 * partecipante
	 * 
	 * @param frame
	 * @param par
	 */
	@SuppressWarnings("unchecked")
	public void modificaOptionalScelti(JFrame frame, ArrayList<Object> par){
		
		BusinessDelegate bd = new BusinessDelegate();
		try {
			bd.execute("modificaOptionalSceltiP", par);
			
			String id = String.valueOf(par.get(0)); //id della competizione
			String mail = (String) bd.execute("getMailMng", id);
			
			ArrayList<Object> c = new ArrayList<Object>();
			c = (ArrayList<Object>) bd.execute("ottieniCompetizione", id);
			
			sm = new SendMail();
			sm.modificaOptionalPart(mail, c);
			
			JOptionPane.showMessageDialog(null, "Modifiche registrate con successo.");
			openJFrame("menuPartecipante");
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
	}


	/**
	 * Scrive su db l'iscrizione a una competizione.
	 * 
	 * @param frame
	 * @param par
	 */
	@SuppressWarnings("unchecked")
	public void confermaIscrizione(JFrame frame, ArrayList<Object> par){

		BusinessDelegate bd = new BusinessDelegate();
		try {
			String u = (String) bd.execute("iscrizioneCompetizione", par);
			ArrayList<Object> p = new ArrayList<Object>();
			p.add(u);
			p.add("ManagerCompetizione");
			String mail = (String) bd.execute("getMail", p);
			
			String id = String.valueOf(par.get(0));
			
			ArrayList<Object> c = new ArrayList<Object>();
			c = (ArrayList<Object>) bd.execute("ottieniCompetizione", id);
			
			sm = new SendMail();
			sm.confermaIscrizione(mail, c);
			
			JOptionPane.showMessageDialog(null, "Iscrizione effettuata con successo.");
			openJFrame("menuPartecipante");
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}

	}

	/**
	 * Mostra la lista delle competizioni a cui un partecipante � iscritto
	 * 
	 * @param frame
	 */
	@SuppressWarnings("unchecked")
	public void listaIscrizioni(JFrame frame){

		ArrayList<ArrayList<Object>> lista = new ArrayList<ArrayList<Object>>();
		BusinessDelegate bd = new BusinessDelegate();
		String c = null;

		try {
			lista = (ArrayList<ArrayList<Object>>) bd.execute("leggiIscrizioni", c);

			ListaIscrizioni listaIscr = new ListaIscrizioni(lista);
			listaIscr.setVisible(true);
			listaIscr.setLocationRelativeTo(null);

		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}		

	}

	/**
	 * Eliminazione iscrizione 
	 * 
	 * @param frame
	 * @param p dettagli 
	 */
	@SuppressWarnings("unchecked")
	public void eliminaIscrizione(JFrame frame, ArrayList<Object> p){

		BusinessDelegate bd = new BusinessDelegate();
		try {
			bd.execute("eliminaIscrizione", p);
			
			String id = String.valueOf(p.get(0));
			
			ArrayList<Object> c = new ArrayList<Object>();
			c = (ArrayList<Object>) bd.execute("ottieniCompetizione", id);
			
			String mail = (String) bd.execute("getMailMng", id);
			
			sm = new SendMail();
			sm.eliminaIscrizione(mail, c);
			
			JOptionPane.showMessageDialog(null, "Cancellazione avvenuta con successo.");
			openJFrame("listaIscrizioni");
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}

	}

	/*
	 * ------------ MANAGER COMPETIZIONE -----------
	 */
	
	/**
	 * Mostra il form di registrazione di un nuovo manager di competizione
	 * 
	 * @param frame
	 */
	public void nuovoMngCompetizione(JFrame frame){
		NuovoMngCompetizione nMngCom = new NuovoMngCompetizione();
		nMngCom.setVisible(true);
		nMngCom.setLocationRelativeTo(null);
	}
	
	/**
	 * Mostra il form di registrazione di un nuovo manager di competizione,
	 * nel caso in cui l'utente abbia inserito un username gi� esistente,
	 * mostrando ci� che l'utente ha gi� inserito, fatta eccezione per username
	 * e password.
	 * 
	 * @param frame
	 * @param p
	 */
	public void nuovoMngCompetizione(JFrame frame, ArrayList<Object> p){
		NuovoMngCompetizione nMngCom = new NuovoMngCompetizione(p);
		nMngCom.setVisible(true);
		nMngCom.setLocationRelativeTo(null);
	}
	
	/**
	 * Registrazione manager competizione
	 * 
	 * @param frame
	 * @param p
	 */
	public void registrazioneMngCompetizione(JFrame frame, ArrayList<Object> p){
		
		BusinessDelegate bd = new BusinessDelegate();
		String u = (String) p.get(3);
		
		try {
			boolean esiste = (boolean) bd.execute("esisteUsername", u);
			if(!esiste){
				bd.execute("registrazioneMngCompetizione", p);
				sm = new SendMail();
				sm.registrazioneSistema((String)p.get(2), (String) p.get(3));
				JOptionPane.showMessageDialog(null, "Registrazione effettuata con successo.");
				openJFrame("menu");
			} else {
				JOptionPane.showMessageDialog(null, "L'username inserito esiste gi�.");
				openJFrame("nuovoMngCompetizione", p);
			}
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
	}

	/**
	 * menu manager competiizone
	 * @param frame
	 */
	public void menuMngCompetizione(JFrame frame){
		MenuMngCompetizione mMngComp = new MenuMngCompetizione();
		mMngComp.setVisible(true);
		mMngComp.setLocationRelativeTo(null);
	}

	/**
	 * Profilo manager competizione
	 * @param frame
	 */
	@SuppressWarnings("unchecked")
	public void profiloMngCompetizione(JFrame frame){
		
		ArrayList<Object> lista = new ArrayList<Object>();
		BusinessDelegate bd = new BusinessDelegate();
		String c = null;
		
		try {
			lista = (ArrayList<Object>) bd.execute("profiloMngCompetizione", c);
			
			ProfiloMngCompetizione pMngComp = new ProfiloMngCompetizione(lista);
			pMngComp.setVisible(true);
			pMngComp.setLocationRelativeTo(null);
				
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}

	}

	/**
	 * Modifica profilo manager competizione 
	 * @param frame
	 */
	@SuppressWarnings("unchecked")
	public void modificaDatiManager(JFrame frame){
		
		BusinessDelegate bd = new BusinessDelegate();
		ArrayList<Object> lista = new ArrayList<Object>();
		String c = null;
		
		try {
			//provo a sfruttare lo stesso di profilo mng
			lista = (ArrayList<Object>) bd.execute("profiloMngCompetizione", c);

			ModificaDatiManager modMngComp = new ModificaDatiManager(lista);
			modMngComp.setVisible(true);
			modMngComp.setLocationRelativeTo(null);
			
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
	}
	
	/**
	 * Scrive le modifiche su db
	 * @param frame
	 * @param mng
	 */
	public void confermaModificheMng(JFrame frame, ArrayList<Object> mng){
		
		BusinessDelegate bd = new BusinessDelegate();
		
		try {
			bd.execute("confermaModificheMng", mng);
			JOptionPane.showMessageDialog(null, "Modifiche registrate con successo.");
			openJFrame("menuMngCompetizione");
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
	}

	/**
	 * Aggiunge una nuova competizione 
	 * 
	 * @param frame 
	 */
	@SuppressWarnings("unchecked")
	public void nuovaCompetizione(JFrame frame){

		BusinessDelegate bd = new BusinessDelegate();
		ArrayList<Object> tipiComp = new ArrayList<Object>();
		String c = null;

		try {
			tipiComp = (ArrayList<Object>) bd.execute("leggiTipiCompetizione", c);
			AggiungiCompetizione aggComp = new AggiungiCompetizione(tipiComp);
			aggComp.setVisible(true);
			aggComp.setLocationRelativeTo(null);
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}

	}

	/**
	 * Inserisce la competizione 
	 * 
	 * @param frame
	 * @param par
	 */
	public void inserisciCompetizione(JFrame frame, ArrayList<Object> par){

		BusinessDelegate bd = new BusinessDelegate();
		try {
			bd.execute("inserisciCompetizione", par);
			JOptionPane.showMessageDialog(null, "Competizione aggiunta con successo.");
			openJFrame("menuMngCompetizione");
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}

	}

	/**
	 * Mostra le comeptizioni gestite
	 * @param frame
	 */
	@SuppressWarnings("unchecked")
	public void competizioniGestite(JFrame frame){

		BusinessDelegate bd = new BusinessDelegate();
		ArrayList<ArrayList<Object>> lista = new ArrayList<ArrayList<Object>>();
		String c = null;
		
		try {
			
			lista = (ArrayList<ArrayList<Object>>) bd.execute("competizioniGestite", c);
			CompetizioniGestite compGest = new CompetizioniGestite(lista);
			compGest.setVisible(true);
			compGest.setLocationRelativeTo(null);
			
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
	}

	/**
	 * Mostra la lista dei partecipanti
	 * @param frame
	 * @param p
	 */
	@SuppressWarnings("unchecked")
	public void listaPartecipanti(JFrame frame, ArrayList<Object> p){
		
		BusinessDelegate bd = new BusinessDelegate();
		ArrayList<ArrayList<Object>> listaPart = new ArrayList<ArrayList<Object>>();
		
		String id = String.valueOf(p.get(0));
		
		try {
			
			listaPart = (ArrayList<ArrayList<Object>>) bd.execute("listaPartecipanti", id);
			
			ListaPartecipanti listPart = new ListaPartecipanti(listaPart);
			listPart.setVisible(true);
			listPart.setLocationRelativeTo(null);
			
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
		
	}
	
	/**
	 * Annulla una competizione 
	 * @param frame
	 * @param par
	 */
	@SuppressWarnings("unchecked")
	public void annullaCompetizione(JFrame frame, ArrayList<Object> par){
		
		BusinessDelegate bd = new BusinessDelegate();
		String idComp = String.valueOf(par.get(0));
		
		try {
			bd.execute("annullaCompetizione", par);
			
			
			ArrayList<Object> mailList = new ArrayList<Object>();
			mailList = (ArrayList<Object>) bd.execute("getMailList", idComp);

			ArrayList<Object> competizione = new ArrayList<Object>();
			competizione = (ArrayList<Object>) bd.execute("ottieniCompetizione", idComp);
			
			sm = new SendMail();
			sm.annullaCompetizione(mailList, competizione);
			
			JOptionPane.showMessageDialog(null, "Competizione annullata.");
			openJFrame("competizioniGestite");
			
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
	}
	
	/**
	 * Legge gli optional scelti da un partecipante 
	 * @param frame
	 * @param p
	 */
	@SuppressWarnings("unchecked")
	public void vediOptionalPartecipante(JFrame frame, ArrayList<Object> p){
		
		BusinessDelegate bd = new BusinessDelegate();
		ArrayList<ArrayList<Object>> opt = new ArrayList<ArrayList<Object>>();
		
		try {
			opt = (ArrayList<ArrayList<Object>>) bd.execute("vediOptionalPartecipante", p);
			
			ModificaOptionalPartecipante modOptPart = new ModificaOptionalPartecipante(opt);
			modOptPart.setVisible(true);
			modOptPart.setLocationRelativeTo(null);
			
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
	}
	
	/**
	 * Modifica gli optional scelti da un partecipanet 
	 * @param frame
	 * @param par
	 */
	@SuppressWarnings("unchecked")
	public void modificaOptionalPartecipante(JFrame frame, ArrayList<Object> par){
		
		BusinessDelegate bd = new BusinessDelegate();
		try {
			bd.execute("modificaOptionalSceltiM", par);
			
			String id = String.valueOf(par.get(0));
			ArrayList<Object> c = new ArrayList<Object>();
			c = (ArrayList<Object>) bd.execute("ottieniCompetizione", id);
			
			ArrayList<Object> p = new ArrayList<Object>();
			String u = (String) par.get(1);
			p.add(u);
			p.add("Partecipanti");
			String mail = (String) bd.execute("getMail", p);
			
			sm = new SendMail();
			sm.modificaOptionalMng(mail, c);
			
			JOptionPane.showMessageDialog(null, "Modifiche registrate con successo.");
			openJFrame("menuMngCompetizione");
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
	}
	
	/**
	 * Ottiene la competizione
	 * @param frame
	 * @param p
	 */
	@SuppressWarnings("unchecked")
	public void ottieniCompetizione(JFrame frame, ArrayList<Object> p){
		
		ArrayList<Object> competizione = new ArrayList<Object>();
		BusinessDelegate bd = new BusinessDelegate();
		String id = (String) String.valueOf(p.get(0));
		
		try {
			competizione = (ArrayList<Object>) bd.execute("ottieniCompetizione", id);
			ModificaCompetizione modComp = new ModificaCompetizione(competizione);
			modComp.setVisible(true);
			modComp.setLocationRelativeTo(null);
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
	}
	
	/**
	 * Modifica la competizione 
	 * @param frame
	 * @param c
	 */
	@SuppressWarnings("unchecked")
	public void modificaCompetizione(JFrame frame, ArrayList<Object> c){
		
		BusinessDelegate bd = new BusinessDelegate();
		String id = String.valueOf(c.get(0));
		
		try {
			
			bd.execute("modificaCompetizione", c);
			
			ArrayList<Object> mailList = new ArrayList<Object>();
			mailList = (ArrayList<Object>) bd.execute("getMailList", id);

			ArrayList<Object> competizione = new ArrayList<Object>();
			competizione = (ArrayList<Object>) bd.execute("ottieniCompetizione", id);
			
			int n = (int) bd.execute("getNumIscritti", id);
			int nMax = (int) competizione.get(4);
			
			ArrayList<Object> partElim = new ArrayList<Object>();
			
			if(n > nMax){
				ArrayList<Object> d = new ArrayList<Object>();
				d.add(id); // id della competizione
				d.add(nMax); //numero max partecipanti
				
				//faccio restituire arraylist con lista mail dei partecipanti eliminati
				partElim = (ArrayList<Object>) bd.execute("riduciPartecipanti", d); 
			}
			
			sm = new SendMail();
			sm.modificaCompetizione(mailList, competizione);
			sm.eliminaPartecipanteMng(partElim, competizione);
			
			JOptionPane.showMessageDialog(null, "Modifiche registrate con successo.");
			
			openJFrame("menuMngCompetizione");
			
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
	}

	/**
	 * Cancella un partecipante da una competizione
	 * @param frame
	 * @param p
	 */
	@SuppressWarnings("unchecked")
	public void eliminaPartecipante(JFrame frame, ArrayList<Object> p){
		
		BusinessDelegate bd = new BusinessDelegate();
		
		try {
			bd.execute("eliminaIscrizione", p);
			JOptionPane.showMessageDialog(null, "Partecipante eliminato con successo.");
			
			String id = String.valueOf(p.get(0));
			ArrayList<Object> c = new ArrayList<Object>();
			c = (ArrayList<Object>) bd.execute("ottieniCompetizione", id);
			
			ArrayList<Object> par = new ArrayList<Object>();
			String u = (String) p.get(1);
			par.add(u);
			par.add("Partecipanti");
			ArrayList<Object> mail = new ArrayList<Object>();
			mail.add((String) bd.execute("getMail", par));
			
			sm = new SendMail();
			sm.eliminaPartecipanteMng(mail, c);
			
			openJFrame("listaPartecipanti", p);
			
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
	}
	
	
	// ------------ MANAGER DI SISTEMA ---------------
	/**
	 * Menu del mng sistema 
	 * @param frame
	 */
	public void menuMngSistema(JFrame frame){
		MenuMngSistema mMngSist = new MenuMngSistema();
		mMngSist.setVisible(true);
		mMngSist.setLocationRelativeTo(null);
	}

	/**
	 * Mostra tutte le competizioni 
	 * @param frame
	 */
	@SuppressWarnings("unchecked")
	public void vediCompetizioni(JFrame frame){
		
		ArrayList<ArrayList<Object>> listaComp = new ArrayList<ArrayList<Object>>();
		BusinessDelegate bd = new BusinessDelegate();
		String c = null;
		
		try {
			
			listaComp = (ArrayList<ArrayList<Object>>) bd.execute("vediCompetizioni", c);
			VediCompetizioni vediComp = new VediCompetizioni(listaComp);
			vediComp.setVisible(true);
			vediComp.setLocationRelativeTo(null);
			
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
		
	}

	/**
	 * Mostra i manager di competizione 
	 * @param frame
	 */
	@SuppressWarnings("unchecked")
	public void vediMngCompetizioni(JFrame frame){
		
		BusinessDelegate bd = new BusinessDelegate();
		ArrayList<ArrayList<Object>> mng = new ArrayList<ArrayList<Object>>();
		String c = null;
		
		try {
			mng = (ArrayList<ArrayList<Object>>) bd.execute("vediMngCompetizioni", c);
			
			VediMngCompetizioni vediMngComp = new VediMngCompetizioni(mng);
			vediMngComp.setVisible(true);
			vediMngComp.setLocationRelativeTo(null);
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
		
	}

	/**
	 * Modifica il prezzo degli optional 
	 * @param frame
	 */
	@SuppressWarnings("unchecked")
	public void modPrezzoOptional(JFrame frame){
		
		ArrayList<Object> lista = new ArrayList<Object>();
		BusinessDelegate bd = new BusinessDelegate();
		String c = null;
		
		try {
			lista = (ArrayList<Object>) bd.execute("getPrezzi", c);
			PrezzoOptional przOpt = new PrezzoOptional(lista);
			przOpt.setVisible(true);
			przOpt.setLocationRelativeTo(null);
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
		
	}

	/**
	 * Mostra i tipi di competizione
	 * @param frame
	 */
	@SuppressWarnings("unchecked")
	public void gestioneCompetizioni(JFrame frame){
		
		BusinessDelegate bd = new BusinessDelegate();
		ArrayList<Object> lista = new ArrayList<Object>();
		String c = null;
		
		try {
			lista = (ArrayList<Object>) bd.execute("leggiTipiCompetizione", c);
			TipiCompetizione tipiComp = new TipiCompetizione(lista);
			tipiComp.setVisible(true);
			tipiComp.setLocationRelativeTo(null);
			
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
		
	}

	/**
	 * Mostra i tipi di optional 
	 * @param frame
	 */
	@SuppressWarnings("unchecked")
	public void gestioneOptional(JFrame frame){
		
		BusinessDelegate bd = new BusinessDelegate();
		ArrayList<ArrayList<Object>> lista = new ArrayList<ArrayList<Object>>();
		String c = null;
		
		try {
			lista = (ArrayList<ArrayList<Object>>) bd.execute("dettagliOptional", c);
			TipiOptional tipiOpt = new TipiOptional(lista);
			tipiOpt.setVisible(true);
			tipiOpt.setLocationRelativeTo(null);
			
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
	}
	
	/**
	 * Modifica il prezzo degli optional 
	 * @param frame
	 * @param p
	 */
	@SuppressWarnings("unchecked")
	public void confermaPrezzoOptional(JFrame frame, ArrayList<Object> p){
		
		BusinessDelegate bd = new BusinessDelegate();
		try {
			bd.execute("confermaPrezzoOptional", p);
			JOptionPane.showMessageDialog(null, "Modifiche registrate con successo.");
			
			ArrayList<Object> mail = new ArrayList<Object>();
			mail = (ArrayList<Object>) bd.execute("getMailList", "codiceCompetizione");
			
			sm = new SendMail();
			sm.prezzoOptional(mail);
			
			openJFrame("menuMngSistema");
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
	}
	
	/**
	 * Elimina un tipo di competizione 
	 * @param frame
	 * @param p
	 */
	public void eliminaTipoComp(JFrame frame, ArrayList<Object> p){
		
		BusinessDelegate bd = new BusinessDelegate();
		String c = p.get(0).toString();
		try {
			bd.execute("eliminaTipoComp", c);
			JOptionPane.showMessageDialog(null, "Tipo di competizione cancellato con successo.");
			openJFrame("gestioneCompetizioni");
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
	}
	
	/**
	 * Aggiunge un tipo di competizione 
	 * @param frame
	 * @param p
	 */
	public void aggiungiTipoCompetizione(JFrame frame, ArrayList<Object> p){
		
		BusinessDelegate bd = new BusinessDelegate();
		String c = p.get(0).toString();
		try {
			bd.execute("aggiungiTipoCompetizione", c);
			JOptionPane.showMessageDialog(null, "Tipo di competizione aggiunto con successo.");
			openJFrame("gestioneCompetizioni");
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
	}

}
