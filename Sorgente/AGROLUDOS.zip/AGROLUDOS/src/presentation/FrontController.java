package presentation;

import java.lang.reflect.Method;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.JFrame;

import utility.XMLReader;

/**
 * Front Controller
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class FrontController {

	private Object result;
	
	/**
	 * Elabora la richiesta dalle ui
	 * 
	 * @param key il metodo da richiamare
	 * @param frame la finestra 
	 * @param par l'eventuale parametro 
	 * @return l'oggeto prestabilito
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 */
	public Object processRequest(String key, JFrame frame, ArrayList<Object> par) 
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, 
			NoSuchMethodException, SecurityException {
		
		String metodo;
		String classe;
		String path;
		
		path = "/xml/FC.xml";
		
		URL url = FrontController.class.getResource(path);
		
		XMLReader xml = new XMLReader(url);
		ArrayList<String> parametri = xml.leggiParametri(key);
		
		if (frame != null) {
			
			//classe e metodo presi dal file xml
			
			classe = parametri.get(0).toString();
			metodo = parametri.get(1).toString();
			
			//trovo la classe
			
			Class<?> c = Class.forName(classe);
			Object o = c.newInstance();
			
			if(par != null){
				
				//estraggo le informazioni del metodo in m
				
				Method m = c.getDeclaredMethod(
								metodo, 
								frame.getClass(), 
								par.getClass()
								);
				//ottengo il tipo restituito dal metodo m
				
				Class<?> returnType = m.getReturnType();
				
				//rende il metodo accessibile perch� sia invocabile
				
				m.setAccessible(true);
				
				try {
					
					if(returnType != Void.TYPE){
						result = returnType.newInstance();
					}
					result = m.invoke(o, frame, par);
					return result;
					
				} catch(Exception e) {
					e.toString();
				}
				
			} else if(par == null) {
				
				//estraggo le informazioni del metodo in m
				
				Method m = c.getDeclaredMethod(
								metodo, 
								frame.getClass()
								);
				
				//ottengo il tipo restituito dal metodo m
				
				Class<?> returnType = m.getReturnType();
				
				//rende il metodo accessibile perch� sia invocabile
				m.setAccessible(true);
				
				try {

					if(returnType != Void.TYPE){
						result = returnType.newInstance();
					}
					result = m.invoke(o, frame);
					return result;
					
				} catch(Exception e){
					e.toString();				
				}
			}
		}
		return null;
	}
}