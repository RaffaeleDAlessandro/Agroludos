package test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import utility.ControlloDati;
/**
 * La classe junit effettua i casi di test per la classe agroludos.utility.ControlloDati
 * @author Raffaele D' Alessandro , Marco Dispoto
 *
 */
public class ControlloDatiTest {
	//	ControlloDati check; 

	/**
	 * CFcases contiene i casi di test relativi al codice fiscale inserito dal
	 * partecipante
	 */
	String[] CFcases = { "0000000000000000", "101010101010101",
			"SCVCRN91D53A662K", "aaaaaaaaaaaaaaaa", "AAAA1234RD567ZZZZ", 
			"DDDDDD22D22D222D", "asv", ".�+�casfaf", "1111111111111111", ""};

	boolean[] CFexpected = { false, false, true, false, false, true, false, false, false, false};


	/**
	 * NTCases contiene i casi di test relativi al numero di tessera sanitaria
	 */
	String[] NTcases = { "1111111112223344556", "56942555415423000619",
			"320001456621485300149", "11111111111111111111", 
			"22222222222222222222", "", 
			"00000000000000000000", "99999999999999999999", 
			"aaaaaaaaaaaaaaaaaaaa", "zzzzzzzzzzzzzzzzzzzz",
	"1111111111111111111�" };

	boolean[] NTexpected = { false, true, false, true, true, false, true, true, false, false, false};

	/**
	 * 
	 */


	String [][] RIcases={
			{
				"Bari", "Torino", "Rutigliano", "Conversano", "Alberobello", "Sammichele", "Molfetta", "Modugno", ""
			},
			{
				"Via Napoli, n�15", "via Obama ", "Piazzza del Pesce ", "largo MAre",
				"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "�.�", "", 
				"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Via roma"
			}
	};

	boolean []RIexpected={
			true, true, true, true, true, false, false, true, false 
	};



	/**
	 * emailCases contiene i casi di test relativi alle email che vengono
	 * registrate al sistema
	 */
	String[] emailCases = { "katia.sc@hotmail.it", "faby_b93@hotmail.it",
			"dalessandroraffaele@gmail.com", "scavokatia@gmail.com", 
			"marcodispoto@gmail.com", "giuseppennloconosco@hotmail.it" };

	boolean[] emailExpected = { true, true, true, true, true, true };


	/**
	 * CognomeCases contiene i casi di test relativi ai cognomi che vengono
	 *  registrati al sistema
	 */
	String []CognomeCases={"Dispoto", "D' Alessandro", "Girolamo", "Visaggio" , "E�aro", "", "cadol1", "Orso32", "aaaaaaaaaaaaaaaaaaaa"};
	boolean[]CognomeExpected = { true, true, true, true, true, false, false, false, true};	

	/**
	 * nameCases contiene i casi di test sul nome
	 */
	String[] nameCases = { "Anna", "Zanzi", "aqaa", "zzzz", 
			"aaaaaaaaaaaaaaaaaaa"
			,"aaaaaaaaaaaaa",
			"AnnaMariaAngelicaAda", "�����ccacds", 
			"cadvf ovnfin", "vaonfo fnvsfnvisfdv", "43v", "cc", "" , "vav", "zz", "z", ", c" };

	boolean[] nameExpected = { true, true, true, true, true, true, true, true, true, true ,
			false, false, false, false, false, false, false, false};

	/**
	 * PasswordCAses contiene i casi di test per confrontare la password
	 */
	String [][] PasswordCases={
			{
				"raffaele", "ciao", "Non lo so", "amore", "gioia", "canottaggio", "aa", "ccaaaa"
			}, 
			{
				"raffaele", "ciao", "Non lo so", "amore", "gioia", "canottaggio", "aaaa", "caaaa"
			}
	};
	boolean[] PassrowConfExpected = { true, true, true, true, true, true, false, false};


	/**
	 * NPartCases contiene i casi di test per cotrollare il numero minimo e massimo di partecipanti
	 *  @throws Exception
	 */
	String [][] NPartCases={
			{
				"2", "7", "32", "43", "10", "3",
				"3", "1111", "vvdfv", "22"
			}
			,
			{
				"3", "10", "44", "44", "11", "10", 
				"2", "2222", "vfdvf", "1@"
			}
	};

	boolean []NPartExpected={true, true, true, true, true, 
			true, false, true, false, false};


	/**
	 * priceCases contiene i casi di test relativi al costo delle competizioni e
	 * degli optional
	 */
	String[] priceCases = { "1", "30.00", "0", "-12.3", "4.00", "5.25", "1.99" };

	boolean[] priceExpected = { true, true, false, false, true, true, true };


	/**
	 * TipoCases contiene i casi di test relativi ai tipi di competizione
	 * @throws Exception
	 */
	String [] tipoCases={
			"calcio", "pallavolo", "spinning", "boxe", "aaaaaaaaaaaaaaa"	, 
			"AAAAAAAAAAAAAAAAAAA", "ZZZZZZZZZZZZZZZZZZZ", 
	};
	boolean[] tipoExpected={
			true, true , true, true, true, true, true, 	
	};

	@Before
	public void setUp() throws Exception {
		//		check=new ControlloDati();
	}

	@After
	public void tearDown() throws Exception {
		//		check =null;
	}

	@Test
	public void test() {
		// testa i nomi
				for (int i = 0; i < nameCases.length; i++) {
					String nameCase = nameCases[i];
					boolean result = ControlloDati.controllaNome(nameCase);
					boolean expected = nameExpected[i];
					assertEquals("CASE: " + nameCase + ", RESULT: " + result
							+ ", EXPECTED: " + expected, result, expected);
				}

				//testa i codici fiscali
				
				for (int i = 0; i < CFcases.length; i++) {
					String CFcase = CFcases[i];
					boolean result = ControlloDati.controllaCF(CFcase);
					boolean expected = CFexpected[i];
					assertEquals("CASE: " + CFcase + ", RESULT: " + result
							+ ", EXPECTED: " + expected, result, expected);
				}
				


		// testa i numeri di tessera
				for (int i = 0; i < NTcases.length; i++) {
					String NTcase = NTcases[i];
					boolean result = ControlloDati.controllaTS(NTcase);
					boolean expected = NTexpected[i];
					assertEquals("CASE: " + NTcase + ", RESULT: " + result
							+ ", EXPECTED: " + expected, result, expected);
				}

		//testa la residenza e gli indirizzi
				for (int i = 7; i < RIcases[1].length; i++) {
		
					String NTcaseResidenza = RIcases[0][i];
					String NTcaseIndirizzo = RIcases[1][i];
					boolean result = ControlloDati.controllaResidenzaeIndirizzo(NTcaseResidenza, NTcaseIndirizzo);
					boolean expected = RIexpected[i];
					assertEquals("CASE: " + NTcaseResidenza + ", RESULT: " + result
							+ ", EXPECTED: " + expected, result, expected);
				
				}

		// testa gli indirizzi e-mail
				for (int i = 0; i < emailCases.length; i++) {
					String emailCase = emailCases[i];
					boolean result = ControlloDati.controllaEmail(emailCase);
					boolean expected = emailExpected[i];
					assertEquals("CASE: " + emailCase + ", RESULT: " + result
							+ ", EXPECTED: " + expected, result, expected);
				}

		// testa gli indirizzi cognome
						for (int i = 0; i < CognomeCases.length; i++) {
							String CognomeCase = CognomeCases[i];
							boolean result = ControlloDati.controllaCognome(CognomeCase);
							boolean expected = CognomeExpected[i];
							assertEquals("CASE: " + CognomeCase + ", RESULT: " + result
									+ ", EXPECTED: " + expected, result, expected);
						}

		//testa il metodo per controllare i confronto della password e password di conferma
						for (int i = 0; i < PasswordCases[1].length; i++) {
							String PConCase1 = PasswordCases[0][i];
							String PConCase2 = PasswordCases[1][i];
							boolean result = ControlloDati.confrontoPass(PConCase1, PConCase2 );
							boolean expected = PassrowConfExpected[i];
							assertEquals("CASE: " + PConCase1 + ", RESULT: " + result
									+ ", EXPECTED: " + expected, result, expected);
						System.out.println(i);
						}


		//testa il metodo per controllare il numero minimo e massimo partecipanti
				for (int i = 0; i < NPartCases[1].length; i++) {
					String NaPaCase1 = NPartCases[0][i];
					String NaCaCase2 = NPartCases[1][i];
					boolean result = ControlloDati.controllaNumPartecipanti(NaPaCase1, NaCaCase2 );
					boolean expected = NPartExpected[i];
					assertEquals("CASE: " + NaPaCase1 + ", RESULT: " + result
							+ ", EXPECTED: " + expected, result, expected);
					System.out.println(i);
				}

		//testa il metodo per controllare il prezzo
				for (int i = 0; i < NPartCases[1].length; i++) {
					String NaPaCase1 = NPartCases[0][i];
					String NaCaCase2 = NPartCases[1][i];
					boolean result = ControlloDati.controllaNumPartecipanti(NaPaCase1, NaCaCase2 );
					boolean expected = NPartExpected[i];
					assertEquals("CASE: " + NaPaCase1 + ", RESULT: " + result
							+ ", EXPECTED: " + expected, result, expected);
					System.out.println(i);
				}

		// testa il prezzo
		for (int i = 0; i < priceCases.length; i++) {
			String priceCase = priceCases[i];
			boolean result = ControlloDati.controllaPrezzo(priceCase);
			boolean expected = priceExpected[i];
			assertEquals("CASE: " + priceCase + ", RESULT: " + result
					+ ", EXPECTED: " + expected, result, expected);
		}

		//testa il tipo di competizione
		for (int i = 0; i < tipoCases.length; i++) {
			String tipoCase = tipoCases[i];
			boolean result = ControlloDati.controlloTipo(tipoCase);
			boolean expected = tipoExpected[i];
			assertEquals("CASE: " + tipoCase + ", RESULT: " + result
					+ ", EXPECTED: " + expected, result, expected);
		}
		
	}

}
