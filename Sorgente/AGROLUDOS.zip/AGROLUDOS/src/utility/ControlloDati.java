package utility;

import java.util.Calendar;
import java.util.Date;

import javax.swing.JOptionPane;


/**
 * CLASSE PER IL CONTROLLO DEI DATI DI REGISTRAZIONE E MODIFICA
 * @author Raffaele D'Alessandro, Marco Dispoto
 *
 */
public class ControlloDati {

	/**
	 * metodo per il controllo dell' username per il login
	 * @param username
	 * @return true se compreso tra 4 e 15, false altrimenti
	 */
	public static boolean controlloUserName(String username){

		if(username.matches("[a-zA-Z0-9]{5,15}")){
			return true;
		}
		JOptionPane.showMessageDialog(null, "Controlla username",
				"ERRORE",
				JOptionPane.ERROR_MESSAGE);
		return false;
	}

	/**
	 * metodo per il controllo della password per il login
	 * @param password
	 * @return true se compreso tra 5 e 15, false altrimenti
	 */
	public static boolean controlloPassword(String password){
		if(!(password.matches("[a-zA-Z0-9]{5,15}"))){
			JOptionPane.showMessageDialog(null, "Controlla password",
					"ERRORE",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}else{
			return true;
		}
	}

	/**
	 * metodo per il controllo della data.
	 * @param data
	 * @return true se la data � precedente alla data odierna
	 */
	public static boolean controllaData(Date data) {
		
		Calendar oggi = Calendar.getInstance();
		Calendar date = Calendar.getInstance();
		date.setTime(data);
		
		if(date != null){
			if (oggi.after(date)) {
				return true; // buon fine
			}
		}
		JOptionPane.showMessageDialog(null, "Controlla data di nascita",
				"ERRORE",
				JOptionPane.ERROR_MESSAGE);
		return false;

	}

	/**
	 * metodo per il controllo della data di rilascio certificato SRC
	 * @param dataSRC data rilascio certificato src
	 * @param dataN data nascita
	 * @return true se data nascita � precedente a data rilascio SRC, falso altrimenti
	 */
	public static boolean controlloDataSRC(Date dataSRC, Date dataN){
		if(dataSRC!=null && dataN!=null){
			if(dataSRC.after(dataN)){
				return true;
			}
		}
		JOptionPane.showMessageDialog(null, "Controlla data di rilascio SRC",
				"ERRORE",
				JOptionPane.ERROR_MESSAGE);
		return false;
	}

	/**
	 * metodo per il controllo del codice fiscale. controlla se nelle posizioni ci sono lettero o cifre
	 * @param string
	 * @return true se � corretto, false altrimenti
	 */
	public static boolean controllaCF(String string) {
		if (string
				.matches("[A-Z]{6}\\d\\d[A-Z]\\d\\d[A-Z]\\d\\d\\d[A-Z]")
				&& (string.length() == 16)) {
			return true; // buon fine
		} else {
			JOptionPane.showMessageDialog(null, "Controlla codice fiscale",
					"ERRORE",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	/**
	 * metodo per il controllo del numero di identificazione della tessera sanitaria
	 * @param string
	 * @return true se la lunghezza � 20, false altrimenti
	 */
	public static boolean controllaTS(String string) {
		if (string.matches("[0-9]{20}")) {
			
			return true;
		} else {

			JOptionPane.showMessageDialog(null, "Controlla numero tessera sanitaria",
					"ERRORE",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	/**
	 * metodo per il controllo della citt� di residenza e dell' indirizzo
	 * @param residenza citt� di resizenza
	 * @param indirizzo
	 * @return true se la residenza � di sole lettere (maiuscole o Minuscole), la lunghezza e compresa tra 3 e 15
	 * AND l' indirizzo � una stringa di lunhgezza compresa da 6 e 15; altrimenti false;
	 */
	public static boolean controllaResidenzaeIndirizzo(String residenza, String indirizzo){

		boolean valido = true;

		if(!(residenza.matches("[a-zA-Z0-9������' ]{3,50}"))){

			JOptionPane.showMessageDialog(
					null,
					"Controlla residenza",
					"ERRORE",
					JOptionPane.ERROR_MESSAGE
					);
			valido = false;			
		}


		if(!(indirizzo.matches("[a-zA-Z0-9\\,.������' /]{3,50}"))){

			JOptionPane.showMessageDialog(null, "Controlla indirizzo",
					"ERRORE",
					JOptionPane.ERROR_MESSAGE);
			valido = false;
		}

		return valido;
	}

	/**
	 * metodo per il controllo della mail. 
	 * @param string
	 * @return true se corretta, false altrimenti
	 */
	public static boolean controllaEmail(String string) {
		if (string.matches("[a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}")) {
			return true;
		} else {
			JOptionPane.showMessageDialog(null, "Controlla indirizzo Email",
					"ERRORE",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
	/**
	 * metodo per controllare il nome e cognome
	 * @param string nome o cognome passato come parametro
	 * @return true se corretto, false altrimenti
	 */
	public static boolean controllaCognome (String string){
		if(!(string.matches("[A-Za-z������' ]{4,20}"))){
			JOptionPane.showMessageDialog(null, "Controlla Cognome",
					"ERRORE",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}

		return true;

	}
	/**
	 * metodo per il controllo del nome
	 * @param string
	 * @return true se corretto, false altrimenti
	 */
	public static boolean controllaNome (String string){
		if(!(string.matches("[A-Za-z������' ]{4,20}"))){
			JOptionPane.showMessageDialog(null, "Controlla nome",
					"ERRORE",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}

		return true;
	}

	/**
	 * Verifica password, password di conferma
	 * 
	 * @param pass password 
	 * @param passC password di conferma
	 * @return true se uguali, false altrimenti 
	 */
	public static boolean confrontoPass(String pass, String passC){

		if(pass.compareTo(passC)==0){
			return true;
		} 

		JOptionPane.showMessageDialog(null, "Controlla password di conferma", "ERRORE", JOptionPane.ERROR_MESSAGE);
		return false;

	}

	//--------------------CONTROLLI SULLE COMPETIZIONI
	/**
	 * controlla se la data della competizione � successiva alla data odierna
	 * @param dataCompetizione
	 * @return true se la data � corretta(cio� successiva alla data odierna);
	 * 			false altrimenti.
	 */
	public static boolean controllaDataCompetizione(Date dataCompetizione) {

		Calendar oggi = Calendar.getInstance();
		Calendar date = Calendar.getInstance();
		date.setTime(dataCompetizione);
		
		if(date != null){
			if (oggi.before(date)) {
				return true; // buon fine
			}

		}
		JOptionPane.showMessageDialog(null, "Controlla data della competizione", 
				"ERRORE", JOptionPane.ERROR_MESSAGE);
		return false;
	}


	/**
	 * Controlla il numero dei partecipanti 
	 * 
	 * @param numMin numero minimo partecipanti
	 * @param numMax numero massimo partecipanti 
	 * @return true se corretti, false altrimenti 
	 */
	public static boolean controllaNumPartecipanti(String numMin, String numMax){

		if(numMin.equals("") || numMax.equals("")){
			JOptionPane.showMessageDialog(null, "Controlla numero minimo e numero massimo di Partecipanti", 
					"ERRORE", JOptionPane.ERROR_MESSAGE);
			return false;
		}else{
			if(!(numMin.matches("[0-9]*"))){
				JOptionPane.showMessageDialog(null, "Controlla numero minimo di Partecipanti", 
						"ERRORE", JOptionPane.ERROR_MESSAGE);
				return false;
			}

			if(!(numMax.matches("[0-9]*"))){
				JOptionPane.showMessageDialog(null, "Controlla numero massimo di Partecipanti", 
						"ERRORE", JOptionPane.ERROR_MESSAGE);
				return false;
			}

			if(Integer.parseInt(numMin) > Integer.parseInt(numMax)){
				JOptionPane.showMessageDialog(null, "Controlla numero minimo e numero massimo di Partecipanti", 
						"ERRORE", JOptionPane.ERROR_MESSAGE);

				return false;
			}
		}

		return true;
	}
	
	/**
	 * Controllo sul prezzo 
	 * 
	 * @param prezzo il prezzo
	 * @return true se accettabile, false altrimenti 
	 */
	public static boolean controllaPrezzo(String prezzo) {

		int counter=0;
		
		if(prezzo.contains(",")){
			prezzo = prezzo.replace(',', '.'); //trasforma eventuali , in .
		}
		
		for (int i = 0; i < prezzo.length(); i++) { // conta numero di occorrenze di .

			if (prezzo.charAt(i) =='.'){
				counter++;
			}
		}
		
		if(!prezzo.equals("")&& !(counter>1)){

			if(!(prezzo.matches("[0-9\\.]*")) || prezzo.equals("0") || prezzo.equals("0.0") || prezzo.equals("00.0") || prezzo.equals("0.00") || prezzo.equals("00.00")){
				JOptionPane.showMessageDialog(null, "Controlla il prezzo", 
						"ERRORE", JOptionPane.ERROR_MESSAGE);
				return false;
			}
		}else{
			JOptionPane.showMessageDialog(null, "Controlla il prezzo", 
					"ERRORE", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		return true;
	}

	/**
	 * Controlla tipo di competizione 
	 * 
	 * @param c tipo di competizione
	 * @return true se accettabile, false altrimenti 
	 */
	public static boolean controlloTipo(String c) {
		
		if(!(c.matches("[A-Za-z0-9'������\\ /]{4,20}"))){
			JOptionPane.showMessageDialog(null, "Controlla Tipo",
					"ERRORE",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}

		return true;
	}
	
	/**
	 * Vincolo per cui una competizione pu� essere modificata a patto che la 
	 * data di modifica sia antecedente di almeno due giorni alla data in cui
	 * la competizione avr� luogo.
	 * 
	 * @param data la data in cui avr� luogo la competizione
	 * @return
	 */
	public static boolean controlloDataModifica(Date data){
		
		boolean ok = false;
		
		Calendar oggi = Calendar.getInstance(); // data oggi
		oggi.add(Calendar.DAY_OF_MONTH, 3); //tra tre giorni
		
		Calendar date = Calendar.getInstance();
		date.setTime(data);
				
		if(oggi.before(date)){
			ok = true;
		} else {
			JOptionPane.showMessageDialog(
					null, "La competizione non � pi� modificabile.", 
					"ERRORE", JOptionPane.ERROR_MESSAGE);
		}
		
		return ok;
	}

	/**
	 * Controllo sulla data rilascio dell'src con data competizione
	 * 
	 * @param dataSRC data di rilascio dell'src
	 * @param dataComp data della competizione
	 * @return true se src � valido, false altrimenti 
	 */
	public static boolean controlloVincoloSRC(Date dataSRC, Date dataComp) {
		
		boolean ok = false;
		
		Calendar src = Calendar.getInstance();
		src.setTime(dataSRC);
				
		Calendar dataC = Calendar.getInstance();
		dataC.setTime(dataComp);
				
		src.add(Calendar.YEAR, 1);
		if(src.after(dataC)){
			ok = true;
		} else {
			JOptionPane.showMessageDialog(
					null, "Non puoi iscriverti a questa competizione "
							+ "a causa del certificato SRC scaduto.", 
					"ERRORE", JOptionPane.ERROR_MESSAGE);
		}
		
		return ok;
	}
	
}
