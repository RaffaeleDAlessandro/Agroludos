package utility;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Classe per il controllo sul database
 * 
 * @author Dispoto Marco, Raffaele D'Alessandro 
 *
 */
public class DBCheck {

	private static Connection conn = null;
	
	private static Connection getConnection() throws SQLException, IOException{
		String[] dati = DBSettingsReader.readSettings();
		return DriverManager.getConnection(dati[0], dati[1], dati[2]);
	}
	
	/**
	 * Controlla l'esistenza del db
	 * @return true se esiste, false altrimenti 
	 */
	public static boolean dbCheck(){
		
		boolean exists;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = getConnection();
			exists = true;
			conn.close();
		} catch (Exception e) {
			exists = false;
		}
		return exists;
	}
	
}
