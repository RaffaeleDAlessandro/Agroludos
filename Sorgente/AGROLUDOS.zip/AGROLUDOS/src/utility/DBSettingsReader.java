package utility;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

/**
 * Classe per la lettura delle impostazioni del db
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class DBSettingsReader {

	/**
	 * Legge le propriet� del database
	 * 
	 * @return path, username e password del db
	 */
	public static String[] readSettings(){
		
		String[] dati = new String[3];
		InputStream in = null;
		
		URL url = DBSettingsReader.class.getResource("/settings/database.settings");
		try {
			in = url.openStream();
		
			InputStreamReader r = new InputStreamReader(in);
			BufferedReader br = new BufferedReader(r);
			
			String temp = "";
			int i = 0;
			try {
				while((temp = br.readLine()) != null){
					dati[i] = temp;
					i++;
				}
			} catch (IOException e) {
				e.toString();
			}
		
		} catch (IOException e) {
			e.toString();
		}

		return dati;
	}
	
}
