package utility;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Classe per la lettura di file XML.
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class XMLReader {

	//deve contenere l'intero documento XML, la classe Document � nel package
	//org.w3c.dom
	
	private Document document;
	private InputStream in = null;
	
	public XMLReader(URL url){
		
		try {
			
			//DocumentBuildFactory � un parser che crea un modello a oggetti del 
			//documento XML, in particolare un modello ad albero
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = documentFactory.newDocumentBuilder();
			
			in = url.openStream();
			document = builder.parse(in);
		
		}catch(ParserConfigurationException e){
			e.toString();
		} catch (SAXException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
	}
	
	/**
	 * Legge il file xml 
	 * 
	 * @param key parametro da cercare 
	 * @return class e method 
	 */
	public ArrayList<String> leggiParametri(String key){
		
		ArrayList<String> items = new ArrayList<String>();
		
		try {
			// accesso al nodo radice del documento XML, 
			// normalizzandone il contenuto
			document.getDocumentElement().normalize();
			
			// prende tutti gli elementi con TagName = action
			NodeList actions = document.getElementsByTagName("action");
			// scansione di nl
			for(int i = 0; i < actions.getLength(); i++){
				
				Node nodo = actions.item(i);
				// Controlla se il tipo del nodo � un elemento
				if(nodo.getNodeType() == Node.ELEMENT_NODE){
					
					Element action = (Element) nodo;
					
					if (action.getAttribute("value").matches(key)) {
						items.add(action.getElementsByTagName("class").item(0).getFirstChild().getNodeValue());
						items.add(action.getElementsByTagName("method").item(0).getFirstChild().getNodeValue());
					}
				}
			}
		} catch(Exception e){
			e.toString();
		}
		return items;
	}
	
}
