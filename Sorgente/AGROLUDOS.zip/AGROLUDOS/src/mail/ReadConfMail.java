package mail;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

/**
 * La classe si occupa di leggere i paramentri 
 * per accedere alla casella di posta elettronica
 * 
 * @author Raffaele D' Alessandro, Marco Dispoto
 *
 */
public class ReadConfMail {

	private final String path = "/settings/confmail.dat";

	private URL url = ReadConfMail.class.getResource(path);
	private InputStream in = null;
	private BufferedReader br;

	/**
	 * Legge dal file confmail.dat i dati necessari all' invio di mail
	 * 
	 * @return array cn i dati necessari
	 */
	public String[] getLines(){
		
		String [] credenziali = new String[5];
		
		try {
			in = url.openStream();
			
			InputStreamReader r = new InputStreamReader(in);
			br = new BufferedReader(r);
			
			credenziali[0] = br.readLine(); //username
			credenziali[1] = br.readLine(); //password
			credenziali[2] = br.readLine(); // indirizzo mail
			credenziali[3] = br.readLine(); //stmp (server per la gestione dell' invio di posta)
			credenziali[4] = br.readLine(); //porta
			
		} catch (IOException e1) {
			e1.toString();			
		}
		
		return credenziali;
	}
}
