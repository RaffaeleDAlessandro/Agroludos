package mail;

import java.util.ArrayList;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * Classe che si occupa dell'invio di mail 
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class SendMail {

	private ReadConfMail sm = new ReadConfMail();

	private String username = sm.getLines()[0]; //nome utente progetto.agroludos
	private String smtpHost = sm.getLines()[3]; // host smtp smtp.gmail.com
	private String smtpPort = sm.getLines()[4]; // porta 587
	private String indMail = sm.getLines()[2]; // indirizzo mail progetto.agroludos@gmail.com
	private String password = sm.getLines()[1]; // password agroludos14

	/**
	 * Invio di mail in caso di registrazione al sistema 
	 * 
	 * @param mail l'indirizzo mail 
	 * @param user l'username dell'utente
	 */
	public void registrazioneSistema(String mail, String user){

		String subject = "Benvenuto in Agroludos";
		String text = "Benvenuto in Agroludos, "+user +
				"! \nTi sei registrato al nostro sistema. "
				+" \nBuon divertimento!"
				+"\n\n--Il Team Agroludos";

		invio(mail, subject, text);
	}
	
	/**
	 * invio mail per avvvenuto annullamento di competizione
	 * @param mail l'indirizzo mail 
	 * @param competizione dettagli della competiizone 
	 */
	public void annullaCompetizione(ArrayList<Object> mailList, ArrayList<Object> c){
		
		String tipo = String.valueOf(c.get(1));
		String data = String.valueOf(c.get(2));
		String ora = String.valueOf(c.get(3));
		
		String subject = "Competizione annullata";
		String text = "Gentile Partecipante, la competizione "
				+ tipo + " del giorno " + data + " alle ore "+ ora
						+ " � stata annullata per motivi tecnici."
						+"\n\n--Il Team Agroludos!";
		
		for(int i = 0; i < mailList.size(); i++){
			
			invio((String) mailList.get(i), subject, text);
			
		}
		
	}
	
	/**
	 * Invio di mail a causa di una modifica di competiizone 
	 * 
	 * @param mailList lista delle mail dei partecipanti iscritti
	 * @param c dettagli della competiizone 
	 */
	public void modificaCompetizione(ArrayList<Object> mailList, ArrayList<Object> c){
		
		String tipo = String.valueOf(c.get(1));
		String data = String.valueOf(c.get(2));
		String ora = String.valueOf(c.get(3));
		
		String subject = "Competizione modificata";
		String text = "Gentile Partecipante, la competizione "
				+ tipo + " del giorno " + data + " alle ore "+ ora
						+ " ha subito delle modifiche per motivi tecnici."
						+ "\n\n--Il team di Agroludos";
		
		for(int i = 0; i < mailList.size(); i++){
			invio((String) mailList.get(i), subject, text);
		}
		
	}
	
	/**
	 * Invio mail se c'� un nuovo partecipante ad una competizione 
	 * 
	 * @param mail indirizzo mail 
	 * @param c dettagli competizione 
	 */
	public void confermaIscrizione(String mail, ArrayList<Object> c) {
		
		String tipo = String.valueOf(c.get(1));
		String data = String.valueOf(c.get(2));
		String ora = String.valueOf(c.get(3));
		
		String subject = "Nuova iscrizione";
		String text = "Gentile Manager, un partecipante si � iscritto alla "
				+ "competizione " + tipo + " del giorno " + data + 
				", ore " + ora + "."
				 + "\n\n--Il team di Agroludos";
		
		invio(mail, subject, text);
		
	}
	
	/**
	 * Invio mail in seguito a modifica del prezzo degli optional
	 * 
	 * @param mail l'indirizzo mail 
	 */
	public void prezzoOptional(ArrayList<Object> mail) {
		
		String subject = "Modifica prezzo optional";
		String text = "Gentile Partecipante, la invitiamo a controllare le sue "
				+ "iscrizioni poich� i prezzi degli optional hanno subito delle "
				+ "modifiche dovute a motivi tecnici."
				+ "\n\n--Il team di Agroludos";
		
		for(int i = 0; i < mail.size(); i++){
			invio((String) mail.get(i), subject, text);
		}
		
	}
	
	/**
	 * Invio di mail in seguito all'eliminazione di un partecipante da una competizione
	 * 
	 * @param mail l'indirizzo mail 
	 * @param c dettagli competiizone
	 */
	public void eliminaIscrizione(String mail, ArrayList<Object> c) {
		
		String tipo = String.valueOf(c.get(1));
		String data = String.valueOf(c.get(2));
		String ora = String.valueOf(c.get(3));
		
		String subject = "Eliminazione da competizione";
		String text = "Gentile Manager, un partecipante si � cancellato dalla "
				+ "competizione " + tipo + " del giorno " + data + ", ore " 
				+ ora+ "."
						+ "\n\n--Il team di Agroludos";
		
		invio(mail, subject, text);
		
	}

	/**
	 * Invio di mail in seguito alla modifica degli optional
	 * 
	 * @param mail l'indirizzo mail 
	 * @param c dettagli della comeptizione 
	 */
	public void modificaOptionalPart(String mail, ArrayList<Object> c) {
		
		String tipo = String.valueOf(c.get(1));
		String data = String.valueOf(c.get(2));
		String ora = String.valueOf(c.get(3));
		
		String subject = "Modifica optional scelti";
		String text = "Gentile Manager, un partecipante ha modificato gli "
				+ "optional da lui precedentemente scelti, per la competizione "
				+ tipo + " del giorno " + data + ", ore "+ ora + 
				"\n\n--Il team di Agroludos";
		
		invio(mail, subject, text);
		
	}
	
	/**
	 * Invio mail in seguito a modifica optional da manager
	 * 
	 * @param mail indirizzo mail 
	 * @param c dettagli competizione 
	 */
	public void modificaOptionalMng(String mail, ArrayList<Object> c) {
		
		String tipo = String.valueOf(c.get(1));
		String data = String.valueOf(c.get(2));
		String ora = String.valueOf(c.get(3));
		
		String subject = "Modifica optional scelti";
		String text = "Gentile Partecipante, il manager della competizione " 
				+ tipo + " del giorno " + data + ", ore " + ora + " ha "
						+ "effettuato delle modifiche agli optional da lei "
						+ "scelti per motivi tecnici."
						+ "\n\n--Il team di Agroludos";
		
		invio(mail, subject, text);
		
	}
	
	/**
	 * Invio di mail in seguito a eliminazione partecipante da parte del manager
	 * 
	 * @param mail indirizzo mail 
	 * @param c dettagli competiizione
	 */
	public void eliminaPartecipanteMng(ArrayList<Object> mail, ArrayList<Object> c) {
		
		String tipo = String.valueOf(c.get(1));
		String data = String.valueOf(c.get(2));
		String ora = String.valueOf(c.get(3));
		
		String subject = "Eliminazione da competizione";
		String text = "Gentile Partecipante, per motivi tecnici � stato "
				+ "cancellato dalla competizione "+tipo+" del giorno "+data+
				", ore "+ora+"."
						+ "\n\n--Il team di Agroludos";
		
		for(int i = 0; i < mail.size(); i++){
			invio((String) mail.get(i), subject, text);
		}
	}

	
	/**
	 * Metodo per l'invio di mail 
	 * 
	 * @param mail indirizzo mail 
	 * @param subject oggetto della mail 
	 * @param text testo della mail 
	 */
	public void invio(String mail, String subject, String text){

		//impostazioni SMTP
		Properties props = new Properties();

		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.stmp.host", smtpHost);
		props.put("mail.smtp.port", smtpPort);

		Session session = Session.getInstance(props,
				new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(indMail, password);
			}
		});

		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(indMail));

			message.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(mail));

			message.setSubject(subject);
			message.setText(text);

			Transport transport = session.getTransport("smtp");
			transport.connect(smtpHost, username, password);
			transport.sendMessage(message, message.getAllRecipients());

		} catch (MessagingException e) {
//			System.out.println("Errore");
			e.toString();
		}

	}

}
