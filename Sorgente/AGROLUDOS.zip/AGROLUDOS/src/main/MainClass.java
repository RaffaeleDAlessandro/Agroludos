package main;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import presentation.FrontController;
import utility.DBCheck;

/**
 * Classe Principale
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class MainClass {

	/**
	 * Main
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		if(DBCheck.dbCheck()){
			try {
					JFrame frame = new JFrame();
					FrontController fc = new FrontController();				
					fc.processRequest("menu", frame, null);
				} catch (Exception e) {
					e.toString();
				}
		} else {
			JOptionPane.showMessageDialog(null, "Errore Database");
		}
		
	}

}
		
