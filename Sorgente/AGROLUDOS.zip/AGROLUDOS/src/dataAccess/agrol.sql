DROP DATABASE IF EXISTS agroludos_db;

CREATE DATABASE agroludos_db;

USE agroludos_db;

CREATE TABLE IF NOT EXISTS Partecipanti (

  CodiceFiscale         CHAR(16)        NOT NULL,
  Nome                  VARCHAR(20)     NOT NULL,
  Cognome               VARCHAR(20)     NOT NULL,
  Residenza             VARCHAR(50)     NOT NULL,
  Via                   VARCHAR(50)     NOT NULL,
  DataNascita           DATE            NOT NULL,
  Sesso                 CHAR(1)         NOT NULL,
  NumTessSanitaria      CHAR(20)        NOT NULL,
  SRC                   TEXT            NOT NULL,
  DataSRC               DATE            NOT NULL,
  Email                 VARCHAR(100)     NOT NULL,
  Username              VARCHAR(20)     NOT NULL    PRIMARY KEY,
  Pass                  VARCHAR(20)     NOT NULL
  
)  ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS ManagerCompetizione (

  idManager             INT             AUTO_INCREMENT      PRIMARY KEY,
  Nome                  VARCHAR(20)     NOT NULL,
  Cognome               VARCHAR(20)     NOT NULL,
  Email                 VARCHAR(30)     NOT NULL,
  Username              VARCHAR(20)     NOT NULL,
  Pass                  VARCHAR(20)     NOT NULL

) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS TipiOptional (

  Nome                  VARCHAR(15)     NOT NULL            PRIMARY KEY,
  Prezzo                DOUBLE          NOT NULL

) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS TipiCompetizione (

  Nome                  VARCHAR(30)     NOT NULL            PRIMARY KEY

) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS ManagerSistema (

  Username              VARCHAR(20)     PRIMARY KEY,
  Pass                  VARCHAR(20)     NOT NULL

) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS Competizioni (

  idCompetizione        INT             AUTO_INCREMENT      PRIMARY KEY,
  Tipo                  VARCHAR(30)     NOT NULL, 
  DataCompetizione      DATE            NOT NULL, 
  OraCompetizione       CHAR(5)         NOT NULL,
  NumMaxPart            INT             NOT NULL,
  NumMinPart            INT             NOT NULL,
  Prezzo                DOUBLE          NOT NULL,
  CodiceManager         INT             NOT NULL,
  Attiva                INT,
  Pranzo                INT,
  Merenda               INT, 
  Pernotto              INT,
  FOREIGN KEY (CodiceManager) REFERENCES ManagerCompetizione(idManager)

) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS Iscrizioni (

  CodiceCompetizione    INT                NOT NULL,
  CodicePartecipante    VARCHAR(20)        NOT NULL,
  Pranzo                INT,
  Merenda               INT, 
  Pernotto              INT,
  DataIscr              DATE,
  FOREIGN KEY (CodiceCompetizione) REFERENCES Competizioni(idCompetizione), 
  FOREIGN KEY (CodicePartecipante) REFERENCES Partecipanti(username),  
  PRIMARY KEY (CodiceCompetizione, CodicePartecipante)

) ENGINE = InnoDB;

INSERT INTO TipiCompetizione(Nome) VALUES 
  ('Tiro con l''arco'),
  ('Corsa campestre');

INSERT INTO TipiOptional VALUES
  ('Pranzo'   ,     5.0),
  ('Merenda'  ,     3.5),
  ('Pernotto' ,    20.0);
  
INSERT INTO ManagerSistema VALUES 
  ('admin', 'agroludos'); 
  
INSERT INTO ManagerCompetizione VALUES
  (1, 'Marco', 'Dispoto', 'marco@mail.it', 'marco', 'marco'),
  (2, 'Raffaele', 'D''Alessandro', 'raff@mail.it', 'raffaele', 'raffaele'); 
  
INSERT INTO Partecipanti VALUES 
  ('DSPMRC93B25A662L', 'Marco', 'Dispoto', 'Bari', 'via bari', '1993-02-25', 'M', 
  '00000000000000000000', '', '2014-09-15', 'marco93@mail.it', 'marco93', 'marco93');
  
INSERT INTO Competizioni VALUES 
  (1, 'Corsa campestre', '2015-03-15', '10:30', 30, 10, 7.50, 1, 1, 1, 1, 0),
  (2, 'Tiro con l''arco', '2015-05-17', '15:30', 7, 4, 11.00, 2, 1, 0, 1, 1),
  (3, 'Tiro con l''arco', '2015-03-20', '20:00', 15, 10, 12.00, 2, 1, 1, 0, 1);
  
INSERT INTO Iscrizioni VALUES 
  (1, 'marco93', 1, 0, 0, CURRENT_DATE());