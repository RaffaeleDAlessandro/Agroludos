package dataAccess;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import utility.DBSettingsReader;

/**
 * Classe che si occupa delle operazioni sul database
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class DAO {

	private Connection conn;
	private ResultSet rs;
	private static String user = "";
	private PreparedStatement statement;

	private Connection getConnection(){
		String[] dati = DBSettingsReader.readSettings();
		try {
			return DriverManager.getConnection(dati[0], dati[1], dati[2]);
		} catch (SQLException e) {
			e.toString();
		}
		return null;
	}

	private boolean openConnection() throws SQLException, IOException{
		boolean connesso = false;
		conn = getConnection();
		//conn.createStatement();
		connesso = true;
		return connesso;
	}

	private boolean closeConnection() throws SQLException {
		boolean chiuso = false;
		conn.close();
		chiuso = true;
		return chiuso;
	}

	/**
	 * Effettua il login 
	 * 
	 * @param p username e password dell'utente 
	 * @return il tipo di utente che ha effettuato il login se va a buon fine, 
	 * 			0 altrimenti
	 */
	public int checkLogin(ArrayList<Object> p) {
		
		String un = p.get(0).toString();
		String pass = p.get(1).toString();

		try {
			openConnection();
			
			int tipoUtente = 0;
			
			final int M_SISTEMA = 1;
			final int M_COMPETIZIONE = 2;
			final int PARTECIPANTE = 3;

			String query = "select username from ManagerSistema where "
					+ "binary username = ? and binary pass = ?;";
			statement = conn.prepareStatement(query);
			
			statement.setString(1, un);
			statement.setString(2, pass);
			
			rs = statement.executeQuery(); 
			if(rs.next()){ 
				tipoUtente = M_SISTEMA; 
				user = un;
			} else {
				query = "select idManager from ManagerCompetizione where "
						+ "binary username = ? and binary pass = ?;";
				
				statement = conn.prepareStatement(query);
				
				statement.setString(1, un);
				statement.setString(2, pass);

				rs = statement.executeQuery();
				if(rs.next()){
					tipoUtente = M_COMPETIZIONE;
					user = un;
				} else {
					query = "select CodiceFiscale from Partecipanti where binary "
							+ "username = ? and binary pass = ?;";
					
					statement = conn.prepareStatement(query);
					
					statement.setString(1, un);
					statement.setString(2, pass);
					
					rs = statement.executeQuery();
					if(rs.next()){
						tipoUtente = PARTECIPANTE;
						user = un;
					}
				}
			}
			
			closeConnection();
			return tipoUtente;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}

		return 0;

	}


	/**
	 * Metodo per controllare se esiste gi� l'username specificato al momento
	 * della registrazione
	 * 
	 * @param user username specificato nella registrazione dell'utente
	 * @return true se esiste gi� l'username, false altrimenti
	 */
	public boolean esisteUsername(String un){

		try {
			openConnection();
			
			boolean esiste = false;

			if("admin".compareTo(un) == 0){
				esiste = true; 
			} else {
				String queryMC = "select username from ManagerCompetizione where binary username = ?;";
				statement = conn.prepareStatement(queryMC);
				
				statement.setString(1, un);
				
				rs = statement.executeQuery(queryMC);
				if(rs.next()){
					esiste = true; 
				} else {
					String queryP = "select username from Partecipanti where binary username = ?;";
					statement = conn.prepareStatement(queryP);
					
					statement.setString(1, un);
					
					rs = statement.executeQuery();
					if(rs.next()){
						esiste = true;
					}
				}

			}
			rs.close();
			closeConnection();
			return esiste;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		return false;

		
	}

	/**
	 * Registrazione di un nuovo partecipante
	 * 
	 * @param par l'anagrafica del partecipante
	 */
	public void registraPartecipante(ArrayList<Object> par) {

		try {

			openConnection();
			// prendo parametri ricevuti dal form di registrazione
			String cf = (String) par.get(0);
			String nome = (String) par.get(1);
			String cognome = (String) par.get(2);
			String residenza = (String) par.get(3);
			String indirizzo = (String) par.get(4);

			Date dataN = (Date) par.get(5);

			java.util.Calendar dateN = Calendar.getInstance();
			dateN.setTime(dataN);
			java.sql.Date sqlDataN = new java.sql.Date(dateN.getTime().getTime());


			String sesso = (String) par.get(6);
			String nTessSan = (String) par.get(7);
			InputStream SRC = (InputStream) par.get(8);
			Date dataSRC = (Date) par.get(9);

			java.util.Calendar dateSRC = Calendar.getInstance();
			dateSRC.setTime(dataSRC);
			java.sql.Date sqlDataSRC = new java.sql.Date(dateSRC.getTime().getTime());

			String email = 	(String) par.get(10);
			String un = (String) par.get(11);
			String pass = (String) par.get(12);

			String query = "INSERT INTO Partecipanti (codicefiscale, nome, "
					+ "cognome, residenza, via, datanascita, sesso, "
					+ "numtesssanitaria, src, datasrc, email, username, "
					+ "pass) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

			statement = conn.prepareStatement(query);
			
			statement.setString(1, cf);
			statement.setString(2, nome);
			statement.setString(3, cognome);
			statement.setString(4, residenza);
			statement.setString(5, indirizzo);
			statement.setDate(6, sqlDataN);
			statement.setString(7, sesso);
			statement.setString(8, nTessSan);
			statement.setBinaryStream(9, SRC);
			statement.setDate(10, sqlDataSRC);
			statement.setString(11, email);
			statement.setString(12, un);
			statement.setString(13, pass);
			
			statement.executeUpdate();
			
			statement.close();
			closeConnection();

		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}

	}

	/**
	 * Ottiene il profilo del partecipante 
	 * 
	 * @return l'anagrafica del partecipante
	 */
	public ArrayList<Object> getPartecipante() {

		String query = "SELECT * FROM Partecipanti WHERE username = ?;";

		try {
			openConnection();
			statement = conn.prepareStatement(query);
			
			statement.setString(1, user);
			
			rs = statement.executeQuery();
			ArrayList<Object> par = new ArrayList<Object>();
			while(rs.next()){
				par.add(rs.getString("codicefiscale"));
				par.add(rs.getString("nome"));
				par.add(rs.getString("cognome"));
				par.add(rs.getString("residenza"));
				par.add(rs.getString("via"));
				par.add(rs.getDate("datanascita"));
				par.add(rs.getString("sesso"));
				par.add(rs.getString("numtesssanitaria"));
				//par.add(rs.getBinaryStream("src"));
				par.add(rs.getDate("datasrc"));
				par.add(rs.getString("email"));
			}
			
			rs.close();
			statement.close();
			closeConnection();

			return par;

		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}

		return null;
	}

	/**
	 * Mostra la lista delle competizioni alle quali il partecipante non � iscritto, 
	 * se e solo se la data � successiva alla data odierna e se non � stato raggiunto
	 * il numero massimo di partecipanti.
	 * 
	 * @return la lista delle competizione alle quali il partecipante non � iscritto
	 */
	public ArrayList<ArrayList<Object>> getCompetizioni() {

		ArrayList<ArrayList<Object>> listaCompetizioni = new ArrayList<ArrayList<Object>>();
		
		//estrae le competizioni che sono successive alla data odierna, alle quali
		//il partecipante non � iscritto.
		String query = "SELECT * FROM COMPETIZIONI WHERE "
				+ "DataCompetizione > (SELECT CURRENT_DATE()) "
				+ "AND Attiva = 1 AND idCompetizione NOT IN "
				+ "(SELECT codiceCompetizione FROM iscrizioni WHERE "
				+ "codicePartecipante=?);";

		try {
			openConnection();
			statement = conn.prepareStatement(query);
			statement.setString(1, user);
			rs = statement.executeQuery();
			while(rs.next()){
				ArrayList<Object> competizione = new ArrayList<Object>();
				competizione.add(rs.getDate("DataCompetizione"));
				competizione.add(rs.getString("OraCompetizione"));
				competizione.add(rs.getString("Tipo"));
				competizione.add(rs.getDouble("Prezzo"));
				competizione.add(rs.getInt("idCompetizione"));
				competizione.add(rs.getInt("NumMaxPart"));
				competizione.add(rs.getInt("NumMinPart"));
				competizione.add(rs.getInt("Pranzo"));
				competizione.add(rs.getInt("Merenda"));
				competizione.add(rs.getInt("Pernotto"));

				int num = getNumIscritti(String.valueOf(rs.getInt("idCompetizione")));
				competizione.add(num);
				
				listaCompetizioni.add(competizione);
				
			}

			rs.close();
			statement.close();
			closeConnection();
			return listaCompetizioni;

		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		return null;

	}

	/**
	 * Lettura degli optional per terminare l'iscrizione a una competizione
	 * da parte di un partecipante.
	 * 
	 * @param par dettagli 
	 * @return optional disponibili
	 */
	public ArrayList<ArrayList<Object>> leggiOptional(ArrayList<Object> par) {

		ArrayList<ArrayList<Object>> optional = new ArrayList<ArrayList<Object>>();
		ArrayList<Object> dettComp = new ArrayList<Object>();

		dettComp.add(par.get(0));
		dettComp.add(par.get(1));
		dettComp.add(par.get(2)); 
		dettComp.add(par.get(3));
		dettComp.add(par.get(4)); 

		optional.add(dettComp);

		String query = "SELECT * FROM TipiOptional";

		try {
			openConnection();
			statement = conn.prepareStatement(query);
			rs = statement.executeQuery();
			while(rs.next()){

				ArrayList<Object> opt = new ArrayList<Object>();
				opt.add(rs.getString("nome"));
				opt.add(rs.getDouble("prezzo"));

				optional.add(opt);
			}

			rs.close();
			statement.close();
			closeConnection();
			return optional;

		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}

		return null;
	}

	/**
	 * Registrazione della iscrizione nel db
	 * 
	 * @param par dettagli dell'iscrizione
	 */
	public String iscrizioneCompetizione(ArrayList<Object> par) {

		int idComp = (Integer) par.get(0);
		int pranzo = (Integer) par.get(1);
		int merenda = (Integer) par.get(2);
		int pernotto = (Integer) par.get(3);
		String un = "";

		String query = "INSERT INTO Iscrizioni VALUES (?, ?, ?, ?, ?, CURRENT_DATE());";

		try {

			openConnection();
			statement = conn.prepareStatement(query);
			
			statement.setInt(1, idComp);
			statement.setString(2, user);
			statement.setInt(3, pranzo);
			statement.setInt(4, merenda);
			statement.setInt(5, pernotto);
			
			statement.executeUpdate();

			String q1 = "SELECT username FROM ManagerCompetizione, Iscrizioni, Competizioni "
					+ "WHERE codiceCompetizione = ? AND "
							+ "codiceManager = idManager AND "
							+ "codiceCompetizione = idCompetizione;";
			
			statement = conn.prepareStatement(q1);
			
			statement.setInt(1, idComp);
			
			rs = statement.executeQuery();
			while(rs.next()){
				un = rs.getString("username");
			}
			
			closeConnection();
			rs.close();
			statement.close();
			return un;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		return null;

	}

	/**
	 * Estrae da db i tipi di competizione previsti
	 * 
	 * @return i tipi di competizione
	 */
	public ArrayList<Object> leggiTipiCompetizione() {

		String query = "SELECT * FROM TipiCompetizione;";
		ArrayList<Object> tipi = new ArrayList<Object>();

		try {
			openConnection();
			statement = conn.prepareStatement(query);
			rs = statement.executeQuery();

			while(rs.next()){
				tipi.add(rs.getString("nome"));
			}

			statement.close();
			rs.close();
			closeConnection();
			return tipi;

		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}

		return null;
	}

	/**
	 * Aggiunge una nuova competizione nel db
	 * 
	 * @param par i dettagli della competizione
	 */
	public void nuovo(ArrayList<Object> par) {

		String tipo = (String) par.get(0);
		Date dataC = (Date) par.get(1);

		java.util.Calendar dataComp = Calendar.getInstance();
		dataComp.setTime(dataC);
		java.sql.Date dataCompetizione = new java.sql.Date(dataComp.getTime().getTime());

		String ora = (String) par.get(2);
		int nMax = (Integer) par.get(3);
		int nMin = (Integer) par.get(4);
		double prezzo = (double) par.get(5);
		//String mng = (String) par.get(6);
		int pranzo = (Integer) par.get(6);
		int merenda = (Integer) par.get(7);
		int pernotto = (Integer) par.get(8);
		int idMng = 0;

		String q1 = "SELECT idManager FROM ManagerCompetizione WHERE Username = ?;";

		try {
			openConnection();
			statement = conn.prepareStatement(q1);
			
			statement.setString(1, user);
			
			rs = statement.executeQuery();

			while(rs.next()){
				idMng = rs.getInt("idManager");
			}

			String query = "INSERT INTO Competizioni(tipo, datacompetizione, "
					+ "oracompetizione, nummaxpart, numminpart, prezzo, "
					+ "codicemanager, attiva, pranzo, merenda, pernotto) "
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?);";

			statement = conn.prepareStatement(query);
			
			statement.setString(1, tipo);
			statement.setDate(2, dataCompetizione);
			statement.setString(3, ora);
			statement.setInt(4, nMax);
			statement.setInt(5, nMin);
			statement.setDouble(6, prezzo);
			statement.setInt(7, idMng);
			statement.setInt(8, pranzo);
			statement.setInt(9, merenda);
			statement.setInt(10, pernotto);
			
			statement.executeUpdate();

			statement.close();
			rs.close();
			closeConnection();

		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}

	}

	/**
	 * Mostra la lista delle competizioni gestite da un manager
	 * 
	 * @return la lista delle competizioni gestite
	 */
	public ArrayList<ArrayList<Object>> competizioniGestite() {

		ArrayList<ArrayList<Object>> listaCompetizioni = new ArrayList<ArrayList<Object>>();
		
		int codM = 0;
		
		String q1 = "SELECT idManager FROM ManagerCompetizione WHERE username = ?;";
		
		try {
			openConnection();
			statement = conn.prepareStatement(q1);
			
			statement.setString(1, user);
			
			rs = statement.executeQuery();
			
			while(rs.next()){
				codM = rs.getInt("idManager");
			}
			
			String q2 = "SELECT idCompetizione, DataCompetizione, OraCompetizione, "
					+ "Tipo, Prezzo, NumMinPart, NumMaxPart, COUNT(codicePartecipante) "
					+ "AS numero_iscritti FROM Competizioni LEFT JOIN iscrizioni "
					+ "ON idCompetizione = codiceCompetizione WHERE "
					+ "DataCompetizione > (SELECT CURRENT_DATE()) AND "
					+ "codiceManager = ? AND attiva = 1 GROUP BY idCompetizione;";
			
			statement = conn.prepareStatement(q2);
			
			statement.setInt(1, codM);
			
			rs = statement.executeQuery();
			
			while(rs.next()){
				
				ArrayList<Object> comp = new ArrayList<Object>();
				
				comp.add(rs.getDate("DataCompetizione"));
				comp.add(rs.getString("OraCompetizione"));
				comp.add(rs.getString("Tipo"));
				comp.add(rs.getDouble("Prezzo"));
				comp.add(rs.getInt("numMinPart"));
				comp.add(rs.getInt("numMaxPart"));
				comp.add(rs.getInt("numero_iscritti"));
				comp.add(rs.getInt("idCompetizione"));
				
				listaCompetizioni.add(comp);
				
			}
			
			rs.close();
			closeConnection();
			statement.close();
			return listaCompetizioni;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		return null;
	}

	/**
	 * Scrive le modifiche effettuate dal partecipante al suo profilo
	 * 
	 * @param par l'anagrafica
	 */
	public void confermaModifichePart(ArrayList<Object> par) {

		String nome = (String) par.get(0);
		String cognome = (String) par.get(1);
		String sesso = (String) par.get(2);
		Date dataN = (Date) par.get(3);

		java.util.Calendar dataNasc = Calendar.getInstance();
		dataNasc.setTime(dataN);
		java.sql.Date dataNascita = new java.sql.Date(dataNasc.getTime().getTime());

		//manca src
		String nTess = (String) par.get(4);
		String res = (String) par.get(5);
		String ind = (String) par.get(6);
		String email = (String) par.get(7);

		Date dataSRC = (Date) par.get(8);

		java.util.Calendar srcDate = Calendar.getInstance();
		srcDate.setTime(dataSRC);
		java.sql.Date rilascioSRC = new java.sql.Date(srcDate.getTime().getTime());

		//manca src
		String query = "UPDATE Partecipanti SET nome = ?, cognome = ?, residenza = ?, "
				+ "via = ?, dataNascita = ?, sesso = ?, numTessSanitaria = ?, "
				+ "dataSRC = ?, email = ? WHERE username = ?;";

		try {
			openConnection();
			statement = conn.prepareStatement(query);
			
			statement.setString(1, nome);
			statement.setString(2, cognome);
			statement.setString(3, res);
			statement.setString(4, ind);
			statement.setDate(5, dataNascita);
			statement.setString(6, sesso);
			statement.setString(7, nTess);
			statement.setDate(8, rilascioSRC);
			statement.setString(9, email);
			statement.setString(10, user);
			
			statement.executeUpdate();
			
			statement.close();
			closeConnection();

		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}

	}

	/**
	 * Legge la lista delle iscrizioni di un partecipante
	 * 
	 * @return la lista delle iscrizioni di un partecipante
	 */
	public ArrayList<ArrayList<Object>> leggiIscrizioni() {

		ArrayList<ArrayList<Object>> listaIscrizioni = new ArrayList<ArrayList<Object>>();

		String query = "select idcompetizione, dataCompetizione, oraCompetizione, tipo, "
				+ "prezzo, iscrizioni.pranzo, iscrizioni.merenda, iscrizioni.pernotto "
				+ "from iscrizioni, competizioni "
				+ "where codicepartecipante = ? and "
				+ "codicecompetizione = idcompetizione AND "
				+ "attiva = 1 AND dataCompetizione >= (SELECT CURRENT_DATE());";

		try {
			openConnection();
			statement = conn.prepareStatement(query);
			
			statement.setString(1, user);
			
			rs = statement.executeQuery();

			while(rs.next()){
				
				ArrayList<Object> iscrizione = new ArrayList<Object>();

				iscrizione.add(rs.getDate("dataCompetizione"));
				iscrizione.add(rs.getString("oraCompetizione"));
				iscrizione.add(rs.getString("tipo"));

				double prezzoComp = rs.getDouble("prezzo");

				int pranzo = rs.getInt("pranzo");
				int merenda = rs.getInt("merenda");
				int pernotto = rs.getInt("pernotto");

				String q1 = "SELECT prezzo FROM tipiOptional;";
				statement = conn.prepareStatement(q1);
				ResultSet r = statement.executeQuery();

				double[] p = new double[3];
				int i = 0;

				while(r.next()){
					p[i] = r.getDouble("prezzo");
					i++;
				}

				r.close();
				
				double prezzoTot = 0.0;
				prezzoTot = prezzoComp + merenda*p[0] + pernotto*p[1] + pranzo*p[2];

				iscrizione.add(prezzoTot);
				iscrizione.add(rs.getInt("idCompetizione"));

				listaIscrizioni.add(iscrizione);

			}
			rs.close();
			statement.close();
			closeConnection();
			return listaIscrizioni;

		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}

		return null;
	}

	/**
	 * Elimina un'iscrizione ad una competizione di un partecipante
	 * 
	 * @param p l'identificativo della competizione
	 */
	public void eliminaIscrizione(ArrayList<Object> p) {

		int id = (int) p.get(0);

		String query = "DELETE FROM iscrizioni WHERE codiceCompetizione = ? "
				+ "AND codicePartecipante= ?;";

		try {

			openConnection();

			statement = conn.prepareStatement(query);
			
			statement.setInt(1, id);
			statement.setString(2, user);
			
			statement.executeUpdate();

			statement.close();
			closeConnection();

		} catch (SQLException e) {
			e.toString();
		}  catch (IOException e) {
			e.toString();
		}


	}

	/**
	 * metodo per l' aggiornamento della password
	 * @param par; l' arraylist contiene: in posizione 0 l' username; in posizione 1 la nuova password;
	 */
	public void aggiornaPassword(ArrayList<Object> par) {
		
		String tipo = (String) par.get(1); //tipo utente
		String query = "";
	
		query = "update "+tipo+" set pass=? where username =?;";
		
		try {
			openConnection();

			statement = conn.prepareStatement(query);
			
			statement.setString(1, par.get(0).toString());
			statement.setString(2, user);
			
			statement.executeUpdate();

			statement.close();
			closeConnection();
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}

	}

	/**
	 * Scrive sul db gli optional modificati
	 * 
	 * @param par
	 * @return
	 */
	public void modificaOptionalSceltiM(ArrayList<Object> par) {

		int idC = (int) par.get(0);
		String un = (String) par.get(1);
		int pr = (int) par.get(2);
		int me = (int) par.get(3);
		int pe = (int) par.get(4);
		
		String query = "UPDATE iscrizioni SET pranzo = ?, merenda = ?, "
				+ "pernotto=? WHERE codiceCompetizione =? AND "
						+ "codicePartecipante =?;";		
		
		try {
			
			openConnection();
			statement = conn.prepareStatement(query);
			
			statement.setInt(1, pr);
			statement.setInt(2, me);
			statement.setInt(3, pe);
			statement.setInt(4, idC);
			statement.setString(5, un);
			
			statement.executeUpdate();
			
			statement.close();
			closeConnection();
				
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
	}
	
	/**
	 * Modifica degli optional scelti da parte di un partecipante
	 * 
	 * @param par i dettagli degli optional
	 */
	public void modificaOptionalSceltiP(ArrayList<Object> par) {

		int idC = (int) par.get(0);
		int pr = (int) par.get(1);
		int me = (int) par.get(2);
		int pe = (int) par.get(3);
		
		String query = "UPDATE iscrizioni SET pranzo = ?, merenda = ?, "
				+ "pernotto=? WHERE codiceCompetizione =? AND "
						+ "codicePartecipante =?;";		
		
		try {
			
			openConnection();
			statement = conn.prepareStatement(query);
			
			statement.setInt(1, pr);
			statement.setInt(2, me);
			statement.setInt(3, pe);
			statement.setInt(4, idC);
			statement.setString(5, user);
			
			statement.executeUpdate();
			
			statement.close();
			closeConnection();
			
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
	}

	/**
	 * Legge da db gli optional selezionati per una data competizione
	 * 
	 * @param par dettagli 
	 * @return gli optional scelti 
	 */
	public ArrayList<ArrayList<Object>> leggiOptionalScelti(ArrayList<Object> par) {
	
		ArrayList<ArrayList<Object>> det = new ArrayList<ArrayList<Object>>();
		ArrayList<Object> temp = new ArrayList<Object>();
		
		int idComp = (int) par.get(0);
	
		temp.add(idComp);
		
		det.add(temp);
		
		//estrae gli optional disponibili per una competizione
		String q1 = "SELECT pranzo, merenda, pernotto, prezzo FROM Competizioni WHERE "
				+ "idCompetizione=?;";
		
		//estrae gli optional scelti dal partecipante per questa competizione
		String q2 = "SELECT pranzo, merenda, pernotto FROM Iscrizioni WHERE "
				+ "codiceCompetizione=? AND codicePartecipante=?;";
		
		//estrae i prezzi degli optional
		String q3 = "SELECT prezzo FROM tipiOptional;";
		
		try {
			openConnection();
			
			statement = conn.prepareStatement(q1);
			
			statement.setInt(1, idComp);
			
			rs = statement.executeQuery();
			while(rs.next()){
				ArrayList<Object> p = new ArrayList<Object>();
				p.add(rs.getInt("pranzo"));
				p.add(rs.getInt("merenda"));
				p.add(rs.getInt("pernotto"));
				p.add(rs.getDouble("prezzo"));
				
				det.add(p);	
			}
			
			statement = conn.prepareStatement(q2);
			
			statement.setInt(1, idComp);
			statement.setString(2, user);
			
			rs=statement.executeQuery();
			while(rs.next()){
				
				ArrayList<Object> p = new ArrayList<Object>();
				p.add(rs.getInt("pranzo"));
				p.add(rs.getInt("merenda"));
				p.add(rs.getInt("pernotto"));
				
				det.add(p);	
			}
			
			statement = conn.prepareStatement(q3);
			rs = statement.executeQuery();
			while(rs.next()){
				
				ArrayList<Object> p = new ArrayList<Object>();
				p.add(rs.getDouble("prezzo"));
				
				det.add(p);	
			}
			
			rs.close();
			statement.close();
			closeConnection();
			return det;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		return null;
	}

	/**
	 * Restituisce la lista dei partecipanti iscritti ad una competizione
	 * 
	 * @param id l'identificativo della competizione
	 * @return la lista dei partecipanti
	 */
	public ArrayList<ArrayList<Object>> listaPartecipanti(String id) {
		
		ArrayList<ArrayList<Object>> listaPart = new ArrayList<ArrayList<Object>>();
		int idComp = Integer.parseInt(id);
		ArrayList<Object> type = new ArrayList<Object>();
		type.add(idComp);
		
		String query = "SELECT codiceFiscale, Cognome, Nome, DataNascita, dataSRC, email, username "
				+ "FROM iscrizioni, partecipanti "
				+ "WHERE codiceCompetizione = ? AND "
						+ "codicePartecipante = username "
						+ "ORDER BY dataIscr;";
		
		
		
		try {
			openConnection();
			statement = conn.prepareStatement(query);
			
			statement.setInt(1, idComp);
			
			rs = statement.executeQuery();
			
			while(rs.next()){
				
				ArrayList<Object> p = new ArrayList<Object>();
				
				p.add(rs.getString("codicefiscale"));
				p.add(rs.getString("cognome"));
				p.add(rs.getString("nome"));
				p.add(rs.getDate("datanascita"));
				p.add(rs.getDate("datasrc"));
				p.add(rs.getString("email"));
				
				p.add(rs.getString("username"));
				
				listaPart.add(p);
				
			}
			
			// inserisco nell'ultimo ArrayList l'id della competizione
			listaPart.add(type);
			
			
			rs.close();
			statement.close();
			closeConnection();
			return listaPart;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}

		return null;
	}

	/**
	 * Annulla una competizione 
	 * 
	 * @param p dettagli della competiizone
	 */
	public void annullaCompetizione(ArrayList<Object> p) {
		
		int idComp = (int) p.get(0);
 		
		String query = "UPDATE competizioni SET Attiva = 0 "
				+ "WHERE idCompetizione=?;";
		
		try {
			openConnection();
			statement = conn.prepareStatement(query);
			
			statement.setInt(1, idComp);
			
			statement.executeUpdate();
			
			statement.close();
			closeConnection();
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
	}

	/**
	 * Registrazione di un nuovo manager di competizione
	 * 
	 * @param p l'anagrafica del manager di competizione
	 */
	public void registrazioneMngCompetizione(ArrayList<Object> p) {
		
		String nome = (String) p.get(0);
		String cognome = (String) p.get(1);
		String email = (String) p.get(2);
		String username = (String) p.get(3);
		String password = (String) p.get(4);
		
		String query = "INSERT INTO ManagerCompetizione(nome, cognome, email, username, pass) "
				+ "VALUES (?, ?, ?, ?, ?);";
		
		try {
			
			openConnection();
			statement = conn.prepareStatement(query);
			
			statement.setString(1, nome);
			statement.setString(2, cognome);
			statement.setString(3, email);
			statement.setString(4, username);
			statement.setString(5, password);
			
			statement.executeUpdate();
			
			statement.close();
			closeConnection();
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		
	}

	/**
	 * Legge gli optional selezionati da un partecipante per una data competizione
	 * 
	 * @param p contiene, in ordine, idCompetizione e username del partecipante
	 */
	public ArrayList<ArrayList<Object>> vediOptionalScelti(ArrayList<Object> par) {
		
		ArrayList<ArrayList<Object>> det = new ArrayList<ArrayList<Object>>();
		ArrayList<Object> temp = new ArrayList<Object>();
		
		int idComp = (int) par.get(0);
		String un = (String) par.get(1);
		
		temp.add(idComp);
		temp.add(un);
		
		det.add(temp);
		
		//estrae gli optional disponibili per una competizione
		String q1 = "SELECT pranzo, merenda, pernotto, prezzo FROM Competizioni WHERE "
				+ "idCompetizione=?;";
		
		//estrae gli optional scelti dal partecipante per questa competizione
		String q2 = "SELECT pranzo, merenda, pernotto FROM Iscrizioni WHERE "
				+ "codiceCompetizione=? AND codicePartecipante=?;";
		
		//estrae i prezzi degli optional
		String q3 = "SELECT prezzo FROM tipiOptional;";
		
		try {
			openConnection();
			
			statement = conn.prepareStatement(q1);
			
			statement.setInt(1, idComp);
			
			rs = statement.executeQuery();
			while(rs.next()){
				ArrayList<Object> p = new ArrayList<Object>();
				p.add(rs.getInt("pranzo"));
				p.add(rs.getInt("merenda"));
				p.add(rs.getInt("pernotto"));
				p.add(rs.getDouble("prezzo"));
				
				det.add(p);	
			}
			
			statement = conn.prepareStatement(q2);
			
			statement.setInt(1, idComp);
			statement.setString(2, user);
			
			rs = statement.executeQuery();
			while(rs.next()){
				
				ArrayList<Object> p = new ArrayList<Object>();
				p.add(rs.getInt("pranzo"));
				p.add(rs.getInt("merenda"));
				p.add(rs.getInt("pernotto"));
				
				det.add(p);	
			}
			
			statement = conn.prepareStatement(q3);
			rs = statement.executeQuery();
			while(rs.next()){
				
				ArrayList<Object> p = new ArrayList<Object>();
				p.add(rs.getDouble("prezzo"));
				
				det.add(p);	
			}
			
			rs.close();
			statement.close();
			closeConnection();
			return det;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		return null;
		
	}

	/**
	 * Ottiene una competizione 
	 * 
	 * @param id l'id della competizione
	 * @return i dettagli della competizione
	 */
	public ArrayList<Object> ottieniCompetizione(String id) {
		
		int idComp = Integer.parseInt(id);
		ArrayList<Object> comp = new ArrayList<Object>();
		
		String query = "SELECT tipo, dataCompetizione, oraCompetizione, NumMaxPart, "
				+ "NumMinPart, Prezzo, Pranzo, Merenda, Pernotto "
				+ "FROM Competizioni WHERE idCompetizione = ?;";
		
		try {
			openConnection();
			statement = conn.prepareStatement(query);
			
			statement.setInt(1, idComp);
			
			rs = statement.executeQuery();
			
			comp.add(idComp);
			
			while(rs.next()){
				
				comp.add(rs.getString("tipo"));
				comp.add(rs.getDate("dataCompetizione"));
				comp.add(rs.getString("oraCompetizione"));
				comp.add(rs.getInt("NumMaxPart"));
				comp.add(rs.getInt("NumMinPart"));
				comp.add(rs.getDouble("prezzo"));
				comp.add(rs.getInt("Pranzo"));
				comp.add(rs.getInt("Merenda"));
				comp.add(rs.getInt("Pernotto"));
				
			}
			
			rs.close();
			statement.close();
			closeConnection();
			return comp;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		return null;
	}

	/**
	 * Scrive le modifiche avvenute 
	 * 
	 * @param par i dettagli della competiizone 
	 */
	public void modificaCompetizione(ArrayList<Object> par) {
		
		int idC = (int) par.get(0);
		String tipo = (String) par.get(1);
		
		Date data = (Date) par.get(2);
		java.util.Calendar dataC = Calendar.getInstance();
		dataC.setTime(data);
		java.sql.Date dataComp = new java.sql.Date(dataC.getTime().getTime());
		
		String ora = (String) par.get(3);
		int nMin = (int) par.get(4);
		int nMax = (int) par.get(5);
		double prezzo = (double) par.get(6);
		int pranzo = (int) par.get(7);
		int merenda = (int) par.get(8);
		int pernotto = (int) par.get(9);
				
		String query = "UPDATE competizioni SET tipo = ?, dataCompetizione = ?, "
				+ "oraCompetizione = ?, numMinPart = ?, numMaxPart = ?, prezzo = ?, "
				+ "pranzo = ?, merenda = ?, pernotto = ? WHERE idCompetizione=?;";
		
		try {
			openConnection();
			statement = conn.prepareStatement(query);
			
			statement.setString(1, tipo);
			statement.setDate(2, dataComp);
			statement.setString(3, ora);
			statement.setInt(4, nMin);
			statement.setInt(5, nMax);
			statement.setDouble(6, prezzo);
			statement.setInt(7, pranzo);
			statement.setInt(8, merenda);
			statement.setInt(9, pernotto);
			statement.setInt(10, idC);
			
			statement.executeUpdate();
			
			if(pranzo == 0){
				String q1 = "UPDATE iscrizioni SET pranzo = 0 "
						+ "WHERE codiceCompetizione = ?;";
				
				statement = conn.prepareStatement(q1);
				
				statement.setInt(1, idC);
				
				statement.executeUpdate();
			}
			
			if(merenda == 0){
				String q1 = "UPDATE iscrizioni SET merenda = 0 "
						+ "WHERE codiceCompetizione = ?;";
				statement = conn.prepareStatement(q1);
				
				statement.setInt(1, idC);
				
				statement.executeUpdate();
			}
			
			if(pernotto == 0){
				String q1 = "UPDATE iscrizioni SET pernotto = 0 "
						+ "WHERE codiceCompetizione = ?;";
				statement = conn.prepareStatement(q1);
				
				statement.setInt(1, idC);
				
				statement.executeUpdate();
			}
			
			statement.close();
			closeConnection();
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
	}

	/**
	 * Restituisce l'anagrafica del manager di competizione
	 * 
	 * @return
	 */
	public ArrayList<Object> profiloMngCompetizione() {
		
		ArrayList<Object> mng = new ArrayList<Object>();
		String query = "SELECT nome, cognome, email FROM ManagerCompetizione "
				+ "WHERE username = ?;";
		
		try {
			openConnection();
			
			statement = conn.prepareStatement(query);
			
			statement.setString(1, user);
			
			rs = statement.executeQuery();
			
			while(rs.next()){
				
				mng.add(rs.getString("nome"));
				mng.add(rs.getString("cognome"));
				mng.add(rs.getString("email"));
				
			}
			
			closeConnection();
			rs.close();
			statement.close();
			return mng;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		return null;
	}

	/**
	 * Conferma le modifiche effettuate al profilo da parte del manager di comeptizione 
	 * 
	 * @param p
	 */
	public void confermaModificheMng(ArrayList<Object> p) {
		
		String nome = (String) p.get(0);
		String cognome = (String) p.get(1);
		String mail = (String) p.get(2);
		
		String query = "UPDATE managercompetizione SET nome = ?, cognome = ?, email = ? "
						+ "WHERE username = ?;";
		
		try {
			openConnection();
			statement = conn.prepareStatement(query);
			
			statement.setString(1, nome);
			statement.setString(2, cognome);
			statement.setString(3, mail);
			statement.setString(4, user);
			
			statement.executeUpdate();
			
			statement.close();
			closeConnection();
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
	}

	/**
	 * Lista delle competizioni
	 * 
	 * @return la lista delle competizioni
	 */
	public ArrayList<ArrayList<Object>> vediCompetizioni() {
		
		ArrayList<ArrayList<Object>> listaComp = new ArrayList<ArrayList<Object>>();
		
		String q1 = "SELECT codicemanager, idcompetizione, dataCompetizione, "
				+ "oraCompetizione, tipo, numminpart, nummaxpart, attiva "
				+ "FROM competizioni ORDER BY datacompetizione;";
		
		try {
			openConnection();
			statement = conn.prepareStatement(q1);
			rs = statement.executeQuery();
			while(rs.next()){
				ArrayList<Object> type = new ArrayList<Object>();
				
				type.add(rs.getInt("codicemanager"));
				type.add(rs.getDate("dataCompetizione"));
				type.add(rs.getString("oracompetizione"));
				type.add(rs.getString("tipo"));
				type.add(rs.getInt("numminpart"));
				type.add(rs.getInt("nummaxpart"));
				type.add(rs.getInt("attiva"));
				
				String id = String.valueOf(rs.getInt("idCompetizione"));
				int nIscr = getNumIscritti(id);
				
				type.add(nIscr);
				listaComp.add(type);
			}
			
			closeConnection();
			rs.close();
			statement.close();
			return listaComp;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		return null;
	}

	/**
	 * Lista dei manager di competizione
	 * 
	 * @return la lista dei manager di competiizone
	 */
	public ArrayList<ArrayList<Object>> vediMngCompetizioni() {
		
		ArrayList<ArrayList<Object>> mng = new ArrayList<ArrayList<Object>>();
		
		String query = "SELECT idmanager, cognome, nome, email "
				+ "FROM managercompetizione;";
		
		try {
			openConnection();
			
			statement = conn.prepareStatement(query);
			rs = statement.executeQuery();
			while(rs.next()){
				ArrayList<Object> m = new ArrayList<Object>();
				
				m.add(rs.getInt("idmanager"));
				m.add(rs.getString("cognome"));
				m.add(rs.getString("nome"));
				m.add(rs.getString("email"));
				
				mng.add(m);
				
			}
			
			closeConnection();
			rs.close();
			statement.close();
			return mng;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		
		return null;
	}

	/**
	 * Ottiene i dettagli degli optional 
	 * 
	 * @return
	 */
	public ArrayList<ArrayList<Object>> dettagliOptional() {
		
		String query = "SELECT * FROM TipiOptional;";
		ArrayList<ArrayList<Object>> lista = new ArrayList<ArrayList<Object>>();
		
		try {
			openConnection();
			statement = conn.prepareStatement(query);
			rs = statement.executeQuery();
			
			while(rs.next()){
				ArrayList<Object> l = new ArrayList<Object>();
				l.add(rs.getString("nome"));
				l.add(rs.getDouble("prezzo"));
				
				lista.add(l);
			}
			
			closeConnection();
			statement.close();
			rs.close();
			return lista;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		return null;
	}

	/**
	 * Ottiene i prezzi degli optional 
	 * 
	 * @return
	 */
	public ArrayList<Object> getPrezzi() {
		
		// merenda, pernotto, pranzo
		String query = "SELECT prezzo FROM TipiOptional;";
		ArrayList<Object> lista = new ArrayList<Object>();
		try {
			openConnection();
			statement = conn.prepareStatement(query);
			rs = statement.executeQuery();
			
			while(rs.next()){
				lista.add(rs.getDouble("prezzo"));
			}
			
			closeConnection();
			statement.close();
			rs.close();
			return lista;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		return null;
	}

	/**
	 * Conferma le modifiche ai prezzi degli optional 
	 * 
	 * @param p prezzi degli optional 
	 */
	public void confermaPrezzoOptional(ArrayList<Object> p) {
		
		double przPranzo = (double) p.get(0);
		double przMerenda = (double) p.get(1);
		double przPernotto = (double) p.get(2);
		String query = "";
		
		try {
			openConnection();
			
			query = "UPDATE TipiOptional SET prezzo = ? WHERE nome = 'pranzo';";
			
			statement = conn.prepareStatement(query);
			statement.setDouble(1, przPranzo);
			statement.executeUpdate();
			
			query = "UPDATE TipiOptional SET prezzo = ? WHERE nome = 'merenda';";
			
			statement = conn.prepareStatement(query);
			statement.setDouble(1, przMerenda);
			statement.executeUpdate();
			
			query = "UPDATE TipiOptional SET prezzo = ? WHERE nome = 'pernotto';";
			
			statement = conn.prepareStatement(query);
			statement.setDouble(1, przPernotto);
			statement.executeUpdate();
			
			closeConnection();
			statement.close();
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
	}

	/**
	 * Elimina un tipo di competizione 
	 * 
	 * @param type il tipo di competizione da eliminare
	 */
	public void eliminaTipoComp(String type) {
		
		String query = "DELETE FROM TipiCompetizione WHERE nome = ?;";
		
		try {
			openConnection();
			statement = conn.prepareStatement(query);
			statement.setString(1, type);
			statement.executeUpdate();
			
			statement.close();
			closeConnection();			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}

	}

	/**
	 * Aggiunge un tipo di competizione
	 * 
	 * @param type il tipo di competizione da aggiungere
	 */
	public void aggiungiTipoCompetizione(String type) {
		
		String query = "INSERT INTO TipiCompetizione VALUES (?);";
		
		try {
			openConnection();
			statement = conn.prepareStatement(query);
			statement.setString(1, type);
			statement.executeUpdate();
			
			statement.close();
			closeConnection();
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		
	}

	/**
	 * Ottiene la password
	 * 
	 * @param tipo tipo di utente
	 * @return la password dell'utente 
	 */
	public String getPassword(String tipo) {
		
		String query = "SELECT pass FROM "+tipo+" WHERE username = ?;";
		
		String p = "";
		
		try {
			openConnection();
			statement = conn.prepareStatement(query);

			statement.setString(1, user);
			rs = statement.executeQuery();
			while(rs.next()){
				p = rs.getString("pass");
			}
			
			closeConnection();
			statement.close();
			rs.close();
			return p;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		return null;
	}

	/**
	 * Ottiene la lista delle mail dei partecipanti iscritti ad una data competizione
	 * 
	 * @param idC il codice identificativo della competizione
	 * @return la lista delle mail
	 */
	public ArrayList<Object> getMailList(String idC) {
		
		String query = "";
		int id = 0;
		boolean intero = true;
		
		ArrayList<Object> mail = new ArrayList<Object>();
		if(idC.matches("[0-9]*")){
			id = Integer.parseInt(idC);
			query = "SELECT email FROM Partecipanti, Iscrizioni "
					+ "WHERE codiceCompetizione = ? AND "
							+ "CodicePartecipante = username";
			//intero = true;
		} else {
			query = "SELECT email FROM Partecipanti, Iscrizioni "
					+ "WHERE codiceCompetizione = ? AND "
							+ "CodicePartecipante = username";
			intero = false;
		}
		
		try {
			openConnection();
			statement = conn.prepareStatement(query);
			
			if(intero){
				statement.setInt(1, id);
			} else {
				statement.setString(1, idC);
			}
				
			
			rs = statement.executeQuery();
			while(rs.next()){
				mail.add(rs.getString("email"));
			}
			
			rs.close();
			statement.close();
			closeConnection();
			return mail;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		return null;
	}

	/**
	 * ottiene la mail di un utente 
	 * 
	 * @param p username e password dell'utente
	 * @return la mail dell'utente 
	 */
	public String getMail(ArrayList<Object> p) {
		
		String un = (String) p.get(0);
		String tipo = (String) p.get(1);
		
		String mail = "";
		String query = "SELECT email from "+tipo+" WHERE username = ?;";
		
		try {
			openConnection();
			statement = conn.prepareStatement(query);
		
			statement.setString(1, un);
			
			rs = statement.executeQuery();
			
			while(rs.next()){
				mail = rs.getString("email");
			}
			
			rs.close();
			statement.close();
			closeConnection();
			return mail;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}

		return null;
	}

	/**
	 * Dato l'id di una competizione ricavo l'email del manager che la gestisce
	 * 
	 * @param id l'id della competizione 
	 * @return la mail del manager che gestisce la competizione 
	 */
	public String getMailMng(String id) {
		
		String mail = "";
		String query = "SELECT email FROM Competizioni, ManagerCompetizione "
				+ "WHERE codiceManager = idManager "
				+ "AND idCompetizione = ?;";
		
		try {
			openConnection();
			statement = conn.prepareStatement(query);
			
			statement.setString(1, id);
			
			rs = statement.executeQuery();
			while(rs.next()){
				mail = rs.getString("email");
			}
			
			closeConnection();
			statement.close();
			rs.close();
			return mail;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		return null;
	}

	/**
	 * Ottiene la data di rilascio del certificato src
	 * 
	 * @return data di rilascio del certificato src
	 */
	public Date getDataSRC() {
		
		Date dataSRC = new Date();
		String query = "SELECT dataSRC FROM Partecipanti WHERE username = ?;";
		
		try {
			openConnection();
			statement = conn.prepareStatement(query);
			
			statement.setString(1, user);
			
			rs = statement.executeQuery();
			while(rs.next()){
				dataSRC = rs.getDate("dataSRC");
			}
			
			closeConnection();
			rs.close();
			statement.close();
			return dataSRC;
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		return null;
	}

	/**
	 * Ottiene il numero di iscritti ad una competizione 
	 * 
	 * @param id l'id della competizione
	 * @return il numero di iscritti a tale competizione 
	 */
	public int getNumIscritti(String id) {
		
		int cod = Integer.parseInt(id);
		int num = 0;
		String query = "SELECT COUNT(codicePartecipante) AS nIscritti "
						+ "FROM Iscrizioni "
						+ "WHERE CodiceCompetizione = ?;";
		
		try {
			openConnection();
			statement = conn.prepareStatement(query);
			
			statement.setInt(1, cod);
			
			ResultSet rs1 = statement.executeQuery();
			while(rs1.next()){
				num = rs1.getInt("nIscritti");
			}
			
			closeConnection();
			statement.close();
			rs1.close();
			return num;
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		return 0;
	}

	/**
	 * Riduce il numero di partecipanti in seguito ad una riduzione del numero
	 * massimo di partecipanti 
	 * 
	 * @param p id competizione e num max partecipanti
	 * @return gli indirizzi email dei partecipanti da eliminare
	 */
	public ArrayList<Object> riduciPartecipanti(ArrayList<Object> p) {
		
		int id = Integer.parseInt((String) p.get(0)); //id competizione
		int num = (int) p.get(1); //num max partecipanti 
		
		ArrayList<Object> mailList = new ArrayList<Object>();
		
		String query = "SELECT username, email FROM Partecipanti, Iscrizioni "
				+ "WHERE codiceCompetizione = ? AND "
						+ "username = codicePartecipante "
						+ "ORDER BY dataIscr;";
		
		try {
			openConnection();
			statement = conn.prepareStatement(query);
			
			statement.setInt(1, id);
			
			rs = statement.executeQuery();
			
			int type = 1;
			while(rs.next()){
				if(type > num){ 
					mailList.add(rs.getString("email"));
					String un = rs.getString("username");
					
					String q1 = "DELETE FROM Iscrizioni WHERE codicePartecipante = ?;";
					PreparedStatement s = conn.prepareStatement(q1);
					s.setString(1, un);
					s.executeUpdate();
					s.close();
				}
				type++;
			}
			closeConnection();
			statement.close();
			rs.close();
			return mailList;
			
		} catch (SQLException e) {
			e.toString();
		} catch (IOException e) {
			e.toString();
		}
		
		return null;
	}

}
