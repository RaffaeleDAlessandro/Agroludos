package entity.mngCompetizione;

import java.util.ArrayList;

import dataAccess.DAO;

/**
 * La classe si occupa della gestione dei manager di competizione, richiamando il 
 * dao
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class MngCompetizione implements IntWMngCompetizione, IntRMngCompetizione {

	private DAO d;
	
	/**
	 * Registrazione di un nuovo manager di competizione 
	 */
	public void registrazioneMngCompetizione(ArrayList<Object> p) {
		d = new DAO();
		d.registrazioneMngCompetizione(p);
	}

	/**
	 * Ottiene il profilo del manager di competizione 
	 */
	public ArrayList<Object> profiloMngCompetizione() {
		d = new DAO();
		return d.profiloMngCompetizione();
	}

	/**
	 * Scrive le modifiche al profilo del manager di competizione
	 */
	public void confermaModificheMng(ArrayList<Object> p) {
		d = new DAO();
		d.confermaModificheMng(p);
	}

	/**
	 * Ottiene la lista dei manager di competizione
	 */
	public ArrayList<ArrayList<Object>> vediMngCompetizioni() {
		d = new DAO();
		return d.vediMngCompetizioni();
	}

	/**
	 * Ottiene la mail del manager di una competizione 
	 */
	public String getMailMng(String id) {
		d = new DAO();
		return d.getMailMng(id);
	}

}
