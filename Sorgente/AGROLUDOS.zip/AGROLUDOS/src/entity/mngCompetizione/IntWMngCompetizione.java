package entity.mngCompetizione;

import java.util.ArrayList;

/**
 * Interfaccia in scrittura manager competiizone
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro 
 *
 */
public interface IntWMngCompetizione {

	/**
	 * Registrazione di un nuovo manager di competizione
	 * 
	 * @param par
	 */
	public void registrazioneMngCompetizione(ArrayList<Object> p);

	/**
	 * Scrive le modifiche avvenute al profilo del manager
	 * 
	 * @param p l'anagrafica
	 */
	public void confermaModificheMng(ArrayList<Object> p);
	
}
