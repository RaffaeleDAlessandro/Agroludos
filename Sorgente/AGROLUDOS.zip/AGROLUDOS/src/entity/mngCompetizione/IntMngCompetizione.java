package entity.mngCompetizione;

/**
 * Interfacce della classe MngCompetizione 
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro 
 *
 */
public class IntMngCompetizione {

	private static MngCompetizione p = new MngCompetizione();
	
	/**
	 * In scrittura 
	 * 
	 * @return manager
	 */
	public static IntWMngCompetizione getWMngCompetizione() {
		return p;
	}

	/**
	 * In lettura
	 * 
	 * @return manager
	 */
	public static IntRMngCompetizione getRMngCompetizione() {
		return p;
	}
	
}
