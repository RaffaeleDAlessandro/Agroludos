package entity.mngCompetizione;

import java.util.ArrayList;

/**
 * Interfaccia in lettura del manager di competizione
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public interface IntRMngCompetizione {

	/**
	 * Ottiene il profilo del Manager di competizione 
	 * 
	 * @return l'anagrafica del manager
	 */
	public ArrayList<Object> profiloMngCompetizione();

	/**
	 * Ottiene la lista dei manager di competiizone 
	 * 
	 * @return lista dei manager di competizione 
	 */
	public ArrayList<ArrayList<Object>> vediMngCompetizioni();
	
	/**
	 * Ottiene la mail del manager di comeptizione che gestisce la competizione  
	 * 
	 * @param id l'id della competiizone 
	 * @return l'indirizzo email del manager della competizione 
	 */
	public String getMailMng(String id);
	
}
