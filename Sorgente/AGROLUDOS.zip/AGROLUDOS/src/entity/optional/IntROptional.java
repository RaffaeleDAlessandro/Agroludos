package entity.optional;

import java.util.ArrayList;
/**
 * Interfaccia in lettura della classe optional
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public interface IntROptional {

	/**
	 * Restituisce i dettagli degli optional.
	 * 
	 * @return dettagli degli optional 
	 */
	public ArrayList<ArrayList<Object>> dettagliOptional();
	
	/**
	 * Ottiene i prezzi degli optional 
	 * 
	 * @return prezzi degli optional 
	 */
	public ArrayList<Object> getPrezzi();
}
