package entity.optional;

/**
 * Interfacce della classe Optional
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class IntOptional {

	private static Optional o = new Optional();
	
	/**
	 * In Lettura
	 * @return optional
	 */
	public static IntROptional getROptional(){
		return o;
	}
	
	/**
	 * 
	 * In scrittura
	 * @return optional
	 */
	public static IntWOptional getWOptional(){
		return o;
	}
	
}
