package entity.optional;

import java.util.ArrayList;

import dataAccess.DAO;

/**
 * La classe si occupa della gestione degli optional, richiamando il dao
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class Optional implements IntROptional, IntWOptional{

	private DAO d;
	
	/**
	 * Ottiene i dettagli degli optional 
	 */
	public ArrayList<ArrayList<Object>> dettagliOptional() {
		d = new DAO();
		return d.dettagliOptional();
	}

	/**
	 * Ottiene i prezzi degli optional 
	 */
	public ArrayList<Object> getPrezzi() {
		d = new DAO();
		return d.getPrezzi();
	}

	/**
	 * Scrive i prezzi degli optional 
	 */
	public void confermaPrezzoOptional(ArrayList<Object> p) {
		d = new DAO();
		d.confermaPrezzoOptional(p);
	}

}
