package entity.optional;
import java.util.ArrayList;

/**
 * Interfaccia in scrittura della classe Optional
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public interface IntWOptional {

	/**
	 * Conferma il prezzo degli optional
	 * 
	 * @param p i prezzi degli optional 
	 */
	public void confermaPrezzoOptional(ArrayList<Object> p);
	
}
