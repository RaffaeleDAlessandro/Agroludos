package entity.competizione;

import java.util.ArrayList;

/**
 * interfaccia in lettura delle Competizioni
 * @author Raffaele D' Alessandro, Marco Dispoto
 *
 */
public interface IntRCompetizione {
	
	/**
	 * ottiene tutti i dati della lista di competizioni disponibili 
	 * a cui � possibile iscriversi
	 * @return
	 */
	public ArrayList<ArrayList<Object>> leggiCompetizioni();

	/**
	 * ottiene la lista di competizioni gestite da un dato manager
	 * @param codice, identificatore del managar di cui si vogliono conoscere 
	 * le competizioni che gestisce
	 * @return
	 */
	public ArrayList<ArrayList<Object>> competizioniGestite();

	/**
	 * ottiene una data competizione gi� presente nel db
	 * @param id , identificatore univoco della competizione
	 * @return
	 */
	public ArrayList<Object> ottieniCompetizione(String id);
	
	/**
	 * ottine la lista di tutti gli optional disponibili per una competizione	
	 * @return
	 */
	public ArrayList<ArrayList<Object>> leggiOptional(ArrayList<Object> par);


	/**
	 * ottiene l' elenco dei partecipanti iscritti ad una competizione
	 * @param id l'identificativo della competizione
	 * @return
	 */
	public ArrayList<ArrayList<Object>> listaPartecipanti(String id);
	
	/**
	 * Restituisce i tipi di competizione disponibili
	 * 
	 * @return i tipi di competizione disponibili
	 */
	public ArrayList<Object> leggiTipiCompetizione();

	/**
	 * Legge tutte le competizioni 
	 * 
	 * @return la lista delle competizioni
	 */
	public ArrayList<ArrayList<Object>> vediCompetizioni();

	/**
	 * Riduce il numero di partecipanti in seguito ad una riduzione del numero 
	 * massimo di partecipanti
	 * 
	 * @param d id e numero massimo di partecipanti
	 * @return gli indirizzi email dei partecipanti eliminati 
	 */
	public ArrayList<Object> riduciPartecipanti(ArrayList<Object> d);
	
}
