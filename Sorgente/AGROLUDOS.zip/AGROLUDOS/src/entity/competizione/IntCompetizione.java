package entity.competizione;

/**
 * Interfacce della classe Competizione 
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro 
 *
 */
public class IntCompetizione {
	
	private static Competizione c = new Competizione();
	
	/**
	 * In scrittura
	 * 
	 * @return la competizione
	 */
	public static IntRCompetizione getRCompetizione(){
		return c;
	}
	
	/**
	 * In lettura
	 * 
	 * @return la competizione
	 */
	public static IntWCompetizione getWCompetizione(){
		return c;
	}
	
}
