package entity.competizione;

import java.util.ArrayList;

import dataAccess.DAO;

/**
 * La classe si occupa della gestione delle competizioni, richiamando il dao
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class Competizione implements IntWCompetizione, IntRCompetizione {

	private DAO d;
	
	/**
	 * Aggiunge una competizione
	 */
	public void nuovaCompetizione(ArrayList<Object> par) {
		d = new DAO();
		d.nuovo(par);
	}
	
	/**
	 * Modifica una competizione
	 */
	public void modificaCompetizione(ArrayList<Object> par) {
		d = new DAO();
		d.modificaCompetizione(par);
	}

	/**
	 * Ottiene la lista di tutte le competizioni, complete di dettagli
	 */
	public ArrayList<ArrayList<Object>> leggiCompetizioni() {
		d = new DAO();
		return d.getCompetizioni();
	}

	/**
	 * Restituisce le competizioni gestite da un manager
	 */
	public ArrayList<ArrayList<Object>> competizioniGestite() {
		d = new DAO();
		return d.competizioniGestite();
	}

	/**
	 * Ottiene una competizione
	 */
	public ArrayList<Object> ottieniCompetizione(String id) {
		d = new DAO();
		return d.ottieniCompetizione(id);
	}

	/**
	 * Restituisce gli optional disponibili per una data competizione
	 */
	public ArrayList<ArrayList<Object>> leggiOptional(ArrayList<Object> par) {
		d = new DAO();
		return d.leggiOptional(par);
	}
	
	/**
	 * Restituisce la lista dei partecipanti
	 */
	public ArrayList<ArrayList<Object>> listaPartecipanti(String id) {
		d = new DAO();
		return d.listaPartecipanti(id);
	}
	
	/**
	 * Legge i tipi di competizione disponibili
	 */
	public ArrayList<Object> leggiTipiCompetizione(){
		d = new DAO();
		return d.leggiTipiCompetizione();
	}

	/**
	 * Annulla una competizione
	 */
	public void annullaCompetizione(ArrayList<Object> p) {
		d = new DAO();
		d.annullaCompetizione(p);
	}

	/**
	 * Legge le competizioni disponibili
	 */
	public ArrayList<ArrayList<Object>> vediCompetizioni() {
		d = new DAO();
		return d.vediCompetizioni();
	}

	/**
	 * Elimina un tipo di competizione
	 */
	public void eliminaTipoCompetizione(String c) {
		d = new DAO();
		d.eliminaTipoComp(c);
	}

	/**
	 * Aggiunge un tipo di competizione
	 */
	public void aggiungiTipoCompetizione(String c) {
		d = new DAO();
		d.aggiungiTipoCompetizione(c);
	}

	/**
	 * Riduce il numero di partecipanti
	 */
	public ArrayList<Object> riduciPartecipanti(ArrayList<Object> p) {
		d = new DAO();
		return d.riduciPartecipanti(p);
	}
	
}
