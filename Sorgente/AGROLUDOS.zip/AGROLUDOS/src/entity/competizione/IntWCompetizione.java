package entity.competizione;

import java.util.ArrayList;

/**
 * interfaccia in scrittura delle competizioni
 * @author Raffaele D' Alessandro, Marco Dispoto
 *
 */
public interface IntWCompetizione {

	/**
	 * inserisce una nuova competizione nel db
	 */
	public void nuovaCompetizione(ArrayList<Object> par);

	/**
	 * modifica una competizione del db
	 * @param par contiene i dati da modificare
	 * @return
	 */
	public void modificaCompetizione(ArrayList<Object> par);	
	
	/**
	 * Annulla una competizione, senza cancellarla dal sistema.
	 * 
	 * @param p i dettagli della competiizone da eliminare
	 */
	public void annullaCompetizione(ArrayList<Object> p);
	
	/**
	 * Elimina un tipo di competizione tra quelli disponibili
	 * 
	 * @param c il tipo di competizione da eliminare
	 */
	public void eliminaTipoCompetizione(String c);

	/**
	 * Aggiunge un tipo di competiizone 
	 * 
	 * @param c il tipo di competizione da aggiungere
	 */
	public void aggiungiTipoCompetizione(String c);

}
