package entity.utente;

/**
 * Interfacce della classe Utente 
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro 
 *
 */
public class IntUtente {
	
	private static Utente u=new Utente();

	/**
	 * In lettura 
	 * @return utente 
	 */
	public static IntRUtente getRUtente(){
		return u;
	}

	/**
	 * In scrittura
	 * @return utente 
	 */
	public static IntWUtente getWUtente(){
		return u;
	}
	
}
