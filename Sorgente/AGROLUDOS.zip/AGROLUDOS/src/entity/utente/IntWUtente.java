package entity.utente;

import java.util.ArrayList;

/**
 * interfaccia in scrittura di un qualsiasi utente
 * @author Raffaele D' Alessandro, Marco Dispoto
 *
 */
public interface IntWUtente {

	/**
	 * Aggiorna la password di un utente
	 * @param par dettagli 
	 */
	public void aggiornaPassword(ArrayList<Object> par);

}

