package entity.utente;

import java.util.ArrayList;

import dataAccess.DAO;

/**
 * la classe si occupa della gestione degli utenti, richiamando il dao
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class Utente implements IntRUtente, IntWUtente {

	private DAO d;
	
	/**
	 * Effettua il login dell'utente 
	 */
	public int login(ArrayList<Object> p){
		d = new DAO();
		int tipo = 0;
		tipo = d.checkLogin(p);
		return tipo;
	}
	
	/**
	 * Aggiorna la password dell'utente 
	 */
	public void aggiornaPassword(ArrayList<Object> par) {
		d = new DAO();
		d.aggiornaPassword(par);
		
	}

	/**
	 * Controlla se esiste o meno l'username specificato dall'utente
	 */
	public boolean esisteUsername(String u) {
		d = new DAO();
		return d.esisteUsername(u);
	}

	/**
	 * Ottiene la mail dell'utente 
	 */
	public String getMail(ArrayList<Object> p) {
		d = new DAO();
		return d.getMail(p);
	}
	
	/**
	 * Ottiene la password dell'utente
	 */
	public String getPassword(String tipo) {
		d = new DAO();
		return d.getPassword(tipo);
	}
	

	
}
