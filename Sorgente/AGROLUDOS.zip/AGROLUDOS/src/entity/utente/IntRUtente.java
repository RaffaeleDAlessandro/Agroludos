package entity.utente;

import java.util.ArrayList;

/**
 * interfaccia in lettura di un qualsiasi utente
 * 
 * @author Raffaele D' Alessandro, Marco Dispoto
 *
 */
public interface IntRUtente {

	/**
	 * Login 
	 * @param p username e password
	 * @return tipo utente 
	 */
	public int login(ArrayList<Object> p);

	/**
	 * Controllo esistenza username 
	 * 
	 * @param u l'username specificato
	 * @return true se esiste, false altrimenti 
	 */
	public boolean esisteUsername(String u);

	/**
	 * Ottiene la mail di un utente 
	 * @param p dettagli utente 
	 * @return l'indirizzo mail
	 */
	public String getMail(ArrayList<Object> p);

	/**
	 * Ottiene la password dell'utente
	 * @param tipo il tipo di utente 
	 * @return
	 */
	public String getPassword(String tipo);
}
