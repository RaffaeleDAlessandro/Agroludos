package entity.partecipante;

import java.util.ArrayList;
import java.util.Date;

/**
 * Interfaccia in lettura del Partecipante
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public interface IntRPartecipante {

	/**
	 *  ottiene tutti i dati del partecipante
	 *  
	 * @param cf
	 * @return
	 */
	public ArrayList<Object> getPartecipante();
	
	/**
	 * ottiene la lista delle competizioni a cui il partecipante � iscritto
	 * @return lista iscrizioni
	 */
	public ArrayList<ArrayList<Object>> leggiIscrizioni();
	
	/**
	 * mostra gli optional scelti per una data competizione
	 * @param par 
	 * @return
	 */
	public ArrayList<ArrayList<Object>> leggiOptionalScelti(ArrayList<Object> par);
	
	/**
	 * ottiene la lista delle mail dei partecipanti a una data competizione??
	 * @param codiceComp
	 * @return
	 */
	public ArrayList<Object> getMailList(String codiceComp);

	/**
	 * Legge gli optional scelti
	 * 
	 * @param p dettagli
	 * @return lista degli optional scelti 
	 */
	public ArrayList<ArrayList<Object>> vediOptionalScelti(ArrayList<Object> p);

	/**
	 * Ottiene la data di rilascio del certificato src
	 * 
	 * @return la data di rilascio dell'src
	 */
	public Date getDataSRC();

	/**
	 * Ottiene il numero di iscritti per una competizione
	 * 
	 * @param id il codice identificativo della competizione
	 * @return il numero di iscritti per la competizione
	 */
	public int getNumIscritti(String id);
	
	/**
	 * Elimina i partecipanti in eccesso, nel caso in cui il numero massimo di 
	 * iscritti ad una competizione venga ridotto dal manager di competizione
	 * 
	 * @param p 
	 * @return
	 */
	public ArrayList<Object> riduciPartecipanti(ArrayList<Object> p);

}