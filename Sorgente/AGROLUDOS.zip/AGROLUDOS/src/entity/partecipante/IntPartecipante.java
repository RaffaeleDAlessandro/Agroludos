package entity.partecipante;

/**
 * Interfacce della classe Partecipante
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class IntPartecipante {

	private static Partecipante p = new Partecipante();
	
	/**
	 * In lettura
	 * 
	 * @return partecipante
	 */
	public static IntRPartecipante getRPartecipante(){
		return p;
	}
	
	/**
	 * In scrittura
	 * 
	 * @return partecipante
	 */
	public static IntWPartecipante getWPartecipante(){
		return p;
	}
	
}
