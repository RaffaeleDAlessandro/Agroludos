package entity.partecipante;

import java.util.ArrayList;

/**
 * Interfaccia in scrittura del Partecipante
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public interface IntWPartecipante {
	
	/**
	 * registra un nuovo partecipante nel database
	 * 
	 * @param par l'anagrafica del partecipante
	 */
	public void registrazionePartecipante(ArrayList<Object> par);

	/**
	 * iscrizione di un partecipante a una competizione 
	 * 
	 * @param par dettagli iscrizione 
	 * @return 
	 */
	public Object iscrizioneCompetizione(ArrayList<Object> par);
	
	/**
	 * cancellazione da una competizione
	 * @param par dettagli competiizone
	 */
	public void cancellaIscrizione(ArrayList<Object> p);
	
	/**
	 * modifica gli optional selezionati da un partecipante per una competizione
	 * @param par gli optional selezionati
	 */
	public void modificaOptionalSceltiM(ArrayList<Object> par);
	
	/**
	 * Modifica gli optional selezionati dal manager
	 * 
	 * @param par gli optional selezionati
	 */
	public void modificaOptionalSceltiP(ArrayList<Object> par);

	/**
	 * Scrive le modifiche al profilo del partecipante
	 * 
	 * @param par anagrafica 
	 */
	public void confermaModifichePart(ArrayList<Object> par);
	
}
