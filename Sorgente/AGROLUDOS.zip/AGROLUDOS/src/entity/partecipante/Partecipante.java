package entity.partecipante;

import java.util.ArrayList;
import java.util.Date;

import dataAccess.DAO;

/**
 * La classe si occupa della gestione dei partecipanti, richiamando il dao
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class Partecipante implements IntRPartecipante, IntWPartecipante{

	private DAO d;
	
	/**
	 * Registrazione di un nuovo partecipante 
	 */
	public void registrazionePartecipante(ArrayList<Object> par) {
		d = new DAO();
		d.registraPartecipante(par);
	}

	/**
	 * Iscrizione ad una competizione
	 */
	public Object iscrizioneCompetizione(ArrayList<Object> par) {
		d = new DAO();
		return d.iscrizioneCompetizione(par);
	}

	/**
	 * Rimuove l'iscrizione da una competizione 
	 */
	public void cancellaIscrizione(ArrayList<Object> p) {
		d = new DAO();
		d.eliminaIscrizione(p);
	}

	/**
	 * Legge gli optional scelti per una competizione 
	 */
	public ArrayList<ArrayList<Object>> vediOptionalScelti(ArrayList<Object> p) {
		d = new DAO();
		return d.vediOptionalScelti(p);
	}

	/**
	 * Modifica gli optional scelti dal manager
	 */
	public void modificaOptionalSceltiM(ArrayList<Object> par) {
		d = new DAO();
		d.modificaOptionalSceltiM(par);
	}
	
	/**
	 * modifica gli optional scelti dal partecipante 
	 */
	public void modificaOptionalSceltiP(ArrayList<Object> par){
		d = new DAO();
		d.modificaOptionalSceltiP(par);
	}
	
	/**
	 * Ottiene un parteciapnte 
	 */
	public ArrayList<Object> getPartecipante() {
		d = new DAO();
		return d.getPartecipante();
	}

	/**
	 * Ottiene la lista delle competizioni a cui il partecipante � iscritto
	 */
	public ArrayList<ArrayList<Object>> leggiIscrizioni() {
		d = new DAO();
		return d.leggiIscrizioni();
	}

	/**
	 * Legge gli optional scelti da un partecipante
	 */
	public ArrayList<ArrayList<Object>> leggiOptionalScelti(ArrayList<Object> par) {
		d = new DAO();
		return d.leggiOptionalScelti(par);
	}

	/**
	 * Ottiene la lista delle mail dei partecipanti iscritti ad una competizione
	 */
	public ArrayList<Object> getMailList(String idC) {
		d = new DAO();
		return d.getMailList(idC);
	}

	/**
	 * Scrive le modifiche avvenute al profilo del partecipante
	 */
	public void confermaModifichePart(ArrayList<Object> par) {
		d = new DAO();
		d.confermaModifichePart(par);
	}

	/**
	 * Ottiene la data di rilascio del certificato src
	 */
	public Date getDataSRC() {
		d = new DAO();
		return d.getDataSRC();
	}
	
	/**
	 * Ottiene il numero di iscritti ad una competizione 
	 */
	public int getNumIscritti(String id){
		d = new DAO();
		return d.getNumIscritti(id);
	}

	/**
	 * Riduce il numero di partecipanti in seguito ad una riduzione del numero 
	 * massimo di partecipanti
	 */
	public ArrayList<Object> riduciPartecipanti(ArrayList<Object> p) {
		d = new DAO();
		return d.riduciPartecipanti(p);
	}

}
