package ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * Menu Principale
 * 
 * @author Marco  Dispoto, Raffaele D'Alessandro
 *
 */
public class Menu extends MainMenu {

	private static final long serialVersionUID = 1L;
	private JTextField usernameField;
	private JPasswordField passwordField;
	
	/**
	 * Costruttore
	 */
	public Menu() {
		initComponents();
	}
	
	private void initComponents(){
		
		// -------LOGO-------
			JLabel lblLogo = new JLabel("");
			lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
			lblLogo.setIcon(new ImageIcon(Menu.class.getResource("/ui/Logo_Long.png")));
			lblLogo.setBounds(70, 15, 210, 65);
			getContentPane().add(lblLogo);
			
			//------SEPARATORE ALTO-----
			JSeparator separator = new JSeparator();
			separator.setBounds(15, 210, 320, 2);
			getContentPane().add(separator);
			
			//--------USERNAME--------
			JLabel lblUsername = new JLabel("Username:");
			lblUsername.setHorizontalAlignment(SwingConstants.CENTER);
			lblUsername.setBounds(65, 105, 75, 20);
			getContentPane().add(lblUsername);
			
			usernameField = new JTextField();
			usernameField.setToolTipText("Case sensitive");
			usernameField.setHorizontalAlignment(SwingConstants.LEFT);
			usernameField.setBounds(145, 105, 135, 20);
			getContentPane().add(usernameField);
			usernameField.setColumns(10);
			
			//--------PASSWORD----------
			JLabel lblPassword = new JLabel("Password:");
			lblPassword.setHorizontalAlignment(SwingConstants.CENTER);
			lblPassword.setBounds(65, 135, 75, 20);
			getContentPane().add(lblPassword);
			
			passwordField = new JPasswordField();
			passwordField.setToolTipText("Case sensitive");
			passwordField.setBounds(145, 135, 135, 20);
			getContentPane().add(passwordField);
			
			//----------BOTTONE LOGIN-----------
			JButton btnAccedi = new JButton("Accedi");
			btnAccedi.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					login();
				}
			});
			btnAccedi.setBounds(125, 170, 100, 30);
			getContentPane().add(btnAccedi);
			
			
			
			//----------SEPARATORE BASSO----------
			JSeparator separator_1 = new JSeparator();
			separator_1.setBounds(10, 95, 320, 2);
			getContentPane().add(separator_1);
			
			//---------BOTTONE REGISTRATI--------
			JButton btnRegistrati = new JButton("Registrati");
			btnRegistrati.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					openJFrame("registrazione");
				}

			});
			btnRegistrati.setBounds(125, 225, 100, 30);
			getContentPane().add(btnRegistrati);
		
	}
	
	private void login() {
		
		try {
			
			String username = usernameField.getText();
			String password = String.valueOf(passwordField.getPassword());
			
			ArrayList<Object> p = new ArrayList<Object>();
			p.add(username);
			p.add(password);
			
			openJFrame("login", p);

		
		} catch(SecurityException e) {
			return;
		}
	}
	
		
}
