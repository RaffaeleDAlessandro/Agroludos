package ui;

import java.awt.Font;
import java.awt.Toolkit;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import presentation.FrontController;

/**
 * Classe astratta MainMenu dalla quale tutte le ui erediteranno
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public abstract class MainMenu extends JFrame {

	private static final long serialVersionUID = 1L;

	/**
	 * Costruttore
	 */
	protected MainMenu() {

		setSize(350, 300);
		setResizable(false);
		setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setTitle("AGROLUDOS");
		
		setFont(new Font("Verdana", Font.PLAIN, 10));
		setIconImage(Toolkit.getDefaultToolkit().getImage
				(MainMenu.class.getResource("/ui/Logo_Icon.png")));
			
	}
	
	protected void openJFrame(String nFrame, ArrayList<Object> par) {
		
		FrontController fc = new FrontController();
		JFrame frame = new JFrame();
		
		//Punta a questo JFrame
		JFrame f = (JFrame) SwingUtilities.getRoot(this);
		
		try {
			
			fc.processRequest(nFrame, frame, par);
			
			//chiude il frame precedente
			f.dispose();
			
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
	}
	
	
	protected void openJFrame(String nFrame) {
		
		FrontController fc = new FrontController();
		JFrame frame = new JFrame();
		
		//Punta a questo JFrame
		JFrame f = (JFrame) SwingUtilities.getRoot(this);
		
		try {
			
			fc.processRequest(nFrame, frame, null);
			
			//chiude il frame precedente
			f.dispose();
			
		} catch (ClassNotFoundException e) {
			e.toString();
		} catch (InstantiationException e) {
			e.toString();
		} catch (IllegalAccessException e) {
			e.toString();
		} catch (NoSuchMethodException e) {
			e.toString();
		} catch (SecurityException e) {
			e.toString();
		}
		
	}
	
	protected String rep(String s){
		
		if(s.contains("'")){
			return s = s.replace("'", "''");
		}
		return s;
		
	}

}
