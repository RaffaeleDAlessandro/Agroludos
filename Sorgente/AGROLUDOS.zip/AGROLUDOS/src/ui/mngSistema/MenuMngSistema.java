package ui.mngSistema;

import ui.MainMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;

import javax.swing.JButton;
import javax.swing.JSeparator;

/**
 * Menu principale del manager di sistema 
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class MenuMngSistema extends MainMenu {

	private static final long serialVersionUID = 1L;

	public MenuMngSistema() {
		initComponents();
	}
	
	private void initComponents(){
		
		setSize(350, 390);
		
		JLabel lblTitolo = new JLabel("<html><h4>Scegli un' operazione :</h4></html>");
		lblTitolo.setBounds(26, 21, 147, 32);
		getContentPane().add(lblTitolo);

		//-------------VISUALIZZA COMPETIZIONI
		JButton btnCompetizioniPresenti = new JButton("<html><p align=\"Center\">Visualizza competizioni <br>concluse e in atto</p> </html>\r\n");
		btnCompetizioniPresenti.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("vediCompetizioni"); //OK
			}
		});
		btnCompetizioniPresenti.setBounds(85, 255, 180, 40);
		getContentPane().add(btnCompetizioniPresenti);

		JButton btnManager = new JButton("<html><p align=\"Center\">Visualizza manager </p></html>\r\n");
		btnManager.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("vediMngCompetizioni"); 
			}
		});
		btnManager.setBounds(85, 200, 180, 40);
		getContentPane().add(btnManager);

		//------------logout
		JButton btnLogout = new JButton("Logout");
		btnLogout.setBounds(125, 325, 100, 23);
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openJFrame("menu");	
			}
		});
		getContentPane().add(btnLogout);
		
		JButton btnTipiCompetizioni = new JButton("<html><p align=\"Center\"> Gestione competizioni </p></html>");
		btnTipiCompetizioni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("gestioneCompetizioni");
				
			}
		});
		btnTipiCompetizioni.setBounds(85, 90, 180, 40);
		getContentPane().add(btnTipiCompetizioni);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 59, 324, 2);
		getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 310, 324, 2);
		getContentPane().add(separator_1);
		
		JButton btnTipiOptional = new JButton("<html><p align=\"Center\"> Gestione optional </p></html>");
		btnTipiOptional.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("gestioneOptional");
			}
		});
		btnTipiOptional.setBounds(85, 145, 180, 40);
		getContentPane().add(btnTipiOptional);
	}
}
