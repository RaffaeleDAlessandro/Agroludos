package ui.mngSistema;

import ui.MainMenu;
import utility.ControlloDati;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.JTextField;

/**
 * Mostra i tipi di competizione disponibili 
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class TipiCompetizione extends MainMenu {
	
	private static final long serialVersionUID = 1L;
	private JTextField textNuovoTipoCompetizione;
	protected String competizioneSelezionata;
	private JComboBox<String> cmbTipiCompetizione;

	public TipiCompetizione(ArrayList<Object> lista) {

		initComponents(lista);
	}
	
	private void initComponents(ArrayList<Object> lista){
		
		setSize(330, 225);

		//-------------LISTA COMPETIZIONI-------
		JLabel lblCompetizioni = new JLabel("<html><h4>Tipi di competizione</h4></html>");
		lblCompetizioni.setBounds(32, 11, 122, 25);
		getContentPane().add(lblCompetizioni);

		cmbTipiCompetizione = new JComboBox<String>();
		cmbTipiCompetizione.setBounds(30, 55, 150, 25);
		getContentPane().add(cmbTipiCompetizione);
		
		for(int i = 0; i < lista.size(); i++){
			cmbTipiCompetizione.addItem((String) lista.get(i));
		}

		//----------------ELIMINA COMPETIZIONE-------
		JButton btnEliminaOptional = new JButton("Elimina");
		btnEliminaOptional.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				competizioneSelezionata = cmbTipiCompetizione.getSelectedItem().toString();
				
				int reply = JOptionPane.showConfirmDialog(null, 
						"Vuoi davvero eliminare il tipo di competizione? "
						+ "Verr� impedita l'organizzazione di nuove competizioni di "
						+ "questo tipo, ma quelle gi� organizzate non verranno annullate.", 
						"Conferma cancellazione", JOptionPane.YES_NO_OPTION);
				
				if(reply == JOptionPane.YES_OPTION){
				
					ArrayList<Object> p = new ArrayList<Object>();
					p.add(competizioneSelezionata);
					openJFrame("eliminaTipoComp", p);
				}
			}		
		});

		btnEliminaOptional.setBounds(200, 55, 100, 25);
		getContentPane().add(btnEliminaOptional);

		textNuovoTipoCompetizione = new JTextField();
		textNuovoTipoCompetizione.setBounds(30, 100, 150, 25);
		getContentPane().add(textNuovoTipoCompetizione);
		textNuovoTipoCompetizione.setColumns(10);

		JButton btnAggiungiTipoCompetizione = new JButton("Aggiungi \r\n");
		btnAggiungiTipoCompetizione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				int reply = JOptionPane.showConfirmDialog(null, 
						"Vuoi davvero aggiungere il tipo di competizione?", 
						"Conferma aggiunta", JOptionPane.YES_NO_OPTION);
				
				if(reply == JOptionPane.YES_OPTION){
				
					String c = textNuovoTipoCompetizione.getText();
					boolean checkTipo = ControlloDati.controlloTipo(c);
					
					if(checkTipo){
						ArrayList<Object> p = new ArrayList<Object>();
						p.add(rep(c));
						openJFrame("aggiungiTipoCompetizione", p);
					}
				}

			}
		});
		btnAggiungiTipoCompetizione.setBounds(200, 100, 100, 25);
		getContentPane().add(btnAggiungiTipoCompetizione);

		JSeparator separator = new JSeparator();
		separator.setBounds(10, 144, 305, 3);
		getContentPane().add(separator);

		JButton btnIndietro = new JButton("<  Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("menuMngSistema");
			}
		});
		btnIndietro.setBounds(115, 160, 100, 25);
		getContentPane().add(btnIndietro);

	}

}
