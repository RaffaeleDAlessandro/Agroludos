package ui.mngSistema;

import ui.MainMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

/**
 * Mostra tutti i manager di competizione 
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class VediMngCompetizioni extends MainMenu {

	private static final long serialVersionUID = 1L;
	//private JTable table;	

	public VediMngCompetizioni(ArrayList<ArrayList<Object>> mng) {
		initComponents(mng);
	}
	
	private void initComponents(ArrayList<ArrayList<Object>> mng){
		
		setSize(500, 300);
		
		JLabel lblTitolo = new JLabel("<html><h4>Lista manager di competizione:</h4></html>");
		lblTitolo.setBounds(10, 10, 222, 32);
		getContentPane().add(lblTitolo);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 53, 474, 152);
		getContentPane().add(scrollPane);
		
		DefaultTableModel model = new DefaultTableModel();
		
		model.addColumn("ID");
		model.addColumn("Cognome");
		model.addColumn("Nome");
		model.addColumn("E-mail");
		
		JTable table = new JTable(model);
		
		if(mng.size() != 0){
			//aggiungo le righe alla tabella
			for(int i = 0; i < mng.size(); i++){
				
				Object[] row = mng.get(i).toArray();
				model.addRow(row);
			}
			
		}
		
		TableColumnModel tcm = table.getColumnModel();
		tcm.getColumn(0).setPreferredWidth(30);
		tcm.getColumn(1).setPreferredWidth(75);
		tcm.getColumn(2).setPreferredWidth(75);
		
		//centro gli elementi all'interno delle celle della tabella
		JLabel label = (JLabel) table.getDefaultRenderer(Object.class);
		label.setHorizontalAlignment (SwingConstants.CENTER);
		
		scrollPane.setViewportView(table);
		
		JButton btnIndietro = new JButton("< Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			openJFrame("menuMngSistema");
			}
		});
		btnIndietro.setBounds(200, 223, 100, 23);
		getContentPane().add(btnIndietro);
		
	}
}
