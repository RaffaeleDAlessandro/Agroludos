package ui.mngSistema;

import ui.MainMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JSeparator;

/**
 * Mostra i prezzi degli optional 
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class PrezzoOptional extends MainMenu {
	
	private static final long serialVersionUID = 1L;
	private JTextField txtPranzo;
	private JTextField txtMerenda;
	private JTextField txtPernotto;

	public PrezzoOptional(ArrayList<Object> lista) {
		initComponents(lista);
	}
	
	private void initComponents(ArrayList<Object> lista){
		
		setSize(240, 275);
		
		JLabel lblmodificaPrezzi = new JLabel("<html><h4>Modifica Prezzi :</h4></html>");
		lblmodificaPrezzi.setBounds(23, 11, 147, 32);
		getContentPane().add(lblmodificaPrezzi);
		
		JLabel lblPranzo = new JLabel("Pranzo:");
		lblPranzo.setBounds(20, 54, 75, 22);
		getContentPane().add(lblPranzo);
		
		JLabel lblMerenda = new JLabel("Merenda:");
		lblMerenda.setBounds(20, 87, 74, 22);
		getContentPane().add(lblMerenda);
		
		JLabel lblPernotto = new JLabel("Pernotto:");
		lblPernotto.setBounds(20, 120, 74, 22);
		getContentPane().add(lblPernotto);
		
		txtPranzo = new JTextField(String.valueOf(lista.get(2)));
		txtPranzo.setColumns(10);
		txtPranzo.setBounds(115, 54, 100, 22);
		getContentPane().add(txtPranzo);
		
		txtMerenda = new JTextField(String.valueOf(lista.get(0)));
		txtMerenda.setColumns(10);
		txtMerenda.setBounds(115, 87, 100, 22);
		getContentPane().add(txtMerenda);
		
		txtPernotto = new JTextField(String.valueOf(lista.get(1)));
		txtPernotto.setColumns(10);
		txtPernotto.setBounds(115, 120, 100, 22);
		getContentPane().add(txtPernotto);
		
		JLabel label_1 = new JLabel("\u20AC");
		label_1.setBounds(99, 124, 12, 14);
		getContentPane().add(label_1);
		
		JLabel label = new JLabel("\u20AC");
		label.setBounds(99, 91, 12, 14);
		getContentPane().add(label);
		
		JLabel label_2 = new JLabel("\u20AC");
		label_2.setBounds(99, 58, 12, 14);
		getContentPane().add(label_2);
		
		JButton btnConferma = new JButton("Conferma");
		btnConferma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				ArrayList<Object> prz = new ArrayList<Object>();
				prz.add(Double.valueOf(txtPranzo.getText()));
				prz.add(Double.valueOf(txtMerenda.getText()));
				prz.add(Double.valueOf(txtPernotto.getText()));
				
				openJFrame("confermaPrezzoOptional", prz);
				
			}
		});
		btnConferma.setBounds(70, 160, 100, 23);
		getContentPane().add(btnConferma);
		
		//---------------INDIETRO-------
		JButton indietroBtn = new JButton("< Indietro");
		indietroBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("gestioneOptional");
			}
		});
		indietroBtn.setBounds(70, 210, 100, 25);
		
		getContentPane().add(indietroBtn);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 195, 218, 8);
		getContentPane().add(separator);
		
	}

}
