package ui.mngSistema;

import ui.MainMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

/**
 * Mostra i tipi di optional 
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class TipiOptional extends MainMenu {

	private static final long serialVersionUID = 1L;
	//private JTable table;
	protected Object optionalSelezionato;

	public TipiOptional(ArrayList<ArrayList<Object>> lista) {
		initComponents(lista);
	}

	private void initComponents(ArrayList<ArrayList<Object>> lista) {
		
		setSize(350, 270);
		
		//------------LISTA OPTIONAL------------
		JLabel lblOptional = new JLabel("<html><h4>Tipi di Optional: </h4></html>");
		lblOptional.setBounds(20, 11, 122, 25);
		getContentPane().add(lblOptional);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 48, 324, 75);
		getContentPane().add(scrollPane);

		DefaultTableModel model = new DefaultTableModel();
		model.addColumn("Tipo Optional");
		model.addColumn("Prezzo (�)");
		
		JTable table = new JTable(model);

		if(lista.size() != 0){
			//aggiungo le righe alla tabella
			for(int i = 0; i < lista.size(); i++){
				
				Object[] row = lista.get(i).toArray();
				model.addRow(row);
			}
			
		}
		JLabel label = (JLabel) table.getDefaultRenderer(Object.class);
		label.setHorizontalAlignment (SwingConstants.CENTER);
		
		scrollPane.setViewportView(table);

		JButton btnIndietro = new JButton("<  Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("menuMngSistema");
			}
		});
		btnIndietro.setBounds(110, 205, 100, 25);
		getContentPane().add(btnIndietro);
		
		JButton btnModificaPrezzi = new JButton("<html><p align=\"Center\"> Modifica<br> prezzi</p></html>");
		btnModificaPrezzi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				openJFrame("modPrezzoOptional");
			}
		});
		btnModificaPrezzi.setBounds(115, 137, 89, 33);
		getContentPane().add(btnModificaPrezzi);

		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 187, 300, 2);
		getContentPane().add(separator_1);
	}

}
