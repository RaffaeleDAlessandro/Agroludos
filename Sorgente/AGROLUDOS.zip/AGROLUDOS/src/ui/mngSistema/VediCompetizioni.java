package ui.mngSistema;

import ui.MainMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

/**
 * Mostra tutte le competizioni
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class VediCompetizioni extends MainMenu {

	private static final long serialVersionUID = 1L;
	//private JTable table;
	
	public VediCompetizioni(ArrayList<ArrayList<Object>> listaComp) {
		
		initComponents(listaComp);
		
	}

	private void initComponents(ArrayList<ArrayList<Object>> listaComp){
		
		setSize(700, 300);
		
		JLabel lblTitolo = new JLabel("<html><h4>Lista competizioni:</h4></html>");
		lblTitolo.setBounds(10, 10, 222, 32);
		getContentPane().add(lblTitolo);

		//-----------TABELLA
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 53, 674, 160);
		getContentPane().add(scrollPane);
		
		DefaultTableModel model = new DefaultTableModel();
		
		model.addColumn("Manager");
		model.addColumn("Data");
		model.addColumn("Ora");
		model.addColumn("Tipo");
		model.addColumn("N. min partecipanti");
		model.addColumn("N. max partecipanti");
		model.addColumn("Attiva");
		model.addColumn("N. iscritti");
		
		JTable table = new JTable(model);
		
		if(listaComp.size() != 0){
			//aggiungo le righe alla tabella
			for(int i = 0; i < listaComp.size(); i++){
				
				Object[] row = listaComp.get(i).toArray();
				model.addRow(row);
			}
			
		}
		
		TableColumnModel tcm = table.getColumnModel();
		tcm.getColumn(0).setPreferredWidth(40);
		tcm.getColumn(1).setPreferredWidth(60);
		tcm.getColumn(2).setPreferredWidth(30);
		tcm.getColumn(3).setPreferredWidth(150);
		tcm.getColumn(6).setPreferredWidth(30);
		//centro gli elementi all'interno delle celle della tabella
		JLabel label = (JLabel) table.getDefaultRenderer(Object.class);
		label.setHorizontalAlignment (SwingConstants.CENTER);
		
		scrollPane.setViewportView(table);
		
		//------------indietro-----------
		JButton btnIndietro = new JButton("< Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("menuMngSistema");
			}
		});
		btnIndietro.setBounds(300, 229, 100, 23);
		getContentPane().add(btnIndietro);
		

	}
	
}
