package ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;

/**
 * Menu di scelta per registrarsi come Partecipante o Manager di Competizione
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class Registrazione extends MainMenu {

	private static final long serialVersionUID = 1L;
	
	/**
	 * Costruttore
	 */
	public Registrazione() {
		initComponents();
	}
	
	private void initComponents(){
		
		JLabel lblTitolo = new JLabel("Scegliere il tipo di registrazione che si vuole effettuare: ");
		lblTitolo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitolo.setBounds(15, 60, 320, 15);
		getContentPane().add(lblTitolo);
		
		JButton btnPartecipante = new JButton("Partecipante");
		btnPartecipante.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openJFrame("nuovoPartecipante");
			}
		});
		btnPartecipante.setToolTipText("I partecipanti possono iscriversi alle competizioni.");
		btnPartecipante.setBounds(40, 108, 125, 50);
		getContentPane().add(btnPartecipante);
		
		JButton btnManagerCompetizione = new JButton("<html><p align='center'>Manager di Competizione</p></html>");
		btnManagerCompetizione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openJFrame("nuovoMngCompetizione");
			}
		});
		btnManagerCompetizione.setToolTipText("I Manager di Competizione gestiscono le competizioni.");
		btnManagerCompetizione.setBounds(180, 108, 125, 50);
		getContentPane().add(btnManagerCompetizione);
		
		JButton btnIndietro = new JButton("< Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openJFrame("menu");
			}
		});
		btnIndietro.setBounds(125, 225, 100, 25);
		getContentPane().add(btnIndietro);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(26, 210, 297, 3);
		getContentPane().add(separator);
	}
	
}