package ui;

import utility.ControlloDati;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;

/**
 * Classe per la modifica della Password
 * @author Raffaele D' Alessandro, Marco Dispoto
 *
 */
public class ModificaPassword extends MainMenu {
	
	private static final long serialVersionUID = 1L;
	private String passwordAttuale;
	private String passwordNuova;
	private String confermaPassword;
	private String tipo;

	private JPasswordField passwordAttualeField;
	private JPasswordField passwordNuovaField;
	private JPasswordField ripetiPasswordField;

	/**
	 * Costruttore
	 */
	public ModificaPassword(ArrayList<Object> p) {
		initComponent(p);
	}

	private void initComponent(ArrayList<Object> p) {

		tipo = (String) p.get(0);
		
		setSize(320, 290); 


		JLabel lblmodificaCredenzialiDi = new JLabel("<html><h4>Modifica password:</h4></html>");
		lblmodificaCredenzialiDi.setBounds(23, 11, 197, 32);
		getContentPane().add(lblmodificaCredenzialiDi);

		JSeparator separator = new JSeparator();
		separator.setBounds(10, 47, 291, 2);
		getContentPane().add(separator);

		//---------------------password attuale 
		JLabel lblPasswordAttuale = new JLabel("Password attuale: ");
		lblPasswordAttuale.setBounds(10, 90, 120, 14);
		getContentPane().add(lblPasswordAttuale);

		passwordAttualeField = new JPasswordField();
		passwordAttualeField.setBounds(140, 87, 160, 20);
		getContentPane().add(passwordAttualeField);

		//------------nuova password

		JLabel label_1 = new JLabel("Password: ");
		label_1.setBounds(10, 118, 120, 14);
		getContentPane().add(label_1);

		passwordNuovaField = new JPasswordField();
		passwordNuovaField.setBounds(140, 113, 160, 20);
		getContentPane().add(passwordNuovaField);

		//-----------------ripeti password

		JLabel label_2 = new JLabel("Ripeti password: ");
		label_2.setBounds(10, 143, 120, 14);
		getContentPane().add(label_2);


		ripetiPasswordField = new JPasswordField();
		ripetiPasswordField.setBounds(140, 139, 160, 20);
		getContentPane().add(ripetiPasswordField);

		//----------------CONFERMA
		JButton btnConferma = new JButton("Conferma");
		btnConferma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				passwordAttuale = String.valueOf(passwordAttualeField.getPassword());

				passwordNuova = String.valueOf(passwordNuovaField.getPassword());
				confermaPassword = String.valueOf(ripetiPasswordField.getPassword());

				controlli();
			}

		});
		btnConferma.setBounds(109, 180, 100, 23);
		getContentPane().add(btnConferma);

		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 214, 299, 2);
		getContentPane().add(separator_1);

		//-----------------BOTTONE INDIETRO
		JButton indietroBtn = new JButton("< Indietro");
		indietroBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				if("ManagerCompetizione".compareTo(tipo) == 0){
					openJFrame("menuMngCompetizione");
				} else if("Partecipanti".compareTo(tipo) == 0){
					openJFrame("menuPartecipante");
				}
				
			}
		});
		indietroBtn.setBounds(109, 227, 100, 23);
		getContentPane().add(indietroBtn);

	}

	private void controlli() {


		if(ControlloDati.confrontoPass(passwordNuova, confermaPassword)){
			boolean checkpassword=ControlloDati.controlloPassword(passwordNuova);

			if(checkpassword){
				conferma();	
			}
		}
	}
	
	private void conferma() {

		ArrayList<Object> anagrafica = new ArrayList<Object>();

		anagrafica.add(passwordNuova);
		anagrafica.add(passwordAttuale);
		anagrafica.add(tipo);
		
		openJFrame("aggiornaPassword", anagrafica);
	}

}
