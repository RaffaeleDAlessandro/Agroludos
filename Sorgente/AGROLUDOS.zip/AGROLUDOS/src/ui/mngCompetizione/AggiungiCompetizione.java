package ui.mngCompetizione;

import ui.MainMenu;
import utility.ControlloDati;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import javax.swing.JTextField;

import com.toedter.calendar.JDateChooser;

/**
 * Inserimento di una nuova competizione 
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class AggiungiCompetizione extends MainMenu {
	
	private static final long serialVersionUID = 1L;
	private JTextField numMinField;
	private JTextField numMaxField;
	private JTextField prezzoField;
	private JDateChooser dateChooser;

	private JComboBox<String> cmbTipoComp;
	private JComboBox<String> cmbOra; 
	private JComboBox<String> cmbMinuti; 

	private JCheckBox chckbxPranzo;
	private JCheckBox chckbxMerenda;
	private JCheckBox chckbxPernotto;

	public AggiungiCompetizione(ArrayList<Object> par) {
		initComponent(par);
	}

	public void initComponent(ArrayList<Object> par){

		setSize(430, 365);

		JLabel lblinserisciUnaCompetizione = new JLabel("<html><h4>Inserisci una competizione :</h4></html>");
		lblinserisciUnaCompetizione.setBounds(25, 21, 186, 32);
		getContentPane().add(lblinserisciUnaCompetizione);

		//-------------TIPO DI COMPETIZIONE
		JLabel lblTipoCompetizione = new JLabel("Tipo competizione :");
		lblTipoCompetizione.setBounds(10, 67, 113, 21);
		getContentPane().add(lblTipoCompetizione);

		cmbTipoComp = new JComboBox<String>();
		cmbTipoComp.setBounds(140, 67, 150, 20); //------------da riempire la combobox in base alla query
		getContentPane().add(cmbTipoComp);

		for(int i = 0; i < par.size(); i++){
			cmbTipoComp.addItem((String) par.get(i));
		}

		//-----------------data
		JLabel lblData = new JLabel("Data :");
		lblData.setBounds(10, 92, 98, 21);
		getContentPane().add(lblData);

		dateChooser = new JDateChooser();
		dateChooser.setBounds(122, 93, 113, 20);
		getContentPane().add(dateChooser);

		//-----------------ora

		JLabel lblOra = new JLabel("Ora :\r\n");
		lblOra.setBounds(245, 92, 38, 21);
		getContentPane().add(lblOra);

		cmbOra = new JComboBox<String>();
		cmbOra.setBounds(288, 92, 43, 20);
		getContentPane().add(cmbOra);
		for(int i=0;i<24;i++){
			if(i < 10){
				cmbOra.addItem("0"+String.valueOf(i));
			} else {
				cmbOra.addItem(String.valueOf(i));
			}
		}
		cmbOra.setSelectedIndex(0);

		JLabel label = new JLabel(" :\r\n");
		label.setBounds(337, 92, 15, 21);
		getContentPane().add(label);


		cmbMinuti = new JComboBox<String>();
		cmbMinuti.setBounds(358, 92, 43, 20);
		getContentPane().add(cmbMinuti);
		for(int i = 0; i < 60; i++){

			if(i < 10){
				cmbMinuti.addItem("0"+String.valueOf(i));
			} else {
				cmbMinuti.addItem(String.valueOf(i));
			}	
		}
		cmbMinuti.setSelectedIndex(0);

		//-----------NUMERO MINIMO E MASSIMO  DI PARTECIPANTI
		JLabel lblnumeroMassimoPartecipanti = new JLabel("<html>Numero massimo <br> partecipanti :</html>");
		lblnumeroMassimoPartecipanti.setBounds(219, 129, 119, 32);
		getContentPane().add(lblnumeroMassimoPartecipanti);

		JLabel lblnumeroMinimoPartecipanti = new JLabel("<html>Numero minimo<br> partecipanti :</html>");
		lblnumeroMinimoPartecipanti.setBounds(10, 129, 98, 32);
		getContentPane().add(lblnumeroMinimoPartecipanti);

		numMinField = new JTextField();
		numMinField.setToolTipText("immettere numeri arabi");
		numMinField.setColumns(10);
		numMinField.setBounds(122, 135, 74, 20);
		getContentPane().add(numMinField);

		numMaxField = new JTextField();
		numMaxField.setToolTipText("immettere numeri arabi");
		numMaxField.setColumns(10);
		numMaxField.setBounds(336, 135, 74, 20);
		getContentPane().add(numMaxField);


		//-------------PREZZO
		JLabel lblPrezzo = new JLabel("Prezzo :");
		lblPrezzo.setBounds(10, 172, 74, 21);
		getContentPane().add(lblPrezzo);

		JLabel label_1 = new JLabel("\u20AC");
		label_1.setBounds(108, 172, 15, 21);
		getContentPane().add(label_1);

		prezzoField = new JTextField();
		prezzoField.setColumns(10);
		prezzoField.setBounds(122, 172, 74, 20);
		getContentPane().add(prezzoField);

		JSeparator separator = new JSeparator();
		separator.setBounds(14, 59, 396, 2);
		getContentPane().add(separator);

		//---------------optional
		JLabel lblOptional = new JLabel("Optional:");
		lblOptional.setBounds(10, 204, 74, 21);
		getContentPane().add(lblOptional);

		chckbxPranzo = new JCheckBox("Pranzo");
		chckbxPranzo.setBounds(95, 200, 75, 23);
		getContentPane().add(chckbxPranzo);

		chckbxMerenda = new JCheckBox("Merenda");
		chckbxMerenda.setBounds(190, 200, 75, 23);
		getContentPane().add(chckbxMerenda);

		chckbxPernotto = new JCheckBox("Pernotto");
		chckbxPernotto.setBounds(285, 200, 75, 23);
		getContentPane().add(chckbxPernotto);

		//----------------CONFERMA CREAZIONE COMPETIZIONE
		JButton button = new JButton("Conferma");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				String tipoCompetizione = cmbTipoComp.getSelectedItem().toString();

				Date dataCompetizione = dateChooser.getDate();
				String ora = String.valueOf(cmbOra.getSelectedItem());
				String minuti = String.valueOf(cmbMinuti.getSelectedIndex());
				if("0".compareTo(minuti) == 0){
					minuti = minuti + "0";
				}
				String oraCompetizione = ora + ":" + minuti; 
				String numMinPart = numMinField.getText();
				String numMaxPart = numMaxField.getText();
				String prezzo = prezzoField.getText(); 

				boolean checkTipo = ControlloDati.controlloTipo(tipoCompetizione);
				boolean checkData = ControlloDati.controllaDataCompetizione(dataCompetizione);
				boolean checkNumMinEMax = ControlloDati.controllaNumPartecipanti(numMinPart, numMaxPart);
				boolean checkPrezzo = ControlloDati.controllaPrezzo(prezzo);


				ArrayList<Object> competizione = new ArrayList<Object>();
				
				competizione.add(rep(tipoCompetizione));

				if(checkTipo && checkData && checkNumMinEMax && checkPrezzo){

					int numero = Integer.parseInt(numMinPart);
					int nMinPart = numero;
					numero = Integer.parseInt(numMaxPart);
					int nMaxPart = numero;

					int pranzoFlag = 0;
					int merendaFlag = 0;
					int pernottoFlag = 0;
					
					double prezzoComp = Double.valueOf(prezzo);

					competizione.add(dateChooser.getDate());	
					competizione.add(oraCompetizione);
					competizione.add(nMaxPart);
					competizione.add(nMinPart);
					competizione.add(prezzoComp);

					if(chckbxPranzo.isSelected()){
						pranzoFlag = 1;
					}

					if(chckbxMerenda.isSelected()){
						merendaFlag = 1;
					}

					if(chckbxPernotto.isSelected()){
						pernottoFlag = 1;
					}

					competizione.add(pranzoFlag);
					competizione.add(merendaFlag);
					competizione.add(pernottoFlag);
					openJFrame("inserisciCompetizione", competizione);
				}

			}
		});
		button.setBounds(165, 249, 100, 23);
		getContentPane().add(button);

		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(14, 283, 396, 7);
		getContentPane().add(separator_2);


		//-------------indietro
		JButton btnIndietro = new JButton("< Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("menuMngCompetizione");
			}
		});
		btnIndietro.setBounds(165, 301, 100, 25);
		getContentPane().add(btnIndietro);


	}
}
