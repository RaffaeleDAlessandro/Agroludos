package ui.mngCompetizione;

import ui.MainMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;

/**
 * Mostra il profilo del manager di competizione
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class ProfiloMngCompetizione extends MainMenu {

	private static final long serialVersionUID = 1L;

	public ProfiloMngCompetizione(ArrayList<Object> lista) {
		initComponents(lista);
	}
	
	private void initComponents(ArrayList<Object> lista){
		
		setSize(370, 270);

		JLabel lblTitolo = new JLabel("<html><h3>Informazioni generali dell' account:</h3></html>");
		lblTitolo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitolo.setBounds(39, 11, 292, 38);
		getContentPane().add(lblTitolo);

		JSeparator separator = new JSeparator();
		separator.setBounds(10, 48, 335, 2);
		getContentPane().add(separator);

		//--------------NOME -------
		JLabel lblNome = new JLabel("Nome: ");
		lblNome.setBounds(10, 60, 100, 15);
		getContentPane().add(lblNome);

		String nomeUtente = (String) lista.get(0);
		JLabel lblNomeUtente = new JLabel(nomeUtente);
		lblNomeUtente.setBounds(113, 60, 151, 14);
		getContentPane().add(lblNomeUtente);


		//---------------COGNOME------
		JLabel lblCognome = new JLabel("Cognome: ");
		lblCognome.setBounds(10, 84, 100, 15);
		getContentPane().add(lblCognome);

		String cognomeUtente = (String) lista.get(1);
		JLabel lblcognomeutente = new JLabel(cognomeUtente);
		lblcognomeutente.setBounds(113, 88, 151, 14);
		getContentPane().add(lblcognomeutente);


		//----------MAIL ---------
		JLabel lblMail = new JLabel("Indirizzo E-Mail:");
		lblMail.setBounds(10, 110, 100, 14);
		getContentPane().add(lblMail);

		String indirizzo=(String) lista.get(2);
		JLabel lblindirizzoutente = new JLabel(indirizzo);
		lblindirizzoutente.setBounds(113, 113, 151, 14);
		getContentPane().add(lblindirizzoutente);

		JButton btnModifica = new JButton("Modifica");
		btnModifica.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				openJFrame("modificaDatiManager");
			}
		});
		btnModifica.setBounds(135, 150, 100, 25);
		getContentPane().add(btnModifica);

		JButton btnIndietro = new JButton("< Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("menuMngCompetizione");
			}
		});
		btnIndietro.setBounds(135, 202, 100, 25);
		getContentPane().add(btnIndietro);

		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(21, 189, 324, 2);
		getContentPane().add(separator_1);
	}
}
