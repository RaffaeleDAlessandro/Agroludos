package ui.mngCompetizione;

import ui.MainMenu;
import utility.ControlloDati;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * Mostra il form di modifica del profilo del manager
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class ModificaDatiManager extends MainMenu {

	private static final long serialVersionUID = 1L;
	private JTextField nomeField;
	private JTextField cognomeField;
	private JTextField emailField;

	private String nome;
	private String cognome;
	private String email;

	public ModificaDatiManager(ArrayList<Object> lista) {
		initComponents(lista);
	}
	
	private void initComponents(ArrayList<Object> lista){
		
		setSize(370, 260);

		JLabel lblTitolo = new JLabel("<html><h3>Modifica dati Manager</h3></html>");
		lblTitolo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitolo.setBounds(15, 11, 340, 32);
		getContentPane().add(lblTitolo);

		JSeparator separator = new JSeparator();
		separator.setBounds(20, 52, 324, 2);
		getContentPane().add(separator);

		//--------------NOME -------
		JLabel lblNome = new JLabel("Nome: ");
		lblNome.setBounds(10, 65, 100, 15);
		getContentPane().add(lblNome);

		String nomeutente = (String) lista.get(0);
		nomeField = new JTextField(nomeutente);
		nomeField.setBounds(114, 62, 237, 20);
		getContentPane().add(nomeField);
		nomeField.setColumns(10);

		//-----------COGNOME---------------
		String cognomeutente = (String) lista.get(1);
		JLabel lblCognome = new JLabel("Cognome: ");
		lblCognome.setBounds(10, 91, 100, 15);
		getContentPane().add(lblCognome);

		cognomeField = new JTextField(cognomeutente);
		cognomeField.setColumns(10);
		cognomeField.setBounds(114, 88, 237, 20);
		getContentPane().add(cognomeField);

		//----------MAIL ---------
		JLabel lblMail = new JLabel("Indirizzo E-Mail:");
		lblMail.setBounds(10, 117, 100, 14);
		getContentPane().add(lblMail);

		emailField = new JTextField((String) lista.get(2));
		emailField.setColumns(10);
		emailField.setBounds(114, 114, 237, 20);
		getContentPane().add(emailField);

		// ---------- BOTTONE CONFERMA --------------
		JButton btnConferma = new JButton("Conferma");
		btnConferma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				nome = nomeField.getText();
				cognome = cognomeField.getText();
				email = emailField.getText();

				controlli();
				
							}
		});
		btnConferma.setBounds(135, 145, 100, 23);
		getContentPane().add(btnConferma);



		//---------- INDIETRO -----------
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 510, 324, 2);
		getContentPane().add(separator_1);
		
				JButton btnIndietro = new JButton("< Indietro");
				btnIndietro.setBounds(135, 192, 100, 25);
				btnIndietro.addActionListener(new ActionListener() {

					public void actionPerformed(ActionEvent e) {
						openJFrame("profiloMngCompetizione");
					}
				});
				getContentPane().add(btnIndietro);

		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(20, 179, 324, 2);
		getContentPane().add(separator_2);
	}

	/**
	 * metodo per controllare i dati inseriti dall' utente
	 */
	private void controlli(){

		
		boolean checkNome = ControlloDati.controllaNome(nome);
		boolean checkCognome = ControlloDati.controllaCognome(cognome);
		boolean checkEmail = ControlloDati.controllaEmail(email);
		
		if(checkNome && checkCognome &&checkEmail){
			conferma();
		}
	}
	
	/**
	 * 
	 */
	private void conferma(){
		
		ArrayList<Object> anagrafica = new ArrayList<Object>();
		anagrafica.add(rep(nome));
		anagrafica.add(rep(cognome));
		anagrafica.add(email);
		
		openJFrame("confermaModificheMng", anagrafica);

	}
}
