package ui.mngCompetizione;

import ui.MainMenu;
import utility.ControlloDati;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import javax.swing.JTextField;

import com.toedter.calendar.JDateChooser;

/**
 * Mostra la finestra di modifica della competizione 
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class ModificaCompetizione extends MainMenu {

	private static final long serialVersionUID = 1L;

	private int idCompetizione;
	private JTextField nMinPartField;
	private JTextField txtTipoComp;
	private JTextField prezzoField;

	private JDateChooser dateChooser;

	private JComboBox<String> cmbMinuti;
	private JComboBox<String> cmbOra;

	private JTextField nMaxPartField;

	private JCheckBox chckbxPranzo;
	private JCheckBox chckbxMerenda;
	private JCheckBox chckbxPernotto;

	private int pranzoFlag = 0;
	private int merendaFlag = 0;
	private int pernottoFlag = 0;

	public ModificaCompetizione(ArrayList<Object> competizione) {
		initComponents(competizione);
	}

	private void initComponents(ArrayList<Object> competizione){

		idCompetizione = (int) competizione.get(0);

		setSize(430, 365);

		JLabel lblmodificaCompetizione = new JLabel("<html><h4>Modifica competizione :</h4></html>");
		lblmodificaCompetizione.setBounds(32, 11, 186, 32);
		getContentPane().add(lblmodificaCompetizione);

		JSeparator separator = new JSeparator();
		separator.setBounds(20, 54, 396, 2);
		getContentPane().add(separator);

		JLabel lblTipoComp = new JLabel("Tipo competizione: ");
		lblTipoComp.setBounds(10, 67, 113, 21);
		getContentPane().add(lblTipoComp);

		txtTipoComp = new JTextField((String) competizione.get(1));
		txtTipoComp.setBounds(118, 67, 176, 21);
		getContentPane().add(txtTipoComp);
		txtTipoComp.setColumns(10);
		//--------------data

		JLabel lblDataComp = new JLabel("Data :");
		lblDataComp.setBounds(10, 99, 98, 21);
		getContentPane().add(lblDataComp);

		dateChooser = new JDateChooser();
		dateChooser.setBounds(118, 100, 115, 20);
		getContentPane().add(dateChooser);

		dateChooser.setDate((Date) competizione.get(2));

		//-----------------ora

		String ora = (String) competizione.get(3);

		int o;
		int m;

		if(ora.length()==5){
			o = Integer.parseInt(ora.substring(0, 2));
			m = Integer.parseInt(ora.substring(3, 5));
		} 
		else
		{
			o = Integer.parseInt(ora.substring(0, 1));
			m = Integer.parseInt(ora.substring(2, 4));
		}

		JLabel lblOra = new JLabel("Ora :\r\n");
		lblOra.setBounds(256, 99, 38, 21);
		getContentPane().add(lblOra);

		cmbOra = new JComboBox<String>();
		cmbOra.setBounds(304, 99, 43, 20);
		getContentPane().add(cmbOra);
		for(int i=0;i<24;i++){
			if(i < 10){
				cmbOra.addItem("0"+String.valueOf(i));
			} else {
				cmbOra.addItem(String.valueOf(i));
			}
		}
		cmbOra.setSelectedIndex(o); // selezionare un valore specifico nella combobox.
		
		JLabel label_3 = new JLabel(" :\r\n");
		label_3.setBounds(351, 99, 15, 21);
		getContentPane().add(label_3);


		cmbMinuti = new JComboBox<String>();
		cmbMinuti.setBounds(371, 99, 43, 20);
		getContentPane().add(cmbMinuti);
		for(int i=0;i<60;i++){
			if(i < 10){
				cmbMinuti.addItem("0"+String.valueOf(i));
			} else {
				cmbMinuti.addItem(String.valueOf(i));
			}
		}
		cmbMinuti.setSelectedIndex(m); // selezionare un valore specifico nella combobox.metodo simile "cmbMinuti.setSelectedItem(arg0);"


		JLabel lblnMaxPartecipanti = new JLabel("<html>Numero massimo <br> partecipanti :</html>");
		lblnMaxPartecipanti.setBounds(219, 129, 119, 32);
		getContentPane().add(lblnMaxPartecipanti);

		JLabel lblnMinPartecipanti = new JLabel("<html>Numero minimo<br> partecipanti :</html>");
		lblnMinPartecipanti.setBounds(10, 129, 98, 32);
		getContentPane().add(lblnMinPartecipanti);

		int nMin = (int) competizione.get(5);

		nMinPartField = new JTextField(String.valueOf(nMin));
		nMinPartField.setColumns(10);
		nMinPartField.setBounds(118, 135, 74, 20);
		getContentPane().add(nMinPartField);

		int nMax = (int) competizione.get(4);

		nMaxPartField = new JTextField(String.valueOf(nMax));
		nMaxPartField.setColumns(10);
		nMaxPartField.setBounds(336, 135, 74, 20);
		getContentPane().add(nMaxPartField);


		//-------------PREZZO
		JLabel lblPrezzo = new JLabel("Prezzo :");
		lblPrezzo.setBounds(10, 172, 74, 21);
		getContentPane().add(lblPrezzo);

		JLabel label_4 = new JLabel("\u20AC");
		label_4.setBounds(108, 172, 15, 21);
		getContentPane().add(label_4);

		double prezzoZ = (double) competizione.get(6);

		prezzoField = new JTextField(String.valueOf(prezzoZ)); //fare il cast dopo!!
		prezzoField.setColumns(10);
		prezzoField.setBounds(122, 172, 74, 20);
		getContentPane().add(prezzoField);

		//---------------optional
		JLabel lblOptional = new JLabel("Optional:");
		lblOptional.setBounds(10, 204, 74, 21);
		getContentPane().add(lblOptional);		

		/*
		 * 
		 * checkbox da abilitare o disabilitare a seconda dell'esito della query
		 * sulla disponibilit� dell'optional per la data competizione. 
		 * Da Spuntare se l'optional � stato previsto per quella competizione.
		 * 
		 */
		chckbxPranzo = new JCheckBox("Pranzo");
		chckbxPranzo.setBounds(95, 203, 75, 23);
		getContentPane().add(chckbxPranzo);

		chckbxMerenda = new JCheckBox("Merenda");
		chckbxMerenda.setBounds(190, 203, 75, 23);
		getContentPane().add(chckbxMerenda);

		chckbxPernotto = new JCheckBox("Pernotto");
		chckbxPernotto.setBounds(285, 203, 75, 23);
		getContentPane().add(chckbxPernotto);

		pranzoFlag = (int) competizione.get(7);
		merendaFlag = (int) competizione.get(8);
		pernottoFlag = (int) competizione.get(9);

		if(pranzoFlag == 1){
			chckbxPranzo.setSelected(true);
		} else {
			chckbxPranzo.setSelected(false);
		}

		if(merendaFlag == 1){
			chckbxMerenda.setSelected(true);
		} else {
			chckbxMerenda.setSelected(false);
		}

		if(pernottoFlag == 1){
			chckbxPernotto.setSelected(true);
		} else {
			chckbxPernotto.setSelected(false);
		}

		//----------------CONFERMA CREAZIONE COMPETIZIONE
		JButton btnConferma = new JButton("Conferma");
		btnConferma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				ArrayList<Object> c = new ArrayList<Object>();
				c.add(idCompetizione);

				String numMinPart = nMinPartField.getText();
				String numMaxPart = nMaxPartField.getText();
				String prezzo = prezzoField.getText();

				//boolean checkDataMod = ControlloDati.controlloDataModifica(dateChooser.getDate());
				boolean checkData = ControlloDati.controllaDataCompetizione(dateChooser.getDate());
				boolean checkNumMinEMax = ControlloDati.controllaNumPartecipanti(numMinPart, numMaxPart);
				boolean checkPrezzo = ControlloDati.controllaPrezzo(prezzo);

				c.add(rep(txtTipoComp.getText()));
				
				if(checkData&& checkNumMinEMax && checkPrezzo){
					c.add(dateChooser.getDate());	

					String ore = String.valueOf(cmbOra.getSelectedItem()) + ":" + 
							String.valueOf(cmbMinuti.getSelectedItem());

					c.add(ore);
					c.add(Integer.valueOf(nMinPartField.getText()));
					c.add(Integer.parseInt(nMaxPartField.getText()));
					c.add(Double.valueOf(prezzoField.getText()));

					if(chckbxPranzo.isSelected()){
						pranzoFlag = 1;
					} else {
						pranzoFlag = 0;
					}

					if(chckbxMerenda.isSelected()){
						merendaFlag = 1;
					} else {
						merendaFlag = 0;
					}

					if(chckbxPernotto.isSelected()){
						pernottoFlag = 1;
					} else {
						pernottoFlag = 0;
					}

					c.add(pranzoFlag);
					c.add(merendaFlag);
					c.add(pernottoFlag);

					openJFrame("modificaCompetizione", c);
				}
			}
		});
		btnConferma.setBounds(165, 249, 100, 23);
		getContentPane().add(btnConferma);

		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(14, 283, 396, 7);
		getContentPane().add(separator_2);


		//-------------indietro
		JButton btnIndietro = new JButton("< Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("competizioniGestite");
			}
		});
		btnIndietro.setBounds(165, 301, 100, 25);
		getContentPane().add(btnIndietro);


	}
}
