package ui.mngCompetizione;

import ui.MainMenu;
import utility.ControlloDati;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * Registrazione di un nuovo Manager di Competizione
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class NuovoMngCompetizione extends MainMenu {

	private static final long serialVersionUID = 1L;
	private JTextField nomeField;
	private JTextField cognomeField;
	private JTextField emailField;
	private JTextField usernameField;
	private JPasswordField passwordField;
	private JPasswordField ripetiPasswordField;

	private String nome;
	private String cognome;
	private String email;
	private String username;
	private String password;
	private String passwordC;

	public NuovoMngCompetizione() {
		initComponents();
	}
	
	public NuovoMngCompetizione(ArrayList<Object> p){
		initComponents(p);
	}

	private void initComponents(ArrayList<Object> p) {
		
		setSize(350, 330);

		JLabel lblTitolo = new JLabel("<html><h4>Registrazione nuovo Manager<h4></html>");
		lblTitolo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitolo.setBounds(10, 20, 324, 14);
		getContentPane().add(lblTitolo);

		JSeparator separator = new JSeparator();
		separator.setBounds(10, 50, 324, 2);
		getContentPane().add(separator);

		// ----------- NOME ------------
		JLabel lblNome = new JLabel("Nome: ");
		lblNome.setBounds(10, 65, 100, 15);
		getContentPane().add(lblNome);

		nomeField = new JTextField((String) p.get(0));
		nomeField.setBounds(114, 62, 220, 20);
		getContentPane().add(nomeField);
		nomeField.setColumns(10);

		//-----------COGNOME---------------
		JLabel lblCognome = new JLabel("Cognome: ");
		lblCognome.setBounds(10, 91, 100, 15);
		getContentPane().add(lblCognome);

		cognomeField = new JTextField((String) p.get(1));
		cognomeField.setColumns(10);
		cognomeField.setBounds(114, 88, 220, 20);
		getContentPane().add(cognomeField);


		// -------- E-MAIL -----------------
		JLabel lblEmail = new JLabel("Indirizzo E-Mail:");
		lblEmail.setBounds(10, 117, 100, 14);
		getContentPane().add(lblEmail);

		emailField = new JTextField((String) p.get(2));
		emailField.setColumns(10);
		emailField.setBounds(114, 114, 220, 20);
		getContentPane().add(emailField);

		// ------------ USERNAME ---------------
		JLabel lblUsername = new JLabel("Username: ");
		lblUsername.setBounds(10, 141, 100, 14);
		getContentPane().add(lblUsername);

		usernameField = new JTextField();
		usernameField.setColumns(10);
		usernameField.setBounds(114, 138, 220, 20);
		getContentPane().add(usernameField);

		//-------------- PASSWORD --------------
		JLabel lblPassword = new JLabel("Password: ");
		lblPassword.setBounds(10, 166, 100, 14);
		getContentPane().add(lblPassword);

		passwordField = new JPasswordField();
		passwordField.setBounds(114, 163, 220, 20);
		getContentPane().add(passwordField);

		// ----------- RIPETI PASSWORD --------
		JLabel lblRipetiPassword = new JLabel("Ripeti password: ");
		lblRipetiPassword.setBounds(10, 191, 100, 14);
		getContentPane().add(lblRipetiPassword);

		ripetiPasswordField = new JPasswordField();
		ripetiPasswordField.setBounds(114, 188, 220, 20);
		getContentPane().add(ripetiPasswordField);

		// ---------- BOTTONE CONFERMA --------------
		JButton btnConferma = new JButton("Conferma");
		btnConferma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				nome = nomeField.getText();
				cognome = cognomeField.getText();
				email = emailField.getText();
				username = usernameField.getText();
				password = String.valueOf(passwordField.getPassword());
				passwordC = String.valueOf(ripetiPasswordField.getPassword());

				controlli();
				// ...................................................

			}
		});
		btnConferma.setBounds(124, 219, 100, 23);
		getContentPane().add(btnConferma);

		// -----------SEPARATORE-----------
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 253, 324, 2);
		getContentPane().add(separator_1);

		//---------- INDIETRO ----------		
		JButton btnIndietro = new JButton("< Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openJFrame("registrazione");
			}
		});
		btnIndietro.setBounds(124, 266, 100, 25);
		getContentPane().add(btnIndietro);


		
	}

	private void initComponents() {
		
		setSize(350, 330);

		JLabel lblTitolo = new JLabel("<html><h4>Registrazione nuovo Manager<h4></html>");
		lblTitolo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitolo.setBounds(10, 20, 324, 14);
		getContentPane().add(lblTitolo);

		JSeparator separator = new JSeparator();
		separator.setBounds(10, 50, 324, 2);
		getContentPane().add(separator);

		// ----------- NOME ------------
		JLabel lblNome = new JLabel("Nome: ");
		lblNome.setBounds(10, 65, 100, 15);
		getContentPane().add(lblNome);

		nomeField = new JTextField();
		nomeField.setBounds(114, 62, 220, 20);
		getContentPane().add(nomeField);
		nomeField.setColumns(10);

		//-----------COGNOME---------------
		JLabel lblCognome = new JLabel("Cognome: ");
		lblCognome.setBounds(10, 91, 100, 15);
		getContentPane().add(lblCognome);

		cognomeField = new JTextField();
		cognomeField.setColumns(10);
		cognomeField.setBounds(114, 88, 220, 20);
		getContentPane().add(cognomeField);


		// -------- E-MAIL -----------------
		JLabel lblEmail = new JLabel("Indirizzo E-Mail:");
		lblEmail.setBounds(10, 117, 100, 14);
		getContentPane().add(lblEmail);

		emailField = new JTextField();
		emailField.setColumns(10);
		emailField.setBounds(114, 114, 220, 20);
		getContentPane().add(emailField);

		// ------------ USERNAME ---------------
		JLabel lblUsername = new JLabel("Username: ");
		lblUsername.setBounds(10, 141, 100, 14);
		getContentPane().add(lblUsername);

		usernameField = new JTextField();
		usernameField.setColumns(10);
		usernameField.setBounds(114, 138, 220, 20);
		getContentPane().add(usernameField);

		//-------------- PASSWORD --------------
		JLabel lblPassword = new JLabel("Password: ");
		lblPassword.setBounds(10, 166, 100, 14);
		getContentPane().add(lblPassword);

		passwordField = new JPasswordField();
		passwordField.setBounds(114, 163, 220, 20);
		getContentPane().add(passwordField);

		// ----------- RIPETI PASSWORD --------
		JLabel lblRipetiPassword = new JLabel("Ripeti password: ");
		lblRipetiPassword.setBounds(10, 191, 100, 14);
		getContentPane().add(lblRipetiPassword);

		ripetiPasswordField = new JPasswordField();
		ripetiPasswordField.setBounds(114, 188, 220, 20);
		getContentPane().add(ripetiPasswordField);

		// ---------- BOTTONE CONFERMA --------------
		JButton btnConferma = new JButton("Conferma");
		btnConferma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				nome = nomeField.getText();
				cognome = cognomeField.getText();
				email = emailField.getText();
				username = usernameField.getText();
				password = String.valueOf(passwordField.getPassword());
				passwordC = String.valueOf(ripetiPasswordField.getPassword());

				controlli();
				// ...................................................

			}
		});
		btnConferma.setBounds(124, 219, 100, 23);
		getContentPane().add(btnConferma);

		// -----------SEPARATORE-----------
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 253, 324, 2);
		getContentPane().add(separator_1);

		//---------- INDIETRO ----------		
		JButton btnIndietro = new JButton("< Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openJFrame("registrazione");
			}
		});
		btnIndietro.setBounds(124, 266, 100, 25);
		getContentPane().add(btnIndietro);


	}

	/**
	 * metodo per il controllo sui dati inseriti dall' utente
	 */
	private void controlli(){
		// --------------------------------------------------------------------------------------------- DAO
		if(ControlloDati.confrontoPass(password, passwordC)){
			
			boolean checkNome = ControlloDati.controllaNome(nome);
			boolean checkCognome = ControlloDati.controllaCognome(cognome);
			boolean checkEmail = ControlloDati.controllaEmail(email);
			boolean checkusername = ControlloDati.controlloUserName(username);
			boolean checkpassword = ControlloDati.controlloPassword(password);

			if(checkCognome && checkNome && checkEmail && checkusername && checkpassword){
				conferma(); //se i dati sono corretti allora si pu� procedere con l' inserimento del nuovo manager
			}
		}

	}
	
	/**
	 * 
	 */
	private void conferma(){
		
		ArrayList<Object> anagrafica = new ArrayList<Object>();
		
		anagrafica.add(rep(nome));
		anagrafica.add(rep(cognome));
		anagrafica.add(email);
		anagrafica.add(username);
		anagrafica.add(password);
		
		openJFrame("registrazioneMngCompetizione", anagrafica);
		
	}


}