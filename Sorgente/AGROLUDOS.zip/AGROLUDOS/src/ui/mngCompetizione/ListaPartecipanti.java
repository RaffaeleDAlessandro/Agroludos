package ui.mngCompetizione;

import ui.MainMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

/**
 * Mostra i partecipanti iscritti ad una competizione 
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class ListaPartecipanti extends MainMenu {
	
	private static final long serialVersionUID = 1L;
	private JTable table;

	public ListaPartecipanti(ArrayList<ArrayList<Object>> listaPart) {
		initComponents(listaPart);
	}
	
	private void initComponents(final ArrayList<ArrayList<Object>> listaPart){
		
		setSize(750, 400);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 50, 724, 211);
		getContentPane().add(scrollPane);
		
		DefaultTableModel model = new DefaultTableModel();
		model.addColumn("Codice Fiscale");
		model.addColumn("Cognome");
		model.addColumn("Nome");
		model.addColumn("Data di nascita");
		model.addColumn("Data rilascio SRC");
		model.addColumn("E-mail");
		
		if(listaPart.size() != 0){
			
			//aggiungo le righe alla tabella
			//in ultima posizione c'� l'id della competizione
			for(int i = 0; i < listaPart.size()-1; i++){
				
				Object[] row = listaPart.get(i).toArray();
				model.addRow(row);
			}
		}
		
		table = new JTable(model);
		
		//setto la larghezza della colonna del codice fiscale ad una dimensione
		// prefissata
		TableColumnModel tcm = table.getColumnModel();
		tcm.getColumn(0).setPreferredWidth(85);
		tcm.getColumn(3).setPreferredWidth(50);
		tcm.getColumn(4).setPreferredWidth(50);
		
		//centro gli elementi all'interno delle celle della tabella
		JLabel label = (JLabel) table.getDefaultRenderer(Object.class);
		label.setHorizontalAlignment (SwingConstants.CENTER);
		
		scrollPane.setViewportView(table);
		
		JLabel lblTitolo = new JLabel("<html><h3>Lista partecipanti: </h3></html>");
		lblTitolo.setBounds(25, 11, 366, 28);
		getContentPane().add(lblTitolo);
		
		JButton btnOptionalSelezionati = new JButton("Optional selezionati");
		btnOptionalSelezionati.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				
				if(table.getSelectedRow() == -1){

					JOptionPane.showMessageDialog(null, "SELEZIONARE UNA COMPETIZIONE", "ERRORE",
							JOptionPane.ERROR_MESSAGE);

				}else{
					
					int i = table.getSelectedRow(); 
					
					ArrayList<Object> p = new ArrayList<Object>();
					p.add(listaPart.get(listaPart.size()-1).get(0)); 
					p.add(listaPart.get(i).get(6)); 
					openJFrame("vediOptionalPartecipante", p);
				}
				
			}
		});
		btnOptionalSelezionati.setBounds(150, 285, 150, 25);
		getContentPane().add(btnOptionalSelezionati);
		
		JButton btnEliminaPartecipante = new JButton("Elimina partecipante");
		btnEliminaPartecipante.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//ELIMINAZIONE PARTECIPANTE
				
				int i = table.getSelectedRow();
				
				ArrayList<Object> p = new ArrayList<Object>();
				p.add(listaPart.get(listaPart.size()-1).get(0));
				p.add(listaPart.get(i).get(6));
				
				int reply = JOptionPane.showConfirmDialog(null, 
						"Vuoi davvero eliminare questo partecipante?", 
						"Conferma eliminazione", JOptionPane.YES_NO_OPTION);
				
				if(reply == JOptionPane.YES_OPTION){
					openJFrame("eliminaPartecipante", p);
				}

			}
		});
		btnEliminaPartecipante.setBounds(450, 285, 150, 25);
		getContentPane().add(btnEliminaPartecipante);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 325, 724, 2);
		getContentPane().add(separator);
		
		JButton btnIndietro = new JButton("< Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openJFrame("competizioniGestite");
			}
		});
		btnIndietro.setBounds(325, 338, 100, 23);
		getContentPane().add(btnIndietro);
		
	}
}
