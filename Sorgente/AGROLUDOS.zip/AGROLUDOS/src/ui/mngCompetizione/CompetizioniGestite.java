package ui.mngCompetizione;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import ui.MainMenu;
import utility.ControlloDati;

/**
 * Finestra che mostra le competizioni gestite dal manager
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class CompetizioniGestite extends MainMenu {
	
	private static final long serialVersionUID = 1L;
	private JTable table;


	public CompetizioniGestite(ArrayList<ArrayList<Object>> lista) {
		initComponents(lista);
	}
	
	private void initComponents(final ArrayList<ArrayList<Object>> lista){
		
		setSize(700, 410);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(22, 66, 662, 197);
		getContentPane().add(scrollPane);

		DefaultTableModel model = new DefaultTableModel();
		model.addColumn("Data");
		model.addColumn("Ora");
		model.addColumn("Tipo");
		model.addColumn("Prezzo (�)");
		model.addColumn("N. min partecipanti");
		model.addColumn("N. max partecipanti");
		model.addColumn("N. iscritti");
		
		if(lista.size() != 0){
			//aggiungo le righe alla tabella
			for(int i = 0; i < lista.size(); i++){
				
				Object[] row = lista.get(i).toArray();
				model.addRow(row);
			}
		}
		
		table = new JTable(model);
		
		//setto la larghezza delle colonne ad una dimensione prefissata
		TableColumnModel tcm = table.getColumnModel();
		tcm.getColumn(0).setPreferredWidth(45);
		tcm.getColumn(1).setPreferredWidth(15);
		tcm.getColumn(2).setPreferredWidth(100);
		tcm.getColumn(3).setPreferredWidth(50);
		//centro gli elementi all'interno delle celle della tabella
		JLabel label = (JLabel) table.getDefaultRenderer(Object.class);
		label.setHorizontalAlignment (SwingConstants.CENTER);
		
		scrollPane.setViewportView(table);

		//------------ANNULLACOMP
		JButton btnAnnullaComp = new JButton("<html><p align=\"Center\">ANNULLA <br> COMPETIZIONE </p></html>");
		btnAnnullaComp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				if(table.getSelectedRow()== -1){

					//---------------JOPTION PANE
					JOptionPane.showMessageDialog(null, "SELEZIONARE UNA COMPETIZIONE", "ERRORE",
							JOptionPane.ERROR_MESSAGE);

				}else{	
					int reply = JOptionPane.showConfirmDialog(null, 
							"Vuoi davvero annullare la competizione?", 
							"Conferma cancellazione", JOptionPane.YES_NO_OPTION);
					
					if(reply == JOptionPane.YES_OPTION){
						int i = table.getSelectedRow(); //restituisce l' indece della RIGA selezionata
						
						Date d = (Date) table.getValueAt(i, 0);
						boolean checkData = ControlloDati.controlloDataModifica(d);
						
						if(checkData){
						
							ArrayList<Object> p = new ArrayList<Object>();
							p.add(lista.get(i).get(7)); //idCompetizione
							openJFrame("annullaCompetizione", p); //dopo l' annullamento, ricarica la pagina corrente, 
																 //senza la competizione eliminata
							
						} 
					}
				}
			}
		});
		btnAnnullaComp.setBounds(75, 275, 150, 37);
		getContentPane().add(btnAnnullaComp);

		//----------LISTA PARTECIPANTI
		JButton btnListaPartecipanti = new JButton("<html><p align=\"Center\">LISTA <br>PARTECIPANTI </p></html>");
		btnListaPartecipanti.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {


				//-------------- APRE UN' ALTRA FINESTRA CON I PARTECIPANTI DELLA COMPETIZIONE SELEZIONATA
				if(table.getSelectedRow() == -1){

					//---------------JOPTION PANE
					JOptionPane.showMessageDialog(null, "SELEZIONARE UNA COMPETIZIONE", "ERRORE",
							JOptionPane.ERROR_MESSAGE);

				}else{
					int i = table.getSelectedRow(); //restituisce l' indece della RIGA selezionata
					
					ArrayList<Object> p = new ArrayList<Object>();
					p.add(lista.get(i).get(7)); //idCompetizione
					openJFrame("listaPartecipanti", p);
				}
			}
		});
		btnListaPartecipanti.setBounds(275, 275, 150, 37);
		getContentPane().add(btnListaPartecipanti);

		//---------MODIFICA COMPETIZOINE
		// controllare che la data odierna sia antecedente alla data della
		//competizione di almeno tre giorni
		JButton btnmodificaCompetizione = new JButton("<html><p align=\"Center\">MODIFICA <br> COMPETIZIONE </p></html>");
		btnmodificaCompetizione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {


				//-------------- APRE UN' ALTRA FINESTRA CON LA FINESTRA DELLA RIGA SELEZIONATA
				if(table.getSelectedRow()== -1){

					//---------------JOPTION PANE
					JOptionPane.showMessageDialog(null, "SELEZIONARE UNA COMPETIZIONE", "ERRORE",
							JOptionPane.ERROR_MESSAGE);

				}else{
					
					int i = table.getSelectedRow(); //restituisce l' indece della RIGA selezionata
					
					Date d = (Date) table.getValueAt(i, 0);
					boolean checkData = ControlloDati.controlloDataModifica(d);
					
					if(checkData){
						
						ArrayList<Object> p = new ArrayList<Object>();
						p.add(lista.get(i).get(7)); //idCompetizione
						openJFrame("ottieniCompetizione", p);
						
					}
				}
			}
		});
		btnmodificaCompetizione.setBounds(475, 275, 150, 37);
		getContentPane().add(btnmodificaCompetizione);


		//------------indietro-----------
		JButton btnIndietro = new JButton("< Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("menuMngCompetizione");
			}
		});
		btnIndietro.setBounds(300, 340, 100, 25);
		getContentPane().add(btnIndietro);

		JLabel lblTitolo = new JLabel("<html><h4>Lista competizioni:</h4></html>");
		lblTitolo.setBounds(22, 11, 222, 32);
		getContentPane().add(lblTitolo);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 53, 674, 2);
		getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 323, 674, 2);
		getContentPane().add(separator_1);
	}
}
