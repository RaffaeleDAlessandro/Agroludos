package ui.mngCompetizione;

import ui.MainMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JSeparator;

/**
 * Mostra il menu del manager di competizione
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class MenuMngCompetizione extends MainMenu {

	private static final long serialVersionUID = 1L;

	public MenuMngCompetizione() {
		initComponents();
	}
	
	private void initComponents(){

		final String MNG_COMPETIZIONE = "ManagerCompetizione";
		
		setSize(350, 335);

		JLabel lblTitolo = new JLabel("<html><h4>Scegli un' operazione :</h4></html>");
		lblTitolo.setBounds(26, 21, 147, 32);
		getContentPane().add(lblTitolo);

		//---------AGGIUNI COMPETIZIONE ------------
		JButton btnAggiungiCompetizioni = new JButton("Aggiungi competizione");
		btnAggiungiCompetizioni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("nuovaCompetizione");
			}
		});
		btnAggiungiCompetizioni.setBounds(90, 66, 170, 39);
		getContentPane().add(btnAggiungiCompetizioni);

		//--------------VEDI COMPETIZIONI GESTITE
		JButton btnCompetizioniGestite = new JButton("<html><p align=\"Center\"> Vedi competizioni <br>Gestite</p></html>");
		btnCompetizioniGestite.setBounds(90, 126, 170, 39);
		btnCompetizioniGestite.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("competizioniGestite");
			}
		});
		getContentPane().add(btnCompetizioniGestite);


		//--------------DATI UTENTE
		JButton btnDatiUtente = new JButton("Profilo");
		btnDatiUtente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("profiloMngCompetizione");
			}					
		});
		btnDatiUtente.setBounds(100, 193, 150, 23);
		getContentPane().add(btnDatiUtente);

		//------------logout
		JButton btnLogout = new JButton("Logout");
		btnLogout.setBounds(125, 275, 100, 23);
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openJFrame("menu");
			}
		});
		getContentPane().add(btnLogout);

		
		//----------------MODIFICA password
				JButton btnModificaCredenziali = new JButton("Modifica password");
				btnModificaCredenziali.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						//passo parametro intero = 1 per segnalare che � un manager
						// di competizione che vuole cambiare password
						ArrayList<Object> p = new ArrayList<Object>();
						p.add(MNG_COMPETIZIONE);
						openJFrame("modificaPassword", p);
					}
				});
				btnModificaCredenziali.setBounds(100, 227, 150, 23);
				getContentPane().add(btnModificaCredenziali);
				
				JSeparator separator = new JSeparator();
				separator.setBounds(10, 51, 324, 2);
				getContentPane().add(separator);
				
				JSeparator separator_1 = new JSeparator();
				separator_1.setBounds(10, 180, 324, 2);
				getContentPane().add(separator_1);
				
				JSeparator separator_2 = new JSeparator();
				separator_2.setBounds(10, 261, 324, 2);
				getContentPane().add(separator_2);
	}

}
