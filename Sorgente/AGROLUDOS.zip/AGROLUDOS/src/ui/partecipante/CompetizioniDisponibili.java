package ui.partecipante;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import ui.MainMenu;
import utility.ControlloDati;

/**
 * Mostra le competizioni disponibili 
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class CompetizioniDisponibili extends MainMenu {

	private JTable table;
	private static final long serialVersionUID = 1L;

	public CompetizioniDisponibili(ArrayList<ArrayList<Object>> par) {
		initComponents(par);
	}
	
	private void initComponents(final ArrayList<ArrayList<Object>> par){

		final Date dataSRC = (Date) par.get(par.size()-1).get(0);
		
		setSize(650, 400);

		JLabel lblTitolo = new JLabel("<html><h4>Scegli una competizione :</h4></html>");
		lblTitolo.setBounds(29, 10, 588, 32);
		getContentPane().add(lblTitolo);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(32, 66, 585, 197);
		getContentPane().add(scrollPane);
		
		DefaultTableModel model = new DefaultTableModel();
		model.addColumn("Data");
		model.addColumn("Ora");
		model.addColumn("Tipo");
		model.addColumn("Prezzo (�)");

		if(par.size() != 0){
			//aggiungo le righe alla tabella
			for(int i = 0; i < par.size()-1; i++){
				
				Object[] row = par.get(i).toArray();
				model.addRow(row);
			}
			
		}
	
		table = new JTable(model);
		
		TableColumnModel tcm = table.getColumnModel();
		tcm.getColumn(0).setPreferredWidth(45);
		tcm.getColumn(1).setPreferredWidth(20);
		tcm.getColumn(2).setPreferredWidth(200);
		tcm.getColumn(3).setPreferredWidth(40);
		//centro gli elementi all'interno delle celle della tabella
		JLabel label = (JLabel) table.getDefaultRenderer(Object.class);
		label.setHorizontalAlignment (SwingConstants.CENTER);
		
		scrollPane.setViewportView(table);


		//-------------------ISCRIZIONE
		JButton btnIscrizione = new JButton("Scegli Optional\r\n");
		btnIscrizione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
		
				if(table.getSelectedRow()== -1){

					JOptionPane.showMessageDialog(null, "SELEZIONARE UNA COMPETIZIONE", "ERRORE",
							JOptionPane.ERROR_MESSAGE);
			
				} else {
					
					int i = table.getSelectedRow(); //restituisce l' indece della RIGA selezionata
					int nIscr = (int) par.get(i).get(10); // numero di gi� iscritti 
					int nMax = (int) par.get(i).get(5); // num max iscriz
					
					if(nIscr < nMax){ //se non � stato ancora raggiunto il numero massimo di iscrizioni
						
						boolean checkDataSRC = ControlloDati.controlloVincoloSRC(dataSRC, (Date) par.get(i).get(0));
						
						if(checkDataSRC){
							ArrayList<Object> dettagli = new ArrayList<Object>();
							dettagli.add(par.get(i).get(4)); // idComp
							dettagli.add(par.get(i).get(3)); // prezzo
							dettagli.add(par.get(i).get(7)); //pranzo
							dettagli.add(par.get(i).get(8)); // merenda
							dettagli.add(par.get(i).get(9)); //pernotto
							openJFrame("selezioneOptional", dettagli);
						}
					} else {
						JOptionPane.showMessageDialog(null, "Raggiunto il numero massimo di iscritti.", "ERRORE",
								JOptionPane.ERROR_MESSAGE);
					}
				}

			}
		});
		btnIscrizione.setBounds(250, 281, 150, 25);
		getContentPane().add(btnIscrizione);

		//------------indietro-----------
		JButton btnIndietro = new JButton("< Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("menuPartecipante");
			}
		});
		btnIndietro.setBounds(275, 330, 100, 25);
		getContentPane().add(btnIndietro);

		JSeparator separator = new JSeparator();
		separator.setBounds(10, 53, 623, 2);
		getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 317, 623, 2);
		getContentPane().add(separator_1);
		
	}
}
