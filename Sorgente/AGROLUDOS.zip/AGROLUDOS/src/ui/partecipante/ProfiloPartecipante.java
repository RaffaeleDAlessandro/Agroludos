package ui.partecipante;

import ui.MainMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;

/**
 * Mostra il profilo del partecipante
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class ProfiloPartecipante extends MainMenu {

	private static final long serialVersionUID = 1L;

	public ProfiloPartecipante(ArrayList<Object> lista) {
		
		initComponents(lista);
		
	}
	
	private void initComponents(final ArrayList<Object> lista){
		
		setSize(340, 485);
		
		JLabel lblTitolo = new JLabel("<html><h3>Informazioni generali dell' account:</h3></html>");
		lblTitolo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitolo.setBounds(0, 11, 324, 38);
		getContentPane().add(lblTitolo);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 46, 335, 2);
		getContentPane().add(separator);
		
		JLabel lblNome = new JLabel("Nome: ");
		lblNome.setBounds(10, 62, 100, 15);
		getContentPane().add(lblNome);
		
		JLabel lblCognome = new JLabel("Cognome: ");
		lblCognome.setBounds(10, 88, 100, 15);
		getContentPane().add(lblCognome);
		
		JLabel lblCodFisc = new JLabel("Codice Fiscale: ");
		lblCodFisc.setBounds(10, 113, 100, 15);
		getContentPane().add(lblCodFisc);
		
		JLabel lblResidenza = new JLabel("Residenza:");
		lblResidenza.setBounds(10, 139, 100, 15);
		getContentPane().add(lblResidenza);
		
		JLabel lblViapiazza = new JLabel("Via/Piazza:");
		lblViapiazza.setBounds(10, 165, 100, 15);
		getContentPane().add(lblViapiazza);
		
		JLabel lblAnnoNascita = new JLabel("Data di nascita:");
		lblAnnoNascita.setBounds(10, 191, 100, 15);
		getContentPane().add(lblAnnoNascita);
		
		JLabel lblSesso = new JLabel("Sesso:");
		lblSesso.setBounds(10, 217, 100, 14);
		getContentPane().add(lblSesso);
		
		JLabel lblNumTesseraSanitaria = new JLabel("<html>Numero tessera<br /> sanitaria: </html>");
		lblNumTesseraSanitaria.setBounds(10, 242, 100, 30);
		getContentPane().add(lblNumTesseraSanitaria);
		
		JLabel lblDataRilascioSRC = new JLabel("<html>Data rilascio<br /> SRC: </html>");
		lblDataRilascioSRC.setBounds(10, 287, 100, 30);
		getContentPane().add(lblDataRilascioSRC);
		
		JLabel lblEMail = new JLabel("Indirizzo E-Mail:");
		lblEMail.setBounds(10, 332, 100, 14);
		getContentPane().add(lblEMail);

		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 410, 314, 2);
		getContentPane().add(separator_1);
		
		//---------- LABEL NOME --------
		String nomeutente=lista.get(1).toString();
		JLabel lblNomeUtente = new JLabel(nomeutente);
		lblNomeUtente.setBounds(113, 60, 211, 14);
		getContentPane().add(lblNomeUtente);
		
		//---------LABEL COGNOME ---------
		String cognomeutente=lista.get(2).toString();
		JLabel lblcognomeutente = new JLabel(cognomeutente);
		lblcognomeutente.setBounds(113, 88, 211, 14);
		getContentPane().add(lblcognomeutente);
		
		//--------LABEL CODICE FISCALE ----------
		String codicefiscale=lista.get(0).toString();
		JLabel lblcodicefiscale = new JLabel(codicefiscale);
		lblcodicefiscale.setBounds(113, 113, 151, 14);
		getContentPane().add(lblcodicefiscale);
		
		//-------------- RESIDENZA ---------
		String indirizzo=lista.get(3).toString();
		JLabel lblindirizzoutente = new JLabel(indirizzo);
		lblindirizzoutente.setBounds(113, 139, 151, 14);
		getContentPane().add(lblindirizzoutente);
		
		// ------------- VIA -------------
		JLabel lblVia = new JLabel(lista.get(4).toString());
		lblVia.setBounds(113, 165, 151, 14);
		getContentPane().add(lblVia);
		

		JLabel lbldatanascitautente = new JLabel(lista.get(5).toString());
		lbldatanascitautente.setBounds(113, 191, 151, 14);
		getContentPane().add(lbldatanascitautente);
		
		JLabel lblsessoutente = new JLabel(lista.get(6).toString());
		lblsessoutente.setBounds(113, 217, 151, 14);
		getContentPane().add(lblsessoutente);
		
		JLabel lblnumerotesserautente = new JLabel(lista.get(7).toString());
		lblnumerotesserautente.setBounds(113, 251, 151, 14);
		getContentPane().add(lblnumerotesserautente);
		
		JLabel lblDataRilascioSRCutente = new JLabel(lista.get(8).toString());
		lblDataRilascioSRCutente.setBounds(113, 292, 151, 14);
		getContentPane().add(lblDataRilascioSRCutente);
		
		JLabel lblEmailUtente = new JLabel(lista.get(9).toString());
		lblEmailUtente.setBounds(113, 332, 151, 14);
		getContentPane().add(lblEmailUtente);
		
		JButton btnModifica = new JButton("Modifica dati");
		btnModifica.setBounds(100, 374, 140, 25);
		btnModifica.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("modificaDatiPartecipante");
				
			}
		});
		getContentPane().add(btnModifica);
		
		JButton btnIndietro = new JButton("< Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("menuPartecipante");
			}
		});
		btnIndietro.setBounds(120, 423, 100, 25);
		getContentPane().add(btnIndietro);
		
		
	 
	}
}
