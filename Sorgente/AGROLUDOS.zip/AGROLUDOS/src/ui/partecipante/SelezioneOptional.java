package ui.partecipante;

import ui.MainMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.JCheckBox;

/**
 * Scelta degli optional
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class SelezioneOptional extends MainMenu {

	private static final long serialVersionUID = 1L;
	private JCheckBox chckbxPranzo;
	private JCheckBox chckbxMerenda;
	private JCheckBox chckbxPernotto;
	private double przComp;

	public SelezioneOptional(ArrayList<ArrayList<Object>> opt) {
		initComponents(opt);
	}
	
	//final ????
	private void initComponents(final ArrayList<ArrayList<Object>> par){
		
		setSize(320, 275);
		
		JLabel lblTitolo = new JLabel("<html><h4>Scegli optional:</h4></html>");
		lblTitolo.setBounds(25, 11, 140, 32);
		getContentPane().add(lblTitolo);
		
		//-----------OPTIONAL 
		
		JLabel lblOptDisp = new JLabel("Optional disponibili :");
		lblOptDisp.setBounds(25, 67, 175, 26);
		getContentPane().add(lblOptDisp);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 198, 294, 2);
		getContentPane().add(separator_1);

		/*
		 * Abilitare o disabilitare a seconda della query sulla disponibilit�
		 * degli optional per una competizione
		 */
		chckbxPranzo = new JCheckBox("Pranzo");
		chckbxPranzo.setToolTipText(par.get(3).get(1).toString()+"�");
		chckbxPranzo.setBounds(20, 100, 80, 23);
		getContentPane().add(chckbxPranzo);
		
		chckbxMerenda = new JCheckBox("Merenda");
		chckbxMerenda.setToolTipText(par.get(1).get(1).toString()+"�");
		chckbxMerenda.setBounds(120, 100, 80, 23);
		getContentPane().add(chckbxMerenda);
		
		chckbxPernotto = new JCheckBox("Pernotto");
		chckbxPernotto.setToolTipText(par.get(2).get(1).toString()+"�");
		chckbxPernotto.setBounds(220, 100, 80, 23);
		getContentPane().add(chckbxPernotto);
		
		przComp = (double) par.get(0).get(1);

		int pranzo = (int) par.get(0).get(2);
		int merenda = (int) par.get(0).get(3);
		int pernotto = (int) par.get(0).get(4);
		
		if(pranzo == 1){
			chckbxPranzo.setEnabled(true);
		} else {
			chckbxPranzo.setEnabled(false);
		}
		
		if(merenda == 1){
			chckbxMerenda.setEnabled(true);
		} else {
			chckbxMerenda.setEnabled(false);
		}
		
		if(pernotto == 1){
			chckbxPernotto.setEnabled(true);
		} else {
			chckbxPernotto.setEnabled(false);
		}
		
		JButton btnConferma = new JButton("Conferma iscrizione\r\n");
		btnConferma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				int pranzoFlag = 0;
				int merendaFlag = 0;
				int pernottoFlag = 0;
				
				double przTot = przComp;
				if(chckbxPranzo.isSelected()){
					pranzoFlag = 1;
					przTot += (double) par.get(3).get(1);
				}
				if(chckbxMerenda.isSelected()){
					merendaFlag = 1;
					przTot += (double) par.get(1).get(1);
				}
				if(chckbxPernotto.isSelected()){
					pernottoFlag = 1;
					przTot += (double) par.get(2).get(1);
				}
				
				ArrayList<Object> iscrizione = new ArrayList<Object>();
				iscrizione.add(par.get(0).get(0)); //idCompetizione
				iscrizione.add(pranzoFlag);
				iscrizione.add(merendaFlag);
				iscrizione.add(pernottoFlag);
				
				int reply = JOptionPane.showConfirmDialog(null, 
						"Confermi l'iscrizione alla competizione, al prezzo di �" + przTot +"?", 
						"Conferma iscrizione", JOptionPane.YES_NO_OPTION);
				
				if(reply == JOptionPane.YES_OPTION){
					openJFrame("confermaIscrizione", iscrizione);
				}
				
			}
		});
		btnConferma.setBounds(85, 159, 150, 28);
		getContentPane().add(btnConferma);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 54, 294, 2);
		getContentPane().add(separator);
		
	//-----------------indietro
		
		JButton btnIndietro = new JButton("< Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("competizioniDisponibili");
			}
		});
		btnIndietro.setBounds(110, 211, 100, 25);
		getContentPane().add(btnIndietro);
			
	}
	
}
