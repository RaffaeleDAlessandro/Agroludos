package ui.partecipante;

import ui.MainMenu;

/**
 * lista competizioni alla quale un partecipante � iscritto
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

/**
 * Mostra la lista delle competizioni alle quali il partecipante � iscritto 
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class ListaIscrizioni extends MainMenu {

	private static final long serialVersionUID = 1L;
	private JTable table;
	
	public ListaIscrizioni(ArrayList<ArrayList<Object>> lista) {
		initComponents(lista);
	}
	
	private void initComponents(final ArrayList<ArrayList<Object>> lista){
		
		setSize(650, 400);

		JLabel lblTitolo = new JLabel("<html><h4>Lista iscrizioni:</h4></html>");
		lblTitolo.setBounds(29, 10, 347, 32);
		getContentPane().add(lblTitolo);
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 53, 623, 2);
		getContentPane().add(separator);



		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 66, 623, 197);
		getContentPane().add(scrollPane);


		DefaultTableModel model = new DefaultTableModel();
		model.addColumn("Data");
		model.addColumn("Ora");
		model.addColumn("Tipo");
		model.addColumn("Prezzo Totale (�)");
		
		table = new JTable(model);
		
		if(lista.size() != 0){
			//aggiungo le righe alla tabella
			for(int i = 0; i < lista.size(); i++){
				
				Object[] row = lista.get(i).toArray();
				model.addRow(row);
			}
			
		}
		
		TableColumnModel tcm = table.getColumnModel();
		tcm.getColumn(0).setPreferredWidth(45);
		tcm.getColumn(1).setPreferredWidth(20);
		tcm.getColumn(2).setPreferredWidth(200);
		tcm.getColumn(3).setPreferredWidth(40);
		//centro gli elementi all'interno delle celle della tabella
		JLabel label = (JLabel) table.getDefaultRenderer(Object.class);
		label.setHorizontalAlignment (SwingConstants.CENTER);

		scrollPane.setViewportView(table);

		JButton btnEliminaIscrizione = new JButton("Elimina Iscrizione");
		btnEliminaIscrizione.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(table.getSelectedRow()== -1){

					JOptionPane.showMessageDialog(null, "SELEZIONARE UNA COMPETIZIONE", "ERRORE",
							JOptionPane.ERROR_MESSAGE);
			
				}else{
					
					int reply = JOptionPane.showConfirmDialog(null, 
							"Vuoi davvero cancellarti dalla competizione?", 
							"Conferma cancellazione", JOptionPane.YES_NO_OPTION);
					
					if(reply == JOptionPane.YES_OPTION){
						int i = table.getSelectedRow(); //restituisce l' indece della RIGA selezionata
						
						ArrayList<Object> dettagli = new ArrayList<Object>();
						dettagli.add(lista.get(i).get(4)); // idComp intero
						openJFrame("eliminaIscrizione", dettagli);
					}
				}
				
			}
		});
		btnEliminaIscrizione.setBounds(100, 276, 150, 28);
		getContentPane().add(btnEliminaIscrizione);


		
		
		//-----------MODIFICA OPTIONAL
		JButton btnModificaOptional = new JButton("Modifica Optional");
		btnModificaOptional.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(table.getSelectedRow()== -1){

					JOptionPane.showMessageDialog(null, "SELEZIONARE UNA COMPETIZIONE", "ERRORE",
							JOptionPane.ERROR_MESSAGE);
			
				}else{
					
					int i = table.getSelectedRow(); //restituisce l' indece della RIGA selezionata
					
					ArrayList<Object> dettagli = new ArrayList<Object>();
					dettagli.add(lista.get(i).get(4)); // idComp
					openJFrame("leggiOptionalScelti", dettagli);
				}
				
				
			}
		});
		btnModificaOptional.setBounds(400, 276, 150, 28);
		getContentPane().add(btnModificaOptional);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 315, 623, 2);
		getContentPane().add(separator_1);
		
		//------------indietro-----------
		JButton btnIndietro = new JButton("< Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("menuPartecipante");
			}
		});
		btnIndietro.setBounds(275, 322, 100, 28);
		getContentPane().add(btnIndietro);
	}
	
}
