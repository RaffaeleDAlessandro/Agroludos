package ui.partecipante;

import ui.MainMenu;

import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.JLabel;
import javax.swing.JCheckBox;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

/**
 * Mostra gli optional selezionati per una competizione
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class ModificaOptionalScelti extends MainMenu {

	private static final long serialVersionUID = 1L;
	private JCheckBox chckbxPranzo;
	private JCheckBox chckbxMerenda;
	private JCheckBox chckbxPernotto;
	private int pranzoFlag;
	private int merendaFlag;
	private int pernottoFlag;
	
	public ModificaOptionalScelti(ArrayList<ArrayList<Object>> opt) {
		
		initComponents(opt);
		
	}
	
	private void initComponents(final ArrayList<ArrayList<Object>> opt){
		
		setSize(315, 230);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 40, 274, 2);
		getContentPane().add(separator);
		
		JLabel lblTitolo = new JLabel("<html><h4>Modifica optional scelti:</h4></html>");
		lblTitolo.setBounds(10, 11, 274, 18);
		getContentPane().add(lblTitolo);
		
		/*
		 * Le checkbox saranno abilitate o disabilitate a seconda del risultato
		 * della query sull'iscrizione.
		 * Spuntate allo stesso modo.
		 * 
		 */
		chckbxPranzo = new JCheckBox("Pranzo");
		chckbxPranzo.setBounds(15, 60, 85, 23);
		getContentPane().add(chckbxPranzo);
		
		chckbxMerenda = new JCheckBox("Merenda");
		chckbxMerenda.setBounds(100, 60, 85, 23);
		getContentPane().add(chckbxMerenda);
		
		chckbxPernotto = new JCheckBox("Pernotto");
		chckbxPernotto.setBounds(200, 60, 85, 23);
		getContentPane().add(chckbxPernotto);
		
		/*
		 * Setto le checkBox disponibili o meno
		 */
		int pr = (int) opt.get(1).get(0); //disponibilit� pranzo
		int me = (int) opt.get(1).get(1); //disponibilit� merenda
		int pe = (int) opt.get(1).get(2); //disponibilit� pernotto
		
		if(pr == 0){
			chckbxPranzo.setEnabled(false);
		} else {
			chckbxPranzo.setEnabled(true);
		}
		
		if(me == 0){
			chckbxMerenda.setEnabled(false);
		} else {
			chckbxMerenda.setEnabled(true);
		}
		
		if(pe == 0){
			chckbxPernotto.setEnabled(false);
		} else {
			chckbxPernotto.setEnabled(true);
		}
		
		/*
		 * Setto le checkbox selezionate, se serve.
		 */
		pr = (int) opt.get(2).get(0); //scelto pranzo
		me = (int) opt.get(2).get(1); //scelto merenda
		pe = (int) opt.get(2).get(2); //scelto pernotto
		
		if(pr == 0){
			chckbxPranzo.setSelected(false);
		} else {
			chckbxPranzo.setSelected(true);
		}
		
		if(me == 0){
			chckbxMerenda.setSelected(false);
		} else {
			chckbxMerenda.setSelected(true);
		}
		
		if(pe == 0){
			chckbxPernotto.setSelected(false);
		} else {
			chckbxPernotto.setSelected(true);
		}
		
		JButton btnConferma = new JButton("Conferma");
		btnConferma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				double prezzoComp = (double) opt.get(1).get(3); //prezzo della competizione senza optional
				double prezzoTot = prezzoComp;
				
				if(chckbxPranzo.isSelected()){
					pranzoFlag = 1;
					prezzoTot += (double) opt.get(5).get(0);
				}
				
				if(chckbxMerenda.isSelected()){
					merendaFlag = 1;
					prezzoTot += (double) opt.get(3).get(0);
				}
				
				if(chckbxPernotto.isSelected()){
					pernottoFlag = 1;
					prezzoTot += (double) opt.get(4).get(0);
				}
				
				ArrayList<Object> iscrizione = new ArrayList<Object>();
				iscrizione.add(opt.get(0).get(0)); //idCompetizione
				iscrizione.add(pranzoFlag);
				iscrizione.add(merendaFlag);
				iscrizione.add(pernottoFlag);
				
				int reply = JOptionPane.showConfirmDialog(null, 
						"Confermare le modifiche, al prezzo di �" + prezzoTot +"?", 
						"Conferma iscrizione", JOptionPane.YES_NO_OPTION);
				
				if(reply == JOptionPane.YES_OPTION){
					openJFrame("modificaOptionalScelti", iscrizione);
				}
					
				
			}
		});
		btnConferma.setBounds(100, 113, 100, 23);
		getContentPane().add(btnConferma);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 147, 274, 2);
		getContentPane().add(separator_1);
		
		JButton btnIndietro = new JButton("< Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openJFrame("listaIscrizioni");
			}
		});
		btnIndietro.setBounds(100, 160, 100, 23);
		getContentPane().add(btnIndietro);
		
		
		
	}
}
