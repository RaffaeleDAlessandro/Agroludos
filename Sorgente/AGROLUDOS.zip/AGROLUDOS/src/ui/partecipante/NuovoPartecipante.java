package ui.partecipante;

import ui.MainMenu;
import utility.ControlloDati;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.toedter.calendar.JDateChooser;

/**
 * Registrazione di un nuovo partecipante 
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class NuovoPartecipante extends MainMenu {

	private static final long serialVersionUID = 1L;
	private JTextField nomeField;
	private JTextField cognomeField;
	private JTextField codFisField;
	private JTextField residenzaField;
	private JTextField indirizzoField;
	private JTextField NrTessSanitariaField;
	private JTextField emailField;
	private JTextField usernameField;
	private JPasswordField passwordField;
	private JPasswordField passwordConfirmField;
	private JRadioButton mButton;
	private JRadioButton fButton;
	private JDateChooser birthDateField;
	private JDateChooser dateSRCField;
	private String path;
	private InputStream fileinputStream;

	private String nome;
	private String cognome;
	private String sesso;
	private String CF;
	private java.util.Date dataN;
	private java.util.Date dataSRC;
	private String residenza;
	private String indirizzo;
	private String email;
	private String nTessera;
	private String username;
	private String password;
	private String passwordC;
	
	final String PARTECIPANTE = "Partecipanti";

	private JFrame f = (JFrame) SwingUtilities.getRoot(this);

	public NuovoPartecipante() {
		initComponents();
	}
	
	public NuovoPartecipante(ArrayList<Object> p){
		initComponents(p);
	}


	private void initComponents(ArrayList<Object> p) {
		
		setSize(350, 625);

		JLabel lblNewLabel = new JLabel("<html><b>Registrazione nuovo partecipante</b></html>");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 20, 324, 14);
		getContentPane().add(lblNewLabel);

		JSeparator separator = new JSeparator();
		separator.setBounds(10, 50, 324, 2);
		getContentPane().add(separator);

		// ----------- NOME ------------
		JLabel lblNome = new JLabel("Nome: ");
		lblNome.setBounds(10, 65, 100, 15);
		getContentPane().add(lblNome);

		nomeField = new JTextField((String) p.get(1));
		nomeField.setBounds(114, 62, 220, 20);
		getContentPane().add(nomeField);
		nomeField.setColumns(10);

		//-----------COGNOME---------------
		JLabel lblCognome = new JLabel("Cognome: ");
		lblCognome.setBounds(10, 91, 100, 15);
		getContentPane().add(lblCognome);

		cognomeField = new JTextField((String) p.get(2));
		cognomeField.setColumns(10);
		cognomeField.setBounds(114, 88, 220, 20);
		getContentPane().add(cognomeField);

		// --------------- CODICE FISCALE ---------------
		JLabel lblCodFis = new JLabel("Codice Fiscale: ");
		lblCodFis.setBounds(10, 117, 100, 15);
		getContentPane().add(lblCodFis);

		codFisField = new JTextField((String) p.get(0));
		codFisField.setColumns(10);
		codFisField.setBounds(114, 114, 220, 20);
		getContentPane().add(codFisField);

		// --------------- INDIRIZZO -----------------
		JLabel lblIndirizzo = new JLabel("Residenza");
		lblIndirizzo.setBounds(10, 143, 100, 15);
		getContentPane().add(lblIndirizzo);

		residenzaField = new JTextField((String) p.get(3));
		residenzaField.setColumns(10);
		residenzaField.setBounds(114, 140, 220, 20);
		getContentPane().add(residenzaField);

		JLabel lblVia = new JLabel("Via :");
		lblVia.setBounds(10, 169, 37, 14);
		getContentPane().add(lblVia);

		indirizzoField = new JTextField((String) p.get(4));
		indirizzoField.setColumns(10);
		indirizzoField.setBounds(114, 166, 220, 20);
		getContentPane().add(indirizzoField);
		
		// ----------------- DATA DI NASCITA --------------
		java.util.Date dataUtente = (Date) p.get(5);
		
		JLabel lblBirthDate = new JLabel("Data di nascita:");
		lblBirthDate.setBounds(10, 196, 100, 15);
		getContentPane().add(lblBirthDate);

		birthDateField = new JDateChooser(dataUtente);
		birthDateField.setBounds(114, 193, 150, 20);
		getContentPane().add(birthDateField);


		// --------------- SESSO ---------------------
		JLabel lblSesso = new JLabel("Sesso:");
		lblSesso.setBounds(10, 221, 100, 14);
		getContentPane().add(lblSesso);

		//------- SESSO, M -----------
		JLabel lblM = new JLabel("M");
		lblM.setBounds(124, 221, 13, 14);
		getContentPane().add(lblM);

		mButton = new JRadioButton("M");
		mButton.setSelected(false);
		mButton.setBounds(134, 218, 20, 20);
		getContentPane().add(mButton);

		//---------- SESSO, F ------------
		JLabel lblF = new JLabel("F");
		lblF.setBounds(181, 222, 13, 14);
		getContentPane().add(lblF);

		fButton = new JRadioButton("F");
		fButton.setSelected(false);
		fButton.setBounds(191, 218, 20, 20);
		getContentPane().add(fButton);

		// -------- SESSO, BUTTON_GROUP
		ButtonGroup gruppo = new ButtonGroup();
		gruppo.add(mButton);
		gruppo.add(fButton);

		if(((String) p.get(6)).compareTo("M") == 0){
			mButton.setSelected(true);
		} else if(((String) p.get(6)).compareTo("F") == 0){
			fButton.setSelected(true);
		}
		
		// -------- NUM. TESSERA SANITARIA ---------
		JLabel lblNrTessSanitaria = new JLabel("<html>Numero tessera<br /> sanitaria: </html>");
		lblNrTessSanitaria.setBounds(10, 248, 100, 30);
		getContentPane().add(lblNrTessSanitaria);

		NrTessSanitariaField = new JTextField((String) p.get(7));
		NrTessSanitariaField.setColumns(10);
		NrTessSanitariaField.setBounds(114, 254, 220, 20);
		getContentPane().add(NrTessSanitariaField);

		// ----------- IMPORT SRC --------------
		JLabel lblImpSRC = new JLabel("<html>Importa Certificato<br /> SRC: </html>");
		lblImpSRC.setBounds(10, 289, 100, 45);
		getContentPane().add(lblImpSRC);

		JButton btnSfoglia = new JButton("Sfoglia");
		btnSfoglia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				final JFileChooser fileChooser = new JFileChooser();
				FileNameExtensionFilter txtFilter = new FileNameExtensionFilter(
						"*.txt", "txt");
				fileChooser.addChoosableFileFilter(txtFilter);
				fileChooser.setFileFilter(txtFilter);
				fileChooser.setAcceptAllFileFilterUsed(false);//settare il filtro di soli file .txt
				fileChooser.setMultiSelectionEnabled(false); //metodo per selezionare pi� file. nel nostro caso solo un file pu� essere selezionato
				fileChooser.setDialogTitle("Seleziona file SRC...");
				int option = fileChooser.showOpenDialog(f);

				if (option == JFileChooser.APPROVE_OPTION) {
					path = fileChooser.getSelectedFile().getPath();
				}
				if (path != null) {
					try {
						fileinputStream = new FileInputStream(path);

					} catch (FileNotFoundException e1) {
						return;
					}
				}
			}
		});
		btnSfoglia.setBounds(134, 300, 89, 23);
		getContentPane().add(btnSfoglia);

		// -------------- DATA SRC --------------
		java.util.Date dataRilSRC = (Date) p.get(9);
		
		JLabel lblDataRilascioSrc = new JLabel("<html>Data rilascio<br /> SRC: </html>");
		lblDataRilascioSrc.setBounds(10, 341, 100, 30);
		getContentPane().add(lblDataRilascioSrc);

		dateSRCField = new JDateChooser(dataRilSRC);
		dateSRCField.setBounds(114, 346, 150, 20);
		getContentPane().add(dateSRCField);

		// -------- E-MAIL -----------------
		JLabel lblEmail = new JLabel("Indirizzo E-Mail:");
		lblEmail.setBounds(10, 392, 100, 14);
		getContentPane().add(lblEmail);

		emailField = new JTextField((String) p.get(10));
		emailField.setColumns(10);
		emailField.setBounds(114, 389, 220, 20);
		getContentPane().add(emailField);

		// ------------ USERNAME ---------------
		JLabel lblUsername = new JLabel("Username: ");
		lblUsername.setBounds(10, 417, 100, 14);
		getContentPane().add(lblUsername);

		usernameField = new JTextField();
		usernameField.setColumns(10);
		usernameField.setBounds(114, 414, 220, 20);
		getContentPane().add(usernameField);

		//-------------- PASSWORD --------------
		JLabel lblPassword = new JLabel("Password: ");
		lblPassword.setBounds(10, 442, 100, 14);
		getContentPane().add(lblPassword);

		passwordField = new JPasswordField();
		passwordField.setBounds(114, 439, 220, 20);
		getContentPane().add(passwordField);

		// ----------- RIPETI PASSWORD --------
		JLabel lblRipetiPassword = new JLabel("Ripeti password: ");
		lblRipetiPassword.setBounds(10, 467, 100, 14);
		getContentPane().add(lblRipetiPassword);

		passwordConfirmField = new JPasswordField();
		passwordConfirmField.setBounds(114, 464, 220, 20);
		getContentPane().add(passwordConfirmField);

		// ---------- BOTTONE CONFERMA --------------
		JButton btnConferma = new JButton("Conferma");
		btnConferma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				nome = nomeField.getText();
				cognome = cognomeField.getText();
				dataN = birthDateField.getDate();
				CF = codFisField.getText().toUpperCase();
				nTessera = NrTessSanitariaField.getText();
				residenza = residenzaField.getText();
				indirizzo=indirizzoField.getText();
				email = emailField.getText();
				dataSRC = dateSRCField.getDate();
				username = usernameField.getText();
				password = String.valueOf(passwordField.getPassword());
				passwordC = String.valueOf(passwordConfirmField.getPassword());

				controlli(); 

			}
		});
		btnConferma.setBounds(124, 515, 100, 25);
		getContentPane().add(btnConferma);


		//---------- INDIETRO -----------
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 549, 324, 2);
		getContentPane().add(separator_1);

		JButton indietroBtn = new JButton("< Indietro");
		indietroBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("registrazione");
			}
		});
		indietroBtn.setBounds(124, 561, 100, 25);
		getContentPane().add(indietroBtn);
		
	}

	private void initComponents(){

		setSize(350, 625);

		JLabel lblNewLabel = new JLabel("<html><b>Registrazione nuovo partecipante</b></html>");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 20, 324, 14);
		getContentPane().add(lblNewLabel);

		JSeparator separator = new JSeparator();
		separator.setBounds(10, 50, 324, 2);
		getContentPane().add(separator);

		// ----------- NOME ------------
		JLabel lblNome = new JLabel("Nome: ");
		lblNome.setBounds(10, 65, 100, 15);
		getContentPane().add(lblNome);

		nomeField = new JTextField();
		nomeField.setBounds(114, 62, 220, 20);
		getContentPane().add(nomeField);
		nomeField.setColumns(10);

		//-----------COGNOME---------------
		JLabel lblCognome = new JLabel("Cognome: ");
		lblCognome.setBounds(10, 91, 100, 15);
		getContentPane().add(lblCognome);

		cognomeField = new JTextField();
		cognomeField.setColumns(10);
		cognomeField.setBounds(114, 88, 220, 20);
		getContentPane().add(cognomeField);

		// --------------- CODICE FISCALE ---------------
		JLabel lblCodFis = new JLabel("Codice Fiscale: ");
		lblCodFis.setBounds(10, 117, 100, 15);
		getContentPane().add(lblCodFis);

		codFisField = new JTextField();
		codFisField.setColumns(10);
		codFisField.setBounds(114, 114, 220, 20);
		getContentPane().add(codFisField);

		// --------------- INDIRIZZO -----------------
		JLabel lblIndirizzo = new JLabel("Residenza");
		lblIndirizzo.setBounds(10, 143, 100, 15);
		getContentPane().add(lblIndirizzo);

		residenzaField = new JTextField();
		residenzaField.setColumns(10);
		residenzaField.setBounds(114, 140, 220, 20);
		getContentPane().add(residenzaField);

		JLabel lblVia = new JLabel("Via :");
		lblVia.setBounds(10, 169, 37, 14);
		getContentPane().add(lblVia);

		indirizzoField = new JTextField();
		indirizzoField.setColumns(10);
		indirizzoField.setBounds(114, 166, 220, 20);
		getContentPane().add(indirizzoField);
		// ----------------- DATA DI NASCITA --------------
		JLabel lblBirthDate = new JLabel("Data di nascita:");
		lblBirthDate.setBounds(10, 196, 100, 15);
		getContentPane().add(lblBirthDate);

		birthDateField = new JDateChooser();
		birthDateField.setBounds(114, 193, 150, 20);
		getContentPane().add(birthDateField);


		// --------------- SESSO ---------------------
		JLabel lblSesso = new JLabel("Sesso:");
		lblSesso.setBounds(10, 221, 100, 14);
		getContentPane().add(lblSesso);

		//------- SESSO, M -----------
		JLabel lblM = new JLabel("M");
		lblM.setBounds(124, 221, 13, 14);
		getContentPane().add(lblM);

		mButton = new JRadioButton("M");
		mButton.setSelected(false);
		mButton.setBounds(134, 218, 20, 20);
		getContentPane().add(mButton);

		//---------- SESSO, F ------------
		JLabel lblF = new JLabel("F");
		lblF.setBounds(181, 222, 13, 14);
		getContentPane().add(lblF);

		fButton = new JRadioButton("F");
		fButton.setSelected(false);
		fButton.setBounds(191, 218, 20, 20);
		getContentPane().add(fButton);

		// -------- SESSO, BUTTON_GROUP
		ButtonGroup gruppo = new ButtonGroup();
		gruppo.add(mButton);
		gruppo.add(fButton);


		// -------- NUM. TESSERA SANITARIA ---------
		JLabel lblNrTessSanitaria = new JLabel("<html>Numero tessera<br /> sanitaria: </html>");
		lblNrTessSanitaria.setBounds(10, 248, 100, 30);
		getContentPane().add(lblNrTessSanitaria);

		NrTessSanitariaField = new JTextField();
		NrTessSanitariaField.setColumns(10);
		NrTessSanitariaField.setBounds(114, 254, 220, 20);
		getContentPane().add(NrTessSanitariaField);

		// ----------- IMPORT SRC --------------
		JLabel lblImpSRC = new JLabel("<html>Importa Certificato<br /> SRC: </html>");
		lblImpSRC.setBounds(10, 289, 100, 45);
		getContentPane().add(lblImpSRC);

		JButton btnSfoglia = new JButton("Sfoglia");
		btnSfoglia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				final JFileChooser fileChooser = new JFileChooser();
				FileNameExtensionFilter txtFilter = new FileNameExtensionFilter(
						"*.txt", "txt");
				fileChooser.addChoosableFileFilter(txtFilter);
				fileChooser.setFileFilter(txtFilter);
				fileChooser.setAcceptAllFileFilterUsed(false);//settare il filtro di soli file .txt
				fileChooser.setMultiSelectionEnabled(false); //metodo per selezionare pi� file. nel nostro caso solo un file pu� essere selezionato
				fileChooser.setDialogTitle("Seleziona file SRC...");
				int option = fileChooser.showOpenDialog(f);

				if (option == JFileChooser.APPROVE_OPTION) {
					path = fileChooser.getSelectedFile().getPath();
				}
				if (path != null) {
					try {
						fileinputStream = new FileInputStream(path);

					} catch (FileNotFoundException e1) {
						return;
					}
				}
			}
		});
		btnSfoglia.setBounds(134, 300, 89, 23);
		getContentPane().add(btnSfoglia);

		// -------------- DATA SRC --------------
		JLabel lblDataRilascioSrc = new JLabel("<html>Data rilascio<br /> SRC: </html>");
		lblDataRilascioSrc.setBounds(10, 341, 100, 30);
		getContentPane().add(lblDataRilascioSrc);

		dateSRCField = new JDateChooser();
		dateSRCField.setBounds(114, 346, 150, 20);
		getContentPane().add(dateSRCField);

		// -------- E-MAIL -----------------
		JLabel lblEmail = new JLabel("Indirizzo E-Mail:");
		lblEmail.setBounds(10, 392, 100, 14);
		getContentPane().add(lblEmail);

		emailField = new JTextField();
		emailField.setColumns(10);
		emailField.setBounds(114, 389, 220, 20);
		getContentPane().add(emailField);

		// ------------ USERNAME ---------------
		JLabel lblUsername = new JLabel("Username: ");
		lblUsername.setBounds(10, 417, 100, 14);
		getContentPane().add(lblUsername);

		usernameField = new JTextField();
		usernameField.setColumns(10);
		usernameField.setBounds(114, 414, 220, 20);
		getContentPane().add(usernameField);

		//-------------- PASSWORD --------------
		JLabel lblPassword = new JLabel("Password: ");
		lblPassword.setBounds(10, 442, 100, 14);
		getContentPane().add(lblPassword);

		passwordField = new JPasswordField();
		passwordField.setBounds(114, 439, 220, 20);
		getContentPane().add(passwordField);

		// ----------- RIPETI PASSWORD --------
		JLabel lblRipetiPassword = new JLabel("Ripeti password: ");
		lblRipetiPassword.setBounds(10, 467, 100, 14);
		getContentPane().add(lblRipetiPassword);

		passwordConfirmField = new JPasswordField();
		passwordConfirmField.setBounds(114, 464, 220, 20);
		getContentPane().add(passwordConfirmField);

		// ---------- BOTTONE CONFERMA --------------
		JButton btnConferma = new JButton("Conferma");
		btnConferma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				nome = nomeField.getText();
				cognome = cognomeField.getText();
				dataN = birthDateField.getDate();
				CF = codFisField.getText().toUpperCase();
				nTessera = NrTessSanitariaField.getText();
				residenza = residenzaField.getText();
				indirizzo=indirizzoField.getText();
				email = emailField.getText();
				dataSRC = dateSRCField.getDate();
				username = usernameField.getText();
				password = String.valueOf(passwordField.getPassword());
				passwordC = String.valueOf(passwordConfirmField.getPassword());

				controlli(); 

			}
		});
		btnConferma.setBounds(124, 515, 100, 25);
		getContentPane().add(btnConferma);


		//---------- INDIETRO -----------
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 549, 324, 2);
		getContentPane().add(separator_1);

		JButton indietroBtn = new JButton("< Indietro");
		indietroBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("registrazione");
			}
		});
		indietroBtn.setBounds(124, 561, 100, 25);
		getContentPane().add(indietroBtn);

	}
	
	/**
	 * questo metodo fa i controlli ortografici sui dati inseriti dall' utente. controlla anche l' esistenza nel db dell' username (univoco).
	 * 
	 */
	private void controlli(){
		// --------------------------------------------------------------------------------------------- DAO
		if(ControlloDati.confrontoPass(password, passwordC)){

			boolean checkusername = ControlloDati.controlloUserName(username);
			boolean checkpassword = ControlloDati.controlloPassword(password);
			boolean checkdataN = ControlloDati.controllaData(dataN);
			boolean checkdataSRC = ControlloDati.controlloDataSRC(dataSRC, dataN);
			boolean checknTessera = ControlloDati.controllaTS(nTessera);
			boolean checkResidenzaIndirizzo = ControlloDati.controllaResidenzaeIndirizzo(residenza, indirizzo);
			boolean checkEmail = ControlloDati.controllaEmail(email);
			boolean checkNome = ControlloDati.controllaNome(nome);
			boolean checkCognome = ControlloDati.controllaCognome(cognome);

			if(!(fButton.isSelected() || mButton.isSelected())){
				JOptionPane.showMessageDialog(null, "selezionare il sesso",
						"ERRORE",
						JOptionPane.ERROR_MESSAGE);
			}else{
				if (mButton.isSelected()){
					sesso="M";
				}else{
					sesso="F";
				}
			}

			if(fileinputStream == null){
				JOptionPane.showMessageDialog(null, "Selezionare certificato SRC",
						"ERRORE",
						JOptionPane.ERROR_MESSAGE);
			}

			if(checkCognome && checkNome && checkdataN && checkdataSRC 
					&& checkEmail && checknTessera && checkpassword && 
					checkResidenzaIndirizzo && checkusername && 
					(fButton.isSelected() || mButton.isSelected()) 
					&& fileinputStream!=null
					)
			{
				conferma();		//se la condizione � vera allora confema.
			}

		}
	}

	// pulsante per l'invio dei dati

	/**
	 * motodo che viene eseguito quando viene cliccato su 'conferma' e tutti i dati sono corretti.
	 * 
	 * CONTROLLARE
	 */
	private void conferma(){

		ArrayList<Object> anagrafica = new ArrayList<Object>();

		/*
		 * Prima di aggiungere i dati nel sistema, bisogna controllare che
		 * non esistano gi� CF, email, numero di tessera sanitaria,
		 * username e password
		 */
		anagrafica.add(CF);
		anagrafica.add(rep(nome));
		anagrafica.add(rep(cognome));
		anagrafica.add(rep(residenza));
		anagrafica.add(rep(indirizzo));
		anagrafica.add(dataN);
		anagrafica.add(sesso);
		anagrafica.add(nTessera);
		anagrafica.add(fileinputStream);
		anagrafica.add(dataSRC);
		anagrafica.add(email);
		anagrafica.add(username);
		anagrafica.add(password);

		openJFrame("registrazionePartecipante", anagrafica);


	}
}
