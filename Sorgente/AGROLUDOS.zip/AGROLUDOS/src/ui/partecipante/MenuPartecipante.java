package ui.partecipante;

import ui.MainMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JSeparator;

/**
 * Mostra il menu principale del partecipante
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class MenuPartecipante extends MainMenu {

	private static final long serialVersionUID = 1L;

	public MenuPartecipante() {
		initComponents();
	}
	
	private void initComponents(){
		
		final String PARTECIPANTE = "Partecipanti";
		//-----------LOGOUT
		
		setSize(350, 365);
		
		JButton btnlogout = new JButton("Logout");
		btnlogout.setBounds(125, 303, 100, 23);
		btnlogout.addActionListener(new ActionListener() {
			
		
			public void actionPerformed(ActionEvent e) {
			openJFrame("menu");	
			}
		});
		getContentPane().add(btnlogout);
		
		
		JLabel lblNewLabel = new JLabel(
				"<html><h4>Scegli un' operazione :</h4></html>");
		lblNewLabel.setBounds(26, 21, 147, 32);
		getContentPane().add(lblNewLabel);
		
		//--------------DATI UTENTE
		JButton btnDatiUtente = new JButton("Profilo");
		btnDatiUtente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("profiloPartecipante");
			}
		});
		btnDatiUtente.setBounds(100, 222, 150, 23);
		getContentPane().add(btnDatiUtente);
		
		//----------------ISCRIVITI AD UNA COMPETIZIONE
		JButton btnIscriviti = new JButton(
				"<html> <p align=\"center\"> Iscriviti ad una competizione </p></html>");
		btnIscriviti.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("competizioniDisponibili");
			}
		});
		btnIscriviti.setBounds(75, 72, 200, 50);
		getContentPane().add(btnIscriviti);
		
		//---------------VISUALIZZA COMPETIZIONI ALLA QUALE SEI ISCRITTO
		JButton btnvisualizzaCompetizioni = new JButton(
				"<html><p align = \"center\">Visualizza competizioni alle quali sei iscritto\r\n</p></html>");
		btnvisualizzaCompetizioni.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				openJFrame("listaIscrizioni");
				
			}
		});
		btnvisualizzaCompetizioni.setBounds(75, 139, 200, 50);
		getContentPane().add(btnvisualizzaCompetizioni);
		//----------------MODIFICA CREDENZIALI DI ACCESSO
		JButton btnModificaCredenziali = new JButton("Modifica password");
		btnModificaCredenziali.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//passo parametro intero = 2 per segnalare che � un partecipante
				//che vuole cambiare password
				ArrayList<Object> p = new ArrayList<Object>();
				p.add(PARTECIPANTE);
				openJFrame("modificaPassword", p);
			}
		});
		btnModificaCredenziali.setBounds(100, 256, 150, 23);
		getContentPane().add(btnModificaCredenziali);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 209, 324, 2);
		getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 59, 324, 2);
		getContentPane().add(separator_1);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(10, 290, 324, 2);
		getContentPane().add(separator_2);
	}
}
