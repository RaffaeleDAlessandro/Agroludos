package ui.partecipante;

import ui.MainMenu;
import utility.ControlloDati;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.toedter.calendar.JDateChooser;

/**
 * Modifica dei dati relativi ad un partecipante
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */

public class ModificaDatiPartecipante extends MainMenu {

	private static final long serialVersionUID = 1L;
	private JTextField nomeField;
	private JTextField cognomeField;
	private JTextField residenzaField;
	private JTextField viaField;
	private JTextField NrTessSanitariaField;
	private JTextField emailField;
	private JDateChooser dateNascitaUtente;
	private JDateChooser dateRilascioSRC;
	private  JRadioButton mButton;
	private  JRadioButton fButton;

	private String nome;
	private String cognome;
	private String sesso;
	private java.util.Date dataN;
	private java.util.Date dataSRC;
	private String residenza;
	private String indirizzo;
	private String email;
	private String nTessera;

	//private String path;
	private InputStream fileinputStream;

	private JFrame f = (JFrame) SwingUtilities.getRoot(this);

	public ModificaDatiPartecipante(ArrayList<Object> lista) {
		initComponents(lista);
	}

	private void initComponents(ArrayList<Object> lista){

		setSize(350, 520);

		JLabel lblTitolo = new JLabel("<html><h3>Modifica dati partecipante</h3></html>");
		lblTitolo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitolo.setBounds(10, 20, 324, 32);
		getContentPane().add(lblTitolo);

		JSeparator separator = new JSeparator();
		separator.setBounds(10, 50, 324, 2);
		getContentPane().add(separator);

		// ----------- NOME ------------
		JLabel lblNome = new JLabel("Nome: ");
		lblNome.setBounds(10, 65, 100, 15);
		getContentPane().add(lblNome);

		String nomeutente=lista.get(1).toString(); // STESSO MECCANISMO PER GLI ALTRI CAMPI DI TESTO 
		nomeField = new JTextField(nomeutente);
		nomeField.setBounds(114, 62, 220, 20);
		getContentPane().add(nomeField);
		nomeField.setColumns(10);

		//-----------COGNOME---------------
		String cognomeutente=lista.get(2).toString();
		JLabel lblCognome = new JLabel("Cognome: ");
		lblCognome.setBounds(10, 91, 100, 15);
		getContentPane().add(lblCognome);

		cognomeField = new JTextField(cognomeutente);
		cognomeField.setColumns(10);
		cognomeField.setBounds(114, 88, 220, 20);
		getContentPane().add(cognomeField);

		// --------------- INDIRIZZO -----------------
		JLabel lblResidenza = new JLabel("Residenza:");
		lblResidenza.setBounds(10, 117, 100, 15);
		getContentPane().add(lblResidenza);

		residenzaField = new JTextField(lista.get(3).toString());
		residenzaField.setColumns(10);
		residenzaField.setBounds(114, 114, 220, 20);
		getContentPane().add(residenzaField);

		JLabel lblVia = new JLabel("Via/Piazza :");
		lblVia.setBounds(10, 143, 100, 14);
		getContentPane().add(lblVia);

		viaField = new JTextField(lista.get(4).toString());
		viaField.setColumns(10);
		viaField.setBounds(114, 140, 220, 20);
		getContentPane().add(viaField);



		// ----------------- DATA DI NASCITA --------------

		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date dataUtente = null;
		try {
			String dataString = lista.get(5).toString();
			dataUtente=formatter.parse(dataString);
		} catch (ParseException e1) {
			e1.toString();
		}

		JLabel lblDataNascita = new JLabel("Data di nascita:");
		lblDataNascita.setBounds(10, 169, 100, 15);
		getContentPane().add(lblDataNascita);

		dateNascitaUtente = new JDateChooser(dataUtente);
		dateNascitaUtente.setBounds(114, 166, 150, 20);
		getContentPane().add(dateNascitaUtente);

		// --------------- SESSO ---------------------
		JLabel lblSesso = new JLabel("Sesso:");
		lblSesso.setBounds(10, 195, 100, 14);
		getContentPane().add(lblSesso);

		//------- SESSO, M -----------
		JLabel lblM = new JLabel("M");
		lblM.setBounds(124, 195, 13, 14);
		getContentPane().add(lblM);

		mButton = new JRadioButton("M");
		mButton.setSelected(false);
		mButton.setBounds(134, 192, 20, 20);
		getContentPane().add(mButton);

		//---------- SESSO, F ------------
		JLabel lblF = new JLabel("F");
		lblF.setBounds(179, 195, 13, 14);
		getContentPane().add(lblF);

		fButton = new JRadioButton("F");
		fButton.setSelected(false);
		fButton.setBounds(189, 192, 20, 20);
		getContentPane().add(fButton);

		// -------- SESSO, BUTTON_GROUP
		sesso=lista.get(6).toString();
		ButtonGroup gruppo = new ButtonGroup();
		gruppo.add(mButton);
		gruppo.add(fButton);

		if(sesso.compareTo("M")==0){
			mButton.setSelected(true);
		}else{
			fButton.setSelected(true);
		}

		// -------- NUM. TESSERA SANITARIA ---------
		JLabel lblNrTessSanitaria = new JLabel("<html>Numero tessera<br /> sanitaria: </html>");
		lblNrTessSanitaria.setBounds(10, 221, 100, 30);
		getContentPane().add(lblNrTessSanitaria);

		NrTessSanitariaField = new JTextField(lista.get(7).toString());
		NrTessSanitariaField.setColumns(10);
		NrTessSanitariaField.setBounds(114, 225, 220, 20);
		getContentPane().add(NrTessSanitariaField);

		// ----------- IMPORT SRC --------------
		JLabel lblImpSRC = new JLabel("<html>Importa Certificato<br /> SRC: </html>");
		lblImpSRC.setBounds(10, 261, 100, 42);
		getContentPane().add(lblImpSRC);

		JButton btnSfoglia = new JButton("Sfoglia");
		btnSfoglia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String path = "";
				final JFileChooser fileChooser = new JFileChooser();
				FileNameExtensionFilter txtFilter = new FileNameExtensionFilter(
						"*.txt", "txt");
				fileChooser.addChoosableFileFilter(txtFilter);
				fileChooser.setFileFilter(txtFilter);
				fileChooser.setAcceptAllFileFilterUsed(false);//settare il filtro di soli file .txt
				fileChooser.setMultiSelectionEnabled(false); //metodo per selezionare pi� file. nel nostro caso solo un file pu� essere selezionato
				fileChooser.setDialogTitle("Seleziona file SRC...");
				int option = fileChooser.showOpenDialog(f);

				if (option == JFileChooser.APPROVE_OPTION) {
					path = fileChooser.getSelectedFile().getPath();
				}
				if (path != null) {
					try {
						fileinputStream = new FileInputStream(path);

					} catch (FileNotFoundException e1) {
						return;
					}
				}
			}
		});
		btnSfoglia.setBounds(133, 273, 89, 23);
		getContentPane().add(btnSfoglia);

		// -------------- DATA SRC --------------
		JLabel lblDataRilascioSrc = new JLabel("<html>Data rilascio<br /> SRC: </html>");
		lblDataRilascioSrc.setBounds(10, 314, 100, 41);
		getContentPane().add(lblDataRilascioSrc);

		try {
			String dataString=lista.get(8).toString();
			dataUtente=formatter.parse(dataString);
		} catch (ParseException e1) {
			e1.toString();
		}


		dateRilascioSRC = new JDateChooser(dataUtente);
		dateRilascioSRC.setBounds(114, 323, 150, 20);
		getContentPane().add(dateRilascioSRC);

		// -------- E-MAIL -----------------
		JLabel lblEmail = new JLabel("Indirizzo E-Mail:");
		lblEmail.setBounds(10, 369, 100, 14);
		getContentPane().add(lblEmail);

		emailField = new JTextField(lista.get(9).toString());
		emailField.setColumns(10);
		emailField.setBounds(114, 365, 220, 20);
		getContentPane().add(emailField);

		// ---------- BOTTONE CONFERMA --------------
		JButton btnModifica = new JButton("Conferma modifiche");
		btnModifica.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				nome = nomeField.getText();
				cognome = cognomeField.getText();
				dataN = dateNascitaUtente.getDate();
				nTessera = NrTessSanitariaField.getText();
				residenza = residenzaField.getText();
				indirizzo = viaField.getText();
				email = emailField.getText();
				dataSRC = dateRilascioSRC.getDate();

				controlli();

			}
		});
		btnModifica.setBounds(100, 404, 150, 23);
		getContentPane().add(btnModifica);


		//---------- INDIETRO -----------
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 442, 324, 2);
		getContentPane().add(separator_1);

		JButton indietroBtn = new JButton("< Indietro");
		indietroBtn.setBounds(124, 456, 100, 25);
		indietroBtn.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				openJFrame("profiloPartecipante");

			}
		});
		getContentPane().add(indietroBtn);
	}



	/**
	 * questo metodo fa i controlli ortografici sui dati inseriti dall' utente. controlla anche l' esistenza nel db dell' username (univoco).
	 * 
	 */
	private void controlli(){

		boolean checkdataN = ControlloDati.controllaData(dataN);
		boolean checkdataSRC = ControlloDati.controlloDataSRC(dataSRC, dataN);
		boolean checknTessera = ControlloDati.controllaTS(nTessera);
		boolean checkResidenzaIndirizzo = ControlloDati.controllaResidenzaeIndirizzo(residenza, indirizzo);
		boolean checkEmail = ControlloDati.controllaEmail(email);
		boolean checkNome = ControlloDati.controllaNome(nome);
		boolean checkCognome = ControlloDati.controllaCognome(cognome);

		if(!(fButton.isSelected() || mButton.isSelected())){
			JOptionPane.showMessageDialog(null, "selezionare il sesso",
					"ERRORE",
					JOptionPane.ERROR_MESSAGE);
		}else{
			if (mButton.isSelected()){
				sesso="M";
			}else{
				sesso="F";
			}
		}

		//				if(fileinputStream==null){						SE E' VUOTO, QUINDI NN E' STATO SELEZIONATO ALCUN FILE, QUESTO NON DEVE ESSERE AGGIORNATO
		//					JOptionPane.showMessageDialog(null, "Selezionare certificato SRC",
		//							"ERRORE",
		//							JOptionPane.ERROR_MESSAGE);
		//				}
		//rimettere controllo sul file
		if(checkCognome && checkNome && checkdataN && checkdataSRC 
				&& checkEmail && checknTessera && 
				checkResidenzaIndirizzo && 
				(fButton.isSelected() || mButton.isSelected()) 
				)
		{
			conferma();		//se la condizione � vera allora confema.
		}

	}

	/**
	 * medoto per l' invio dei dati
	 */
	private void conferma() {

		ArrayList<Object> anagrafica = new ArrayList<Object>();

		anagrafica.add(rep(nome));
		anagrafica.add(rep(cognome));
		anagrafica.add(sesso);
		anagrafica.add(dataN);
		anagrafica.add(nTessera);

		if(fileinputStream!=null){
			anagrafica.add(fileinputStream);
		}

		anagrafica.add(rep(residenza));
		anagrafica.add(rep(indirizzo));
		anagrafica.add(email);
		anagrafica.add(dataSRC);

		openJFrame("confermaModifichePart", anagrafica);
	}

}

