package business;

import java.util.ArrayList;

import entity.utente.IntRUtente;
import entity.utente.IntWUtente;
import entity.utente.IntUtente;

/**
 * Classe per la gestione degli utenti
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class GestioneUtenti {
	
	private static IntRUtente rUtente = IntUtente.getRUtente();

	private static IntWUtente wUtente = IntUtente.getWUtente() ;

	/**
	 * Effettua il login di un utente
	 * 
	 * @param p dettagli utente
	 * @return 
	 */
	public Object login(ArrayList<Object> p){
		return (Object) rUtente.login(p);
	}
	
	/**
	 * Modifica la password dell'utente
	 * 
	 * @param par dettagli password
	 */
	public void aggiornaPassword(ArrayList<Object> par){
		wUtente.aggiornaPassword(par);
	}
	
	/**
	 * Controlla l'esistenza dell'username inserito dall'utente
	 * 
	 * @param u l'username specificato dall'utente
	 * @return true se esiste, false altrimenti
	 */
	public Object esisteUsername(String u){
		return (Object) rUtente.esisteUsername(u);
	}
	
	/**
	 * Ottiene la mail dell'utente
	 * 
	 * @param p dettagli dell'utente 
	 * @return la mail dell'utente
	 */
	public Object getMail(ArrayList<Object> p){
		return (Object) rUtente.getMail(p);
	}
	
	/**
	 * Ottiene la password dell'utente 
	 * 
	 * @param tipo il tipo di utente 
	 * @return la password dell'utente 
	 */
	public String getPassword(String tipo){
		return rUtente.getPassword(tipo);
	}
	
}
