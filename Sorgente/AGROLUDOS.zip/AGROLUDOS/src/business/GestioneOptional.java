package business;

import java.util.ArrayList;

import entity.optional.IntROptional;
import entity.optional.IntWOptional;
import entity.optional.IntOptional;

/**
 * Classe per la gestione degli Optional
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class GestioneOptional {

	private static IntROptional rOptional = IntOptional.getROptional();
	
	private static IntWOptional wOptional = IntOptional.getWOptional();
	
	/**
	 * Restituisce i dettagli degli optional
	 * 
	 * @return la lista degli optional
	 */
	public ArrayList<ArrayList<Object>> dettagliOptional(){
		return rOptional.dettagliOptional();
	}
	
	/**
	 * Restituisce i prezzi degli optional
	 * 
	 * @return i prezzi degli optional
	 */
	public ArrayList<Object> getPrezzi(){
		return rOptional.getPrezzi();
	}
	
	/**
	 * Conferma le modifiche ai prezzi degli optional
	 * 
	 * @param p i dettagli degli optional
	 */
	public void confermaPrezzoOptional(ArrayList<Object> p){
		wOptional.confermaPrezzoOptional(p);
	}
	
}
