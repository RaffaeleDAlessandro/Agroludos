package business;

import java.util.ArrayList;

import entity.mngCompetizione.IntRMngCompetizione;
import entity.mngCompetizione.IntWMngCompetizione;
import entity.mngCompetizione.IntMngCompetizione;

/**
 * Classe per la gestione dei manager di competizione
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class GestioneMngCompetizione {

	private static IntRMngCompetizione rMngCompetizione = IntMngCompetizione.getRMngCompetizione();
	
	private static IntWMngCompetizione wMngCompetizione = IntMngCompetizione.getWMngCompetizione();
	
	/**
	 * Registrazione del manager di competizione
	 * 
	 * @param p i dettagli del manager
	 */
	public void registrazioneMngCompetizione(ArrayList<Object> p){
		wMngCompetizione.registrazioneMngCompetizione(p);
	}
	
	/**
	 * Restituisce il profilo con i dati del manager di competizione
	 * 
	 * @return il profilo con i dati del manager di competizione
	 */
	public ArrayList<Object> profiloMngCompetizione(){
		return rMngCompetizione.profiloMngCompetizione();
	}
	
	/**
	 * Scrive le modifiche del profilo del manager di competizione
	 * 
	 * @param p dettagli del manager
	 */
	public void confermaModificheMng(ArrayList<Object> p){
		wMngCompetizione.confermaModificheMng(p);
	}
	
	/**
	 * Legge l'elenco dei manager di competizione
	 * 
	 * @return lista dei manager di competizione
	 */
	public ArrayList<ArrayList<Object>> vediMngCompetizioni(){
		return rMngCompetizione.vediMngCompetizioni();
	}
	
	/**
	 * Ottiene la mail di un manager di competizione, dato l'id
	 * 
	 * @param id l'id del manager di competizione
	 * @return la mail del manager di competizione
	 */
	public Object getMailMng(String id){
		return rMngCompetizione.getMailMng(id);
	}

	
}
