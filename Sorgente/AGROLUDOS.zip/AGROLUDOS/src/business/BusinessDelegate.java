package business;

import java.lang.reflect.Method;
import java.net.URL;
import java.util.ArrayList;

import utility.XMLReader;

/**
 * Delega la richiesta al metodo appropriato
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class BusinessDelegate {

	private XMLReader xml;
	private String path = "/xml/AC.xml";

	private URL url = BusinessDelegate.class.getResource(path);
	
	/**
	 * Si occupa di soddisfare la richiesta
	 * 
	 * @param key metodo da raggiungere
	 * @param par eventuali parametri
	 * @return l'oggetto prestabilito 
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 */
	public Object execute(String key, ArrayList<Object> par) throws 
		ClassNotFoundException, InstantiationException, IllegalAccessException, 
		NoSuchMethodException, SecurityException {

		xml = new XMLReader(url);
		ArrayList<String> parametri = xml.leggiParametri(key);

		String metodo;
		String classe;

		classe = parametri.get(0).toString();
		metodo = parametri.get(1).toString();

		Class<?> c = Class.forName(classe);
		Object o = c.newInstance();

		if(par != null){
			Method m = c.getDeclaredMethod(metodo, par.getClass());
			Class<?> returnType = m.getReturnType();
			m.setAccessible(true);

			try {

				Object result;
				if(returnType != Void.TYPE){
					result = returnType.newInstance();
				}
				result = m.invoke(o, par);
				return result;

			} catch(Exception e) {
				e.toString();
			}

		} else {

			Method m = c.getDeclaredMethod(metodo, (Class[]) null);
			Class<?> returnType = m.getReturnType();
			m.setAccessible(true);

			try {
				Object result;
				if(returnType != Void.TYPE){
					result = returnType.newInstance();
				}
				result = m.invoke(o);
				return result;
			} catch (Exception e) {
				e.toString();
			}

		}

		return null;
	}

	/**
	 * Si occupa di soddisfare la richiesta
	 * 
	 * @param key il metodo da raggiungere
	 * @param p l'eventuale parametro 
	 * @return l'oggetto prestabilito 
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 */
	public Object execute(String key, String p) throws 
		ClassNotFoundException, InstantiationException, 
		IllegalAccessException, NoSuchMethodException, 
		SecurityException {

		xml = new XMLReader(url);
		ArrayList<String> parametri = xml.leggiParametri(key);
		String metodo;
		String classe;

		classe = parametri.get(0).toString();
		metodo = parametri.get(1).toString();

		Class<?> c = Class.forName(classe);
		Object o = c.newInstance();

		if(p != null){
			Method m = c.getDeclaredMethod(metodo, p.getClass());
			Class<?> returnType = m.getReturnType();
			m.setAccessible(true);

			try {

				Object result;
				if(returnType != Void.TYPE){
					result = returnType.newInstance();
				}
				result = m.invoke(o, p);
				return result;

			} catch(Exception e){
				e.toString();
			}

		} else {

			Method m = c.getDeclaredMethod(metodo, (Class[]) null);
			Class<?> returnType = m.getReturnType();
			m.setAccessible(true);

			try {

				Object result;
				if(returnType != Void.TYPE){
					result = returnType.newInstance();		
				}
				result = m.invoke(o);
				return result;

			} catch(Exception e) {
				e.toString();
			}

		}

		return null;
	}

}
