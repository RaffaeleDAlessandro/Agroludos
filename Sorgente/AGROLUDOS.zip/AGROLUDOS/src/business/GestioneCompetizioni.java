package business;

import java.util.ArrayList;

import entity.competizione.IntRCompetizione;
import entity.competizione.IntWCompetizione;
import entity.competizione.IntCompetizione;

/**
 * Classe per la gestione delle competizioni
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro
 *
 */
public class GestioneCompetizioni {

	private static IntWCompetizione wCompetizione = IntCompetizione.getWCompetizione();
	
	private static IntRCompetizione rCompetizione = IntCompetizione.getRCompetizione();
	
	/**
	 * Ottiene la lista delle competizioni disponibili (attore: mng competizione)
	 * 
	 * @return la lista delle competizioni disponibili con i dettagli
	 */
	public ArrayList<ArrayList<Object>> leggiCompetizioni(){
		return rCompetizione.leggiCompetizioni();
	}
	
	/**
	 * Legge gli optional previsti per una competizione
	 * 
	 * @param par dettagli della competizione
	 * @return la lista degli optional previsti 
	 */
	public ArrayList<ArrayList<Object>> leggiOptional(ArrayList<Object> par){
		return rCompetizione.leggiOptional(par);
	}
	
	/**
	 * Legge i tipi di competizioni disponibili
	 * 
	 * @return la lista dei tipi di competizione disponibili
	 */
	public ArrayList<Object> leggiTipiCompetizione(){
		return rCompetizione.leggiTipiCompetizione();
	}
	
	/**
	 * Inserisce una nuova competizione
	 * 
	 * @param par i dettagli della competizione 
	 */
	public void nuovaCompetizione(ArrayList<Object> par){
		wCompetizione.nuovaCompetizione(par);
	}
	
	/**
	 * Legge le competizioni gestite da un manager di competizione
	 * 
	 * @return la lista delle competizioni gestite dal manager
	 */
	public ArrayList<ArrayList<Object>> competizioniGestite(){
		return rCompetizione.competizioniGestite();
	}
	
	/**
	 * Mostra la lista dei partecipanti iscritti ad una competizione
	 * 
	 * @param id l'id della competizione
	 * @return la lista dei partecipanti iscritti ad una competizione
	 */
	public ArrayList<ArrayList<Object>> listaPartecipanti(String id){
		return rCompetizione.listaPartecipanti(id);
	}
	
	/**
	 * Annulla una competizione
	 * 
	 * @param p i dettagli della competizione
	 */
	public void annullaCompetizione(ArrayList<Object> p){
		wCompetizione.annullaCompetizione(p);
	}
	
	/**
	 * Legge una competizione, dato l'id
	 * 
	 * @param id l'id della competizione
	 * @return i dettagli della competizione
	 */
	public ArrayList<Object> ottieniCompetizione(String id){
		return rCompetizione.ottieniCompetizione(id);
	}

	/**
	 * Modifica una competizione gi� organizzata
	 * 
	 * @param c dettagli della competizione
	 */
	public void modificaCompetizione(ArrayList<Object> c){
		wCompetizione.modificaCompetizione(c);
	}
	
	/**
	 * Legge tutte le competizioni (in atto, concluse e annullate) (mng sistema)
	 * @return la lista di tutte le competizioni
	 */
	public ArrayList<ArrayList<Object>> vediCompetizioni(){
		return rCompetizione.vediCompetizioni();
	}
	
	/**
	 * Elimina un tipo di competizione
	 * 
	 * @param c il tipo di competizione da eliminare
	 */
	public void eliminaTipoComp(String c){
		wCompetizione.eliminaTipoCompetizione(c);
	}
	
	/**
	 * Aggiunge un nuovo tipo di competizione
	 *  
	 * @param c il tipo di competizione da aggiungere
	 */
	public void aggiungiTipoCompetizione(String c){
		wCompetizione.aggiungiTipoCompetizione(c);
	}
	
	/**
	 * Riduce il numero del partecipanti
	 * 
	 * @param d lista dei partecipanti da eliminare
	 * @return la lista delle mail dei partecipanti eliminati
	 */
	public ArrayList<Object> riduciPartecipanti(ArrayList<Object> d){
		return rCompetizione.riduciPartecipanti(d);
	}
	
}
