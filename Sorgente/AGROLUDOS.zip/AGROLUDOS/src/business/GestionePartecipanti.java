package business;

import java.util.ArrayList;
import java.util.Date;

import entity.partecipante.IntRPartecipante;
import entity.partecipante.IntWPartecipante;
import entity.partecipante.IntPartecipante;

/**
 * Classe per la gestione dei partecipanti 
 * 
 * @author Marco Dispoto, Raffaele D'Alessandro 
 *
 */
public class GestionePartecipanti {

	private static IntRPartecipante rPartecipante = IntPartecipante.getRPartecipante();
	
	private static IntWPartecipante wPartecipante = IntPartecipante.getWPartecipante();
	
	/**
	 * Registrazione del partecipante
	 * 
	 * @param par l'anagrafica del partecipante
	 */
	public void registrazionePartecipante(ArrayList<Object> par){
		wPartecipante.registrazionePartecipante(par);
	}
	
	/**
	 * Ottiene le informazioni del partecipanti
	 * 
	 * @param u username del partecipante
	 * @return l'anagrafica del partecipante
	 */
	public ArrayList<Object> ottieniPartecipante(){
		return rPartecipante.getPartecipante();
	}
	
	/**
	 * Conferma le modifiche al profilo del partecipante
	 * 
	 * @param par i dettagli del partecipante
	 */
	public void confermaModifichePart(ArrayList<Object> par){
		wPartecipante.confermaModifichePart(par);
	}
	
	/**
	 * Registra l'iscrizione del partecipante ad una competizione
	 * 
	 * @param par i dati necessari all'iscrizione
	 */
	public Object iscrizioneCompetizione(ArrayList<Object> par){
		return wPartecipante.iscrizioneCompetizione(par);
	}
	
	/**
	 * Mostra le competizioni a cui un partecipante � iscritto
	 * 
	 * @return la lista delle competizioni
	 */
	public ArrayList<ArrayList<Object>> leggiIscrizioni(){
		return rPartecipante.leggiIscrizioni();
	}
	
	/**
	 * Cancella l'iscrizione di un partecipante ad una competizione
	 * 
	 * @param p i dettagli
	 */
	public void eliminaIscrizione(ArrayList<Object> p){
		wPartecipante.cancellaIscrizione(p);
	}
	
	/**
	 * Legge gli optional scelti
	 * 
	 * @param p 
	 * @return la lista degli optional selezionati 
	 */
	public ArrayList<ArrayList<Object>> leggiOptionalScelti(ArrayList<Object> p){
		return rPartecipante.leggiOptionalScelti(p);
	}
	
	/**
	 * Modifica gli optional scelti dal partecipante
	 * 
	 * @param p optional 
	 */
	public void modificaOptionalSceltiP(ArrayList<Object> p){
		wPartecipante.modificaOptionalSceltiP(p);
	}
	
	/**
	 * Modifica gli optional scelti dal Manager
	 * 
	 * @param p optional
	 */
	public void modificaOptionalSceltiM(ArrayList<Object> p){
		wPartecipante.modificaOptionalSceltiM(p);
	}
	
	/**
	 * Legge gli optional scelti da un partecipante
	 * 
	 * @param p dettagli
	 * @return lista degli optional scelti 
	 */
	public ArrayList<ArrayList<Object>> vediOptionalPartecipante(ArrayList<Object> p){
		return rPartecipante.vediOptionalScelti(p);
	}
	
	/**
	 * Ottiene la lista delle mail dei partecipanti iscritti ad una competizione
	 * 
	 * @param idC id della competizione
	 * @return la lista delle mail dei partecipanti iscritti alla competizione
	 */
	public ArrayList<Object> getMailList(String idC){
		return rPartecipante.getMailList(idC);
	}
	
	/**
	 * Ottiene la data di rilascio dell'src di un partecipante
	 * 
	 * @return la data di rilascio dell'src
	 */
	public Date getDataSRC(){
		return rPartecipante.getDataSRC();
	}
	
	/**
	 * Ottiene il numero di iscritti ad una competizione
	 * 
	 * @param id l'id della competizione 
	 * @return il numero di iscritti alla competizione
	 */
	public Object getNumIscritti(String id){
		return rPartecipante.getNumIscritti(id);
	}
	
}
